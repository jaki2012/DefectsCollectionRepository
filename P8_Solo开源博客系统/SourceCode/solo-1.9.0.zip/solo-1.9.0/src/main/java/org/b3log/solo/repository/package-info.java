/**
 * Data access.
 */
package org.b3log.solo.repository;
