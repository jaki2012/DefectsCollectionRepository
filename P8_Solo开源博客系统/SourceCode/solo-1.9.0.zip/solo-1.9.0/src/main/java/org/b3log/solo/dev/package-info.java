/**
 * Development usage.
 * 
 * <p>
 * All functions in this package just for development mode.
 * </p>
 */
package org.b3log.solo.dev;
