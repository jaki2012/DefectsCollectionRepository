package org.b3log.solo.repository.impl;

import org.b3log.latke.Keys;
import org.b3log.latke.repository.Transaction;
import org.b3log.solo.AbstractTestCase;
import org.b3log.solo.ExcelUtil;
import org.b3log.solo.model.Article;
import org.b3log.solo.repository.ArticleRepository;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by 91574 on 2017/6/2.
 */
public class ArchiveRepositoryImplTest extends AbstractTestCase {

    @DataProvider(name = "archiveData")
    public Object[][] Users() {
        try {
            return ExcelUtil.getInputData("Data", "ArchiverRepository");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    @Test(dataProvider = "archiveData")
    public void getPrevious(String articleTitle1,String date1,String published1,
                    String articleTitle2,String date2,String published2) throws Exception {
        try{
            final ArticleRepository articleRepository = getArticleRepository();

            final JSONObject article = new JSONObject();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            article.put(Article.ARTICLE_TITLE, articleTitle1);
            article.put(Article.ARTICLE_ABSTRACT, "article abstract");
            article.put(Article.ARTICLE_TAGS_REF, "tag1, tag2");
            article.put(Article.ARTICLE_AUTHOR_EMAIL, "test@gmail.com");
            article.put(Article.ARTICLE_COMMENT_COUNT, 0);
            article.put(Article.ARTICLE_VIEW_COUNT, 0);
            article.put(Article.ARTICLE_CONTENT, "article content");
            article.put(Article.ARTICLE_PERMALINK, "article permalink1");
            article.put(Article.ARTICLE_HAD_BEEN_PUBLISHED, true);
            article.put(Article.ARTICLE_IS_PUBLISHED, Boolean.valueOf(published1));
            article.put(Article.ARTICLE_PUT_TOP, false);
            System.out.println(new Date());
            article.put(Article.ARTICLE_CREATE_DATE, dateFormat.parse(date1));
            article.put(Article.ARTICLE_UPDATE_DATE, dateFormat.parse(date1));
            article.put(Article.ARTICLE_RANDOM_DOUBLE, Math.random());
            article.put(Article.ARTICLE_SIGN_ID, "1");
            article.put(Article.ARTICLE_COMMENTABLE, true);
            article.put(Article.ARTICLE_VIEW_PWD, "");
            article.put(Article.ARTICLE_EDITOR_TYPE, "");

            final Transaction transaction = articleRepository.beginTransaction();
            articleRepository.add(article);
            transaction.commit();


            final ArticleRepository articleRepository2 = getArticleRepository();

            final JSONObject article2 = new JSONObject();

            article2.put(Article.ARTICLE_TITLE, articleTitle2);
            article2.put(Article.ARTICLE_ABSTRACT, "article abstract");
            article2.put(Article.ARTICLE_TAGS_REF, "tag1, tag2");
            article2.put(Article.ARTICLE_AUTHOR_EMAIL, "test@gmail.com");
            article2.put(Article.ARTICLE_COMMENT_COUNT, 1);
            article2.put(Article.ARTICLE_VIEW_COUNT, 1);
            article2.put(Article.ARTICLE_CONTENT, "article content");
            article2.put(Article.ARTICLE_PERMALINK, "article permalink2");
            article2.put(Article.ARTICLE_HAD_BEEN_PUBLISHED, true);
            article2.put(Article.ARTICLE_IS_PUBLISHED, Boolean.valueOf(published2));
            article2.put(Article.ARTICLE_PUT_TOP, false);
            article2.put(Article.ARTICLE_CREATE_DATE, dateFormat.parse(date2));
            article2.put(Article.ARTICLE_UPDATE_DATE, dateFormat.parse(date2));
            article2.put(Article.ARTICLE_RANDOM_DOUBLE, Math.random());
            article2.put(Article.ARTICLE_SIGN_ID, "1");
            article2.put(Article.ARTICLE_COMMENTABLE, true);
            article2.put(Article.ARTICLE_VIEW_PWD, "");
            article2.put(Article.ARTICLE_EDITOR_TYPE, "");

            final Transaction transaction2 = articleRepository.beginTransaction();
            articleRepository2.add(article);
            transaction2.commit();


            JSONObject previousArticle = articleRepository2.getPreviousArticle(article2.getString(Keys.OBJECT_ID));

            Assert.assertNotNull(previousArticle);
            Assert.assertEquals(previousArticle.getString(Article.ARTICLE_TITLE), articleTitle1);

        }catch (Exception e){
            e.printStackTrace();
        }



    }

    @Test(dataProvider = "archiveData")
    public void getNext(String articleTitle1,String date1,String published1,
                            String articleTitle2,String date2,String published2) throws Exception {
        try{
            final ArticleRepository articleRepository = getArticleRepository();

            final JSONObject article = new JSONObject();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            article.put(Article.ARTICLE_TITLE, articleTitle1);
            article.put(Article.ARTICLE_ABSTRACT, "article abstract");
            article.put(Article.ARTICLE_TAGS_REF, "tag1, tag2");
            article.put(Article.ARTICLE_AUTHOR_EMAIL, "test@gmail.com");
            article.put(Article.ARTICLE_COMMENT_COUNT, 0);
            article.put(Article.ARTICLE_VIEW_COUNT, 0);
            article.put(Article.ARTICLE_CONTENT, "article content");
            article.put(Article.ARTICLE_PERMALINK, "article permalink1");
            article.put(Article.ARTICLE_HAD_BEEN_PUBLISHED, true);
            article.put(Article.ARTICLE_IS_PUBLISHED, Boolean.valueOf(published1));
            article.put(Article.ARTICLE_PUT_TOP, false);
            System.out.println(new Date());
            article.put(Article.ARTICLE_CREATE_DATE, dateFormat.parse(date1));
            article.put(Article.ARTICLE_UPDATE_DATE, dateFormat.parse(date1));
            article.put(Article.ARTICLE_RANDOM_DOUBLE, Math.random());
            article.put(Article.ARTICLE_SIGN_ID, "1");
            article.put(Article.ARTICLE_COMMENTABLE, true);
            article.put(Article.ARTICLE_VIEW_PWD, "");
            article.put(Article.ARTICLE_EDITOR_TYPE, "");

            final Transaction transaction = articleRepository.beginTransaction();
            articleRepository.add(article);
            transaction.commit();


            final ArticleRepository articleRepository2 = getArticleRepository();

            final JSONObject article2 = new JSONObject();

            article2.put(Article.ARTICLE_TITLE, articleTitle2);
            article2.put(Article.ARTICLE_ABSTRACT, "article abstract");
            article2.put(Article.ARTICLE_TAGS_REF, "tag1, tag2");
            article2.put(Article.ARTICLE_AUTHOR_EMAIL, "test@gmail.com");
            article2.put(Article.ARTICLE_COMMENT_COUNT, 1);
            article2.put(Article.ARTICLE_VIEW_COUNT, 1);
            article2.put(Article.ARTICLE_CONTENT, "article content");
            article2.put(Article.ARTICLE_PERMALINK, "article permalink2");
            article2.put(Article.ARTICLE_HAD_BEEN_PUBLISHED, true);
            article2.put(Article.ARTICLE_IS_PUBLISHED, Boolean.valueOf(published2));
            article2.put(Article.ARTICLE_PUT_TOP, false);
            article2.put(Article.ARTICLE_CREATE_DATE, dateFormat.parse(date2));
            article2.put(Article.ARTICLE_UPDATE_DATE, dateFormat.parse(date2));
            article2.put(Article.ARTICLE_RANDOM_DOUBLE, Math.random());
            article2.put(Article.ARTICLE_SIGN_ID, "1");
            article2.put(Article.ARTICLE_COMMENTABLE, true);
            article2.put(Article.ARTICLE_VIEW_PWD, "");
            article2.put(Article.ARTICLE_EDITOR_TYPE, "");

            final Transaction transaction2 = articleRepository.beginTransaction();
            articleRepository2.add(article);
            transaction2.commit();


            JSONObject nextArticle = articleRepository2.getNextArticle(article.getString(Keys.OBJECT_ID));

            Assert.assertNotNull(nextArticle);
            Assert.assertEquals(nextArticle.getString(Article.ARTICLE_TITLE), articleTitle2);

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
