package org.b3log.solo.repository.impl;

import org.b3log.latke.repository.Transaction;
import org.b3log.solo.AbstractTestCase;
import org.b3log.solo.ExcelUtil;
import org.b3log.solo.model.Comment;
import org.b3log.solo.repository.CommentRepository;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Date;
import java.util.List;

/**
 * Created by 91574 on 2017/6/3.
 */
public class CommentRepositoryImplTest extends AbstractTestCase {

    @DataProvider(name = "commentData")
    public Object[][] Users() {
        try {
            return ExcelUtil.getInputData("Data", "CommentRepository");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Test(dataProvider = "commentData")
    public void add(String commentNum,String commentType,String isPublished) throws Exception {
        try {
            final CommentRepository commentRepository = getCommentRepository();
            int commentsSize=Integer.valueOf(commentNum);
            for(int i=1;i<=commentsSize;i++){
                final JSONObject comment = new JSONObject();
                comment.put(Comment.COMMENT_CONTENT, "comment1 content");
                comment.put(Comment.COMMENT_DATE, new Date());
                comment.put(Comment.COMMENT_EMAIL, "test@gmail.com");
                comment.put(Comment.COMMENT_NAME, "comment1 name");
                comment.put(Comment.COMMENT_ON_ID, "comment1 on id");
                comment.put(Comment.COMMENT_ON_TYPE, commentType);
                comment.put(Comment.COMMENT_ORIGINAL_COMMENT_ID, "");
                comment.put(Comment.COMMENT_ORIGINAL_COMMENT_NAME, "");
                comment.put(Comment.COMMENT_SHARP_URL, "comment1 sharp url");
                comment.put(Comment.COMMENT_URL, "comment1 url");
                comment.put(Comment.COMMENT_THUMBNAIL_URL, "comment1 thumbnail url");

                final Transaction transaction = commentRepository.beginTransaction();
                commentRepository.add(comment);
                transaction.commit();
            }

            System.out.println(commentRepository.getRecentComments(2).size());
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
