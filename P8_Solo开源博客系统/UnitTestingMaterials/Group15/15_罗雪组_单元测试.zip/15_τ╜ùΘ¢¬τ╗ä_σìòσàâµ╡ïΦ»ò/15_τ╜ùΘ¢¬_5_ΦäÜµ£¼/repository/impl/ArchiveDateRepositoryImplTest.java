package org.b3log.solo.repository.impl;


import org.apache.commons.lang.time.DateUtils;
import org.b3log.latke.repository.RepositoryException;
import org.b3log.latke.repository.Transaction;
import org.b3log.solo.AbstractTestCase;
import org.b3log.solo.ExcelUtil;
import org.b3log.solo.SoloServletListener;
import org.b3log.solo.model.ArchiveDate;
import org.b3log.solo.repository.ArchiveDateRepository;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import javax.swing.*;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.text.ParseException;
import java.util.regex.PatternSyntaxException;

/**
 * Created by 91574 on 2017/6/1.
 */
public class ArchiveDateRepositoryImplTest extends AbstractTestCase {



    @DataProvider(name = "archiveDateData")
    public Object[][] Users() {
        try {
            return ExcelUtil.getInputData("Data", "ArchiverDateRepository");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Test(dataProvider = "archiveDateData")
    public void add(String year, String month) throws Exception {
        String archive_time = year + "/" + month;
        final ArchiveDateRepository archiveDateRepository = getArchiveDateRepository();

        final JSONObject archiveDate = new JSONObject();
        try {
            archiveDate.put(ArchiveDate.ARCHIVE_TIME, DateUtils.parseDate(archive_time, new String[]{"yyyy/MM"}).getTime());
            archiveDate.put(ArchiveDate.ARCHIVE_DATE_ARTICLE_COUNT, 1);
            archiveDate.put(ArchiveDate.ARCHIVE_DATE_PUBLISHED_ARTICLE_COUNT, 1);
            final Transaction transaction = archiveDateRepository.beginTransaction();
            archiveDateRepository.add(archiveDate);
            transaction.commit();
        } catch (Exception e) {

        }
    }


    @Test(dataProvider = "archiveDateData",dependsOnMethods = "add")
    public void getByArchiveDate(String year, String month) throws Exception {
        String archive_time = year + "/" + month;

        final ArchiveDateRepository archiveDateRepository = getArchiveDateRepository();
        final JSONObject archiveDate = archiveDateRepository.getByArchiveDate(archive_time);
        Assert.assertEquals(archiveDate.getInt(ArchiveDate.ARCHIVE_DATE_ARTICLE_COUNT), 1);
        Assert.assertEquals(archiveDate.getInt(ArchiveDate.ARCHIVE_DATE_PUBLISHED_ARTICLE_COUNT), 1);
    }

    @Test
    public void getByArchiveDateNull() throws Exception {

        final ArchiveDateRepository archiveDateRepository = getArchiveDateRepository();
        try {
            final JSONObject archiveDate = archiveDateRepository.getByArchiveDate("-1");
        } catch (Exception e) {
            Assert.assertEquals("org.b3log.latke.repository.RepositoryException", e.getClass().getName());
        }
    }

}
