package org.b3log.solo.processor;

import org.apache.commons.lang.StringUtils;
import org.b3log.latke.Keys;
import org.b3log.latke.Latkes;
import org.b3log.latke.logging.Level;
import org.b3log.latke.model.Role;
import org.b3log.latke.model.User;
import org.b3log.latke.servlet.renderer.JSONRenderer;
import org.b3log.latke.util.MD5;
import org.b3log.latke.util.Requests;
import org.b3log.latke.util.Sessions;
import org.b3log.latke.util.Strings;
import org.b3log.solo.AbstractTestCase;
import org.b3log.solo.ExcelUtil;
import org.b3log.solo.model.Common;
import org.b3log.solo.service.InitService;
import org.b3log.solo.service.UserQueryService;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by 91574 on 2017/6/3.
 */
public class LoginProcessTest extends AbstractTestCase {

    @DataProvider(name = "loginData")
    public Object[][] Users() {
        try {
            return ExcelUtil.getInputData("Data", "LoginProcess");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    @Test(dataProvider = "loginData")
    public void login(String username,String password,String flag)throws Exception{
        try {
            final HttpServletRequest request = mock(HttpServletRequest.class);
            when(request.getServletContext()).thenReturn(mock(ServletContext.class));
            when(request.getRequestURI()).thenReturn("/login");
            when(request.getMethod()).thenReturn("POST");

            final JSONObject requestJSON = new JSONObject();
            requestJSON.put(User.USER_EMAIL, username);
            requestJSON.put(User.USER_PASSWORD, password);

            final BufferedReader reader = new BufferedReader(new StringReader(requestJSON.toString()));
            when(request.getReader()).thenReturn(reader);

            final MockDispatcherServlet dispatcherServlet = new MockDispatcherServlet();
            dispatcherServlet.init();

            final StringWriter stringWriter = new StringWriter();
            final PrintWriter printWriter = new PrintWriter(stringWriter);

            final HttpServletResponse response = mock(HttpServletResponse.class);
            when(response.getWriter()).thenReturn(printWriter);

            dispatcherServlet.service(request, response);

            final String content = stringWriter.toString();
            Assert.assertTrue(StringUtils.contains(content, "isLoggedIn\":" + flag));
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
