package org.b3log.solo.repository.impl;

import java.util.Date;
import java.util.List;
import org.b3log.latke.repository.Transaction;
import org.b3log.solo.AbstractTestCase;
import org.b3log.solo.model.Comment;
import org.b3log.solo.repository.CommentRepository;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

@Test(suiteName = "repository")
public class CommentRepositoryImplTestCase extends AbstractTestCase {

    @Test
    public void add() throws Exception {
        final CommentRepository commentRepository = getCommentRepository();

        final JSONObject comment = new JSONObject();
        //输入变量
        comment.put(Comment.COMMENT_CONTENT, "comment1 content");
        comment.put(Comment.COMMENT_DATE, new Date());
        comment.put(Comment.COMMENT_EMAIL, "test1@gmail.com");
        comment.put(Comment.COMMENT_NAME, "comment1 name");
        comment.put(Comment.COMMENT_ON_ID, "comment1 on id");
        comment.put(Comment.COMMENT_ON_TYPE, "comment1 on type");
        comment.put(Comment.COMMENT_ORIGINAL_COMMENT_ID, "");
        comment.put(Comment.COMMENT_ORIGINAL_COMMENT_NAME, "");
        comment.put(Comment.COMMENT_SHARP_URL, "comment1 sharp url");
        comment.put(Comment.COMMENT_URL, "comment1 url");
        comment.put(Comment.COMMENT_THUMBNAIL_URL, "comment1 thumbnail url");

        final Transaction transaction = commentRepository.beginTransaction();
        commentRepository.add(comment);
        transaction.commit();
    }
}
