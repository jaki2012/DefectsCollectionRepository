package org.b3log.solo.repository.impl;

import org.b3log.latke.repository.Transaction;
import org.b3log.solo.AbstractTestCase;
import org.b3log.solo.model.Category;
import org.b3log.solo.repository.CategoryRepository;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

@Test(suiteName = "repository")
public final class CategoryRepositoryImplTestCase extends AbstractTestCase {
    @Test
    public void test() throws Exception {
        final CategoryRepository categoryRepository = getCategoryRepository();

        final int category1Order = 1, category2Order = 2, category3Order = 3;

        JSONObject category = new JSONObject();
        category.put(Category.CATEGORY_TITLE, "category title");
        category.put(Category.CATEGORY_DESCRIPTION, "cateogry description");
        category.put(Category.CATEGORY_URI, "category uri");
        category.put(Category.CATEGORY_ORDER, category1Order);
        category.put(Category.CATEGORY_TAG_CNT, 0);

        Transaction transaction = categoryRepository.beginTransaction();
        categoryRepository.add(category);
        transaction.commit();

    
        Assert.assertNotNull(categoryRepository.getByTitle("category title"));
    }
}
