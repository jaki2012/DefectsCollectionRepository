package org.b3log.solo.repository.impl;

import java.util.List;
import org.b3log.latke.Keys;
import org.b3log.latke.repository.Transaction;
import org.b3log.solo.AbstractTestCase;
import org.b3log.solo.model.Page;
import org.b3log.solo.repository.PageRepository;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

@Test(suiteName = "repository")
public class PageRepositoryImplTestCase extends AbstractTestCase {

  
    @Test
    public void add() throws Exception {
        final PageRepository pageRepository = getPageRepository();

        Assert.assertEquals(pageRepository.getMaxOrder(), -1);

        final JSONObject page = new JSONObject();

        page.put(Page.PAGE_COMMENT_COUNT, 0);
        page.put(Page.PAGE_CONTENT, "page1 content");
        page.put(Page.PAGE_ORDER, 0);
        page.put(Page.PAGE_PERMALINK, "page1 permalink");
        page.put(Page.PAGE_TITLE, "page1 title");
        page.put(Page.PAGE_COMMENTABLE, true);
        page.put(Page.PAGE_TYPE, "page");
        page.put(Page.PAGE_OPEN_TARGET, "_self");
        page.put(Page.PAGE_EDITOR_TYPE, "");

        final Transaction transaction = pageRepository.beginTransaction();
        pageRepository.add(page);
        transaction.commit();
    }
}
