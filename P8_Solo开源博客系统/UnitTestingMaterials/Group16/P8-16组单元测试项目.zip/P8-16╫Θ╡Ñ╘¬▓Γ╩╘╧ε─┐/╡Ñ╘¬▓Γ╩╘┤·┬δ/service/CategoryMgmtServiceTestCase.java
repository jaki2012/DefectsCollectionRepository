package org.b3log.solo.service;

import org.b3log.latke.model.User;
import org.b3log.solo.AbstractTestCase;
import org.b3log.solo.model.Category;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

@Test(suiteName = "service")
public class CategoryMgmtServiceTestCase extends AbstractTestCase {

    @Test
    public void addCategory() throws Exception {
        final CategoryMgmtService categoryMgmtService = getCategoryMgmtService();

        final JSONObject category = new JSONObject();
        category.put(Category.CATEGORY_TITLE, "category1 title");
        category.put(Category.CATEGORY_URI, "category1 uri");
        category.put(Category.CATEGORY_DESCRIPTION, "category1 description");

        final String categoryId = categoryMgmtService.addCategory(category);
        Assert.assertNotNull(categoryId);
    }

    @Test
    public void removeCategory() throws Exception {
        final CategoryMgmtService categoryMgmtService = getCategoryMgmtService();

        final JSONObject category = new JSONObject();
        category.put(Category.CATEGORY_TITLE, "category2 title");
        category.put(Category.CATEGORY_URI, "category2 uri");
        category.put(Category.CATEGORY_DESCRIPTION, "category2 description");

        final String categoryId = categoryMgmtService.addCategory(category);
        Assert.assertNotNull(categoryId);

        final CategoryQueryService categoryQueryService = getCategoryQueryService();
        JSONObject result = categoryQueryService.getCategory(categoryId);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getString(Category.CATEGORY_TITLE), "category2 title");

        categoryMgmtService.removeCategory(categoryId);

        result = categoryQueryService.getCategory(categoryId);
        Assert.assertNull(result);
    }
}
