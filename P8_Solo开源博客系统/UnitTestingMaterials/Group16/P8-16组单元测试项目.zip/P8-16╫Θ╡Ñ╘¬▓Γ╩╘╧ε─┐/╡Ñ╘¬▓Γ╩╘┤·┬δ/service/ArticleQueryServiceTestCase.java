package org.b3log.solo.service;

import org.b3log.latke.Keys;
import org.b3log.latke.model.User;
import org.b3log.solo.AbstractTestCase;
import org.b3log.solo.model.Article;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

@Test(suiteName = "service")
public class ArticleQueryServiceTestCase extends AbstractTestCase {

    @Test
    public void getRecentArticles() throws Exception {
        final ArticleQueryService articleQueryService = getArticleQueryService();
        final List<JSONObject> articles = articleQueryService.getRecentArticles(10);

        System.out.print("Size of recent articles:"+articles.size());
        Assert.assertEquals(articles.size(), 10);
    }

    @Test
    public void getArticle() throws Exception {
        final ArticleQueryService articleQueryService = getArticleQueryService();
        final String articleId = "1496403611354";
        final JSONObject article = articleQueryService.getArticle(articleId);

        System.out.print(article.getJSONObject("article").get("articleTitle"));
        Assert.assertNotNull(article);
        //Assert.assertEquals(article.optString(Article.ARTICLE_VIEW_COUNT), "");
    }

   
    @Test
    public void getArticleById() throws Exception {
        final ArticleQueryService articleQueryService = getArticleQueryService();
        final List<JSONObject> articles = articleQueryService.getRecentArticles(5);

        Assert.assertEquals(articles.size(), 1);

        final String articleId = articles.get(0).getString(Keys.OBJECT_ID);
        final JSONObject article = articleQueryService.getArticleById(articleId);

        Assert.assertNotNull(article);
        Assert.assertNotNull(article.getString(Article.ARTICLE_VIEW_COUNT), "");
    }

    @Test
    public void getArticleContent() throws Exception {
        final ArticleQueryService articleQueryService = getArticleQueryService();
        final String articleId = "";

        Assert.assertNotNull(articleQueryService.getArticleContent(null, articleId));
    }

 
    @Test
    public void getArticlesByTag() throws Exception {
        final TagQueryService tagQueryService = getTagQueryService();
        final String tagId = "1496419869310";

        final ArticleQueryService articleQueryService = getArticleQueryService();
        
        final List<JSONObject> articles = articleQueryService.getArticlesByTag(tagId, 2, 6);
        //System.out.print(articles);
        Assert.assertNotNull(articles);
        System.out.print("size: "+ articles.size());
        Assert.assertEquals(articles.size(), 6);
    }
}
