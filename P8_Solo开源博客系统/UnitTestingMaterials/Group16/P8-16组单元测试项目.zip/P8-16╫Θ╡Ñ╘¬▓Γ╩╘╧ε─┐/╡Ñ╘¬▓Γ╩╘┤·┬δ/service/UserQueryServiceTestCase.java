package org.b3log.solo.service;

import junit.framework.Assert;
import org.b3log.latke.model.User;
import org.b3log.latke.util.Requests;
import org.b3log.solo.AbstractTestCase;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;


@Test(suiteName = "service")
public class UserQueryServiceTestCase extends AbstractTestCase {

    @Test
    public void addUser() throws Exception {
        final UserMgmtService userMgmtService = getUserMgmtService();

        final JSONObject requestJSONObject = new JSONObject();

        requestJSONObject.put(User.USER_NAME, "user1 name");
        requestJSONObject.put(User.USER_EMAIL, "test1@gmail.com");
        requestJSONObject.put(User.USER_PASSWORD, "pass1");

        final String id = userMgmtService.addUser(requestJSONObject);
        Assert.assertNotNull(id);

        final UserQueryService userQueryService = getUserQueryService();
        Assert.assertNotNull(userQueryService.getUser(id));
    }

    

    @Test(dependsOnMethods = "addUser")
    public void getUser() throws Exception {
        final UserQueryService userQueryService = getUserQueryService();
        Assert.assertNull(userQueryService.getUser("not found"));
    }

    @Test(dependsOnMethods = "addUser")
    public void getUserByEmail() throws Exception {
        final UserQueryService userQueryService = getUserQueryService();

        final JSONObject user = userQueryService.getUserByEmail("test1@gmail.com");
        Assert.assertNotNull(user);
    }

    /
    @Test(dependsOnMethods = "addUser")
    public void getUsers() throws Exception {
        final UserQueryService userQueryService = getUserQueryService();

        final JSONObject paginationRequest = Requests.buildPaginationRequest("1/20/10");
        final JSONObject result = userQueryService.getUsers(paginationRequest);
        final JSONArray users = result.getJSONArray(User.USERS);
        Assert.assertEquals(1, users.length());
    }

   
}
