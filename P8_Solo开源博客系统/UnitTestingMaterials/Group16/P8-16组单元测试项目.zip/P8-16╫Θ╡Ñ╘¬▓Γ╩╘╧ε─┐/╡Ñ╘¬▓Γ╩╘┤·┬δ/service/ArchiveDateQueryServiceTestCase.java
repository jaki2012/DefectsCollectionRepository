package org.b3log.solo.service;

import org.b3log.latke.model.User;
import org.b3log.solo.AbstractTestCase;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class ArchiveDateQueryServiceTestCase extends AbstractTestCase {

   
    @Test
    public void getArchiveDates() throws Exception {
        final ArchiveDateQueryService archiveDateQueryService = getArchiveDateQueryService();

        final List<JSONObject> archiveDates = archiveDateQueryService.getArchiveDates();

        Assert.assertNotNull(archiveDates);
        Assert.assertEquals(archiveDates.size(), 1);
    }

    @Test
    public void getByArchiveDateString() throws Exception {
        final ArchiveDateQueryService archiveDateQueryService = getArchiveDateQueryService();

        
        System.out.print(archiveDateString);
        final String archiveDateString = "2017/6";
        //System.out.print(archiveDateString);
        final JSONObject result = archiveDateQueryService.getByArchiveDateString(archiveDateString);
        System.out.print(result);
        Assert.assertNotNull(result);
        
    }
}
