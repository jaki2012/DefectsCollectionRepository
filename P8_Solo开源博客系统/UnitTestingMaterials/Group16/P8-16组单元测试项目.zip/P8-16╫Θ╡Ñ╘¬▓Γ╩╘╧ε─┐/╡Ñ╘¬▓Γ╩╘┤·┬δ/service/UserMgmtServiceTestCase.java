package org.b3log.solo.service;

import junit.framework.Assert;
import org.b3log.latke.Keys;
import org.b3log.latke.model.Role;
import org.b3log.latke.model.User;
import org.b3log.latke.util.MD5;
import org.b3log.solo.AbstractTestCase;
import org.json.JSONObject;
import org.testng.annotations.Test;

@Test(suiteName = "service")
public class UserMgmtServiceTestCase extends AbstractTestCase {

    @Test
    public void addUser() throws Exception {
        final UserMgmtService userMgmtService = getUserMgmtService();

        final JSONObject requestJSONObject = new JSONObject();

        requestJSONObject.put(User.USER_NAME, "张三");
        requestJSONObject.put(User.USER_EMAIL, "z3@gmail.com");
        requestJSONObject.put(User.USER_PASSWORD, "1234");

        final String id = userMgmtService.addUser(requestJSONObject);
        Assert.assertNotNull(id);
    }

    @Test
    public void updateUser() throws Exception {
        final UserMgmtService userMgmtService = getUserMgmtService();
        final String id = userMgmtService.addUser(requestJSONObject);
        Assert.assertNotNull(id);

        requestJSONObject.put(Keys.OBJECT_ID, id);
        requestJSONObject.put(User.USER_NAME, "user2newname");

        userMgmtService.updateUser(requestJSONObject);

        Assert.assertEquals(getUserQueryService().getUser(id).getJSONObject(
                User.USER).getString(User.USER_NAME), "user2newname");
        requestJSONObject.put(Keys.OBJECT_ID, id);
        requestJSONObject.put(User.USER_NAME, "user2name");
        requestJSONObject.put(User.USER_EMAIL, "test2@gmail.com");
        requestJSONObject.put(User.USER_PASSWORD, "pass2");

        userMgmtService.updateUser(requestJSONObject);

        Assert.assertEquals(getUserQueryService().getUser(id).getJSONObject(
                User.USER).getString(User.USER_PASSWORD), MD5.hash("pass2"));
    }

   
    @Test
    public void removeUser() throws Exception {
        final UserMgmtService userMgmtService = getUserMgmtService();

        final userId = "9080813753";
        userMgmtService.removeUser(userId);

        Assert.assertNull(
                getUserQueryService().getUserByEmail("test1@gmail.com"));
    }
}
