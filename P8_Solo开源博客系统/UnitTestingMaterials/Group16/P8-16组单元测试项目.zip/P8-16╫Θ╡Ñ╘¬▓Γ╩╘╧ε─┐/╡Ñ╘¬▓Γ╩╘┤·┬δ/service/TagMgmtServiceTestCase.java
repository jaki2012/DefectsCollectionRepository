package org.b3log.solo.service;

import org.b3log.latke.model.User;
import org.b3log.solo.AbstractTestCase;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

@Test(suiteName = "service")
public class TagMgmtServiceTestCase extends AbstractTestCase {

    @Test
    public void removeUnusedTags() throws Exception {
        final TagMgmtService tagMgmtService = getTagMgmtService();

        tagMgmtService.removeUnusedTags();
    }
}
