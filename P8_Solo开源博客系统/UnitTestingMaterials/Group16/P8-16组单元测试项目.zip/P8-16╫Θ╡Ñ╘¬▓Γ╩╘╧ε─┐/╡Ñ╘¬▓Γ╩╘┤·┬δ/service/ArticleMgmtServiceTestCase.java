package org.b3log.solo.service;

import org.b3log.latke.Keys;
import org.b3log.latke.model.User;
import org.b3log.latke.util.Requests;
import org.b3log.solo.AbstractTestCase;
import org.b3log.solo.model.Article;
import org.b3log.solo.model.Common;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

@Test(suiteName = "service")
public class ArticleMgmtServiceTestCase extends AbstractTestCase {

    @Test
    public void addArticle() throws Exception {
        final ArticleMgmtService articleMgmtService = getArticleMgmtService();

        final JSONObject requestJSONObject = new JSONObject();
        final JSONObject article = new JSONObject();
        requestJSONObject.put(Article.ARTICLE, article);

        //输入变量
        article.put(Article.ARTICLE_AUTHOR_EMAIL, "test1@gmail.com");
        article.put(Article.ARTICLE_TITLE, "中国近代史纲要");
        article.put(Article.ARTICLE_ABSTRACT, "ABSTRACT");
        article.put(Article.ARTICLE_CONTENT, "CONTENT");
        article.put(Article.ARTICLE_TAGS_REF, "solo, tag2, tag3");
        article.put(Article.ARTICLE_PERMALINK, "article permalink");
        article.put(Article.ARTICLE_IS_PUBLISHED, true);
        article.put(Common.POST_TO_COMMUNITY, true);
        article.put(Article.ARTICLE_SIGN_ID, "1");
        article.put(Article.ARTICLE_COMMENTABLE, true);
        article.put(Article.ARTICLE_VIEW_PWD, "");

        final String articleId = articleMgmtService.addArticle(requestJSONObject);

        Assert.assertNotNull(articleId);
    }

   

    @Test
    public void updateArticle() throws Exception {
        final ArticleMgmtService articleMgmtService = getArticleMgmtService();

        final JSONObject requestJSONObject = new JSONObject();
        final JSONObject article = new JSONObject();
        requestJSONObject.put(Article.ARTICLE, article);

        article.put(Article.ARTICLE_AUTHOR_EMAIL, "test1@gmail.com");
        article.put(Article.ARTICLE_TITLE, "article2 title");
        article.put(Article.ARTICLE_ABSTRACT, "article2 abstract");
        article.put(Article.ARTICLE_CONTENT, "article2 content");
        article.put(Article.ARTICLE_TAGS_REF, "tag1, tag2, tag3");
        article.put(Article.ARTICLE_PERMALINK, "article2 permalink");
        article.put(Article.ARTICLE_IS_PUBLISHED, true);
        article.put(Common.POST_TO_COMMUNITY, true);
        article.put(Article.ARTICLE_SIGN_ID, "1");
        article.put(Article.ARTICLE_COMMENTABLE, true);
        article.put(Article.ARTICLE_VIEW_PWD, "");

        final String articleId = articleMgmtService.addArticle(requestJSONObject);

        Assert.assertNotNull(articleId);

        article.put(Keys.OBJECT_ID, articleId);
        article.put(Article.ARTICLE_TITLE, "updated article2 title");

        articleMgmtService.updateArticle(requestJSONObject);

        final ArticleQueryService articleQueryService = getArticleQueryService();
        final JSONObject updated = articleQueryService.getArticleById(articleId);
        System.out.print(articleId);
        System.out.print(updated);
        Assert.assertNotNull(updated);
        //Assert.assertEquals(updated.getString(Article.ARTICLE_TITLE), "updated article2 title");
    }


    @Test
    public void removeArticle() throws Exception {
        final ArticleMgmtService articleMgmtService = getArticleMgmtService();

        final JSONObject requestJSONObject = new JSONObject();
        final JSONObject article = new JSONObject();
        requestJSONObject.put(Article.ARTICLE, article);

        final String articleId = "";

        articleMgmtService.removeArticle(articleId);

        final ArticleQueryService articleQueryService = getArticleQueryService();
        final JSONObject updated = articleQueryService.getArticleById(articleId);
        Assert.assertNull(updated);
    }

 
    @Test
    public void topArticle() throws Exception {
        final ArticleMgmtService articleMgmtService = getArticleMgmtService();
        final ArticleQueryService articleQueryService = getArticleQueryService();
        final JSONObject paginationRequest = Requests.buildPaginationRequest("1/10/20");
        final JSONArray articles = articleQueryService.getArticles(paginationRequest).optJSONArray(Article.ARTICLES);

        Assert.assertNotEquals(articles.length(), 0);
        final JSONObject article = articles.getJSONObject(0);

        final String articleId = article.getString(Keys.OBJECT_ID);
        articleMgmtService.topArticle(articleId, true);
        articleMgmtService.topArticle(articleId, false);
    }

    @Test
    public void cancelPublishArticle() throws Exception {
        final ArticleMgmtService articleMgmtService = getArticleMgmtService();

        final String articleId = "1496419869196";

        Assert.assertNotNull(articleId);

        final ArticleQueryService articleQueryService = getArticleQueryService();
        final JSONObject paginationRequest = Requests.buildPaginationRequest("1/10/20");
        JSONArray articles = articleQueryService.getArticles(paginationRequest).optJSONArray(Article.ARTICLES);

        int articleCount = articles.length();
        Assert.assertNotEquals(articleCount, 0);
    }

    @Test
    public void updateArticlesRandomValue() throws Exception {
        final ArticleMgmtService articleMgmtService = getArticleMgmtService();
        final ArticleQueryService articleQueryService = getArticleQueryService();

        List<JSONObject> articles = articleQueryService.getRecentArticles(10);
        //Assert.assertNotEquals(articles.size(), 0);

        final JSONObject article = articles.get(0);
        final String articleId = article.getString(Keys.OBJECT_ID);
        double randomValue = article.getDouble(Article.ARTICLE_RANDOM_DOUBLE);
        articleMgmtService.updateArticlesRandomValue(Integer.MAX_VALUE);

        //Assert.assertNotEquals(articleQueryService.getArticleById(articleId).
         //       getDouble(Article.ARTICLE_RANDOM_DOUBLE), randomValue);
    }
}
