package org.b3log.solo;

import org.b3log.latke.Latkes;
import org.b3log.latke.ioc.LatkeBeanManager;
import org.b3log.latke.ioc.Lifecycle;
import org.b3log.latke.ioc.config.Discoverer;
import org.b3log.latke.repository.jdbc.util.Connections;
import org.b3log.solo.api.metaweblog.MetaWeblogAPI;
import org.b3log.solo.repository.*;
import org.b3log.solo.repository.impl.*;
import org.b3log.solo.service.*;
import org.testng.annotations.BeforeClass;

import java.sql.Connection;
import java.util.Collection;
import java.util.Locale;

public abstract class AbstractTestCase {

    private LatkeBeanManager beanManager;

    @BeforeClass
    public void beforeClass() throws Exception {
        Latkes.initRuntimeEnv();
        Latkes.setLocale(Locale.SIMPLIFIED_CHINESE);

        final Collection<Class<?>> classes = Discoverer.discover("org.b3log.solo");
        Lifecycle.startApplication(classes);
        beanManager = Lifecycle.getBeanManager();

        final Connection connection = Connections.getConnection();
        
        connection.close();

    }
