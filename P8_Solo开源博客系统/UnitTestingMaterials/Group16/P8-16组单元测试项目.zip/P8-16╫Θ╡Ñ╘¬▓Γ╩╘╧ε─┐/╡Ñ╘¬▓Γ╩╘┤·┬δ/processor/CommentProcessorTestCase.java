package org.b3log.solo.processor;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.lang.StringUtils;
import org.b3log.latke.model.User;
import org.b3log.latke.service.ServiceException;
import org.b3log.solo.AbstractTestCase;
import org.b3log.solo.model.Article;
import org.b3log.solo.model.Common;
import org.b3log.solo.model.Page;
import org.b3log.solo.service.ArticleMgmtService;
import org.b3log.solo.service.InitService;
import org.b3log.solo.service.PageMgmtService;
import org.b3log.solo.service.UserQueryService;
import org.json.JSONObject;
import static org.mockito.Mockito.*;
import org.testng.Assert;
import org.testng.annotations.Test;

@Test(suiteName = "processor")
public class CommentProcessorTestCase extends AbstractTestCase {
    //添加对页面的评论
    @Test
    public void addPageComment() throws Exception {
        final HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getServletContext()).thenReturn(mock(ServletContext.class));
        when(request.getRequestURI()).thenReturn("/add-page-comment.do");
        when(request.getMethod()).thenReturn("POST");

        final HttpSession session = mock(HttpSession.class);
        when(session.getAttribute(CaptchaProcessor.CAPTCHA)).thenReturn("captcha123456");
        when(request.getSession(false)).thenReturn(session);

        //输入变量
        final String pageId = "1";

        final JSONObject requestJSON = new JSONObject();
        requestJSON.put("captcha", "captcha123456");
        requestJSON.put("oId", pageId);
        requestJSON.put("commentName", "88250");
        requestJSON.put("commentEmail", "user@qq.com");
        requestJSON.put("commentURL", "https://hacpai.com");
        requestJSON.put("commentContent", "测试评论");

        final BufferedReader reader = new BufferedReader(new StringReader(requestJSON.toString()));
        when(request.getReader()).thenReturn(reader);

        final MockDispatcherServlet dispatcherServlet = new MockDispatcherServlet();
        dispatcherServlet.init();

        final StringWriter stringWriter = new StringWriter();
        final PrintWriter printWriter = new PrintWriter(stringWriter);

        final HttpServletResponse response = mock(HttpServletResponse.class);
        when(response.getWriter()).thenReturn(printWriter);

        dispatcherServlet.service(request, response);

        final String content = stringWriter.toString();
        Assert.assertTrue(StringUtils.contains(content, "\"sc\":true"));
    }

    //添加对文章的评论
    @Test
    public void addArticleComment() throws Exception {
        final HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getServletContext()).thenReturn(mock(ServletContext.class));
        when(request.getRequestURI()).thenReturn("/add-article-comment.do");
        when(request.getMethod()).thenReturn("POST");

        final HttpSession session = mock(HttpSession.class);
        when(session.getAttribute(CaptchaProcessor.CAPTCHA)).thenReturn("captcha123456");
        when(request.getSession(false)).thenReturn(session);

        //输入变量
        final String articleId = "";

        final JSONObject requestJSON = new JSONObject();
        requestJSON.put("captcha", "captcha123456");
        requestJSON.put("oId", articleId);
        requestJSON.put("commentName", "good");
        requestJSON.put("commentEmail", "user@qq.com");
        requestJSON.put("commentURL", "https://hacpai.com");
        requestJSON.put("commentContent", "测试评论");

        final BufferedReader reader = new BufferedReader(new StringReader(requestJSON.toString()));
        when(request.getReader()).thenReturn(reader);

        final MockDispatcherServlet dispatcherServlet = new MockDispatcherServlet();
        dispatcherServlet.init();

        final StringWriter stringWriter = new StringWriter();
        final PrintWriter printWriter = new PrintWriter(stringWriter);

        final HttpServletResponse response = mock(HttpServletResponse.class);
        when(response.getWriter()).thenReturn(printWriter);

        dispatcherServlet.service(request, response);

        final String content = stringWriter.toString();
        Assert.assertTrue(StringUtils.contains(content, "\"sc\":true"));
    }

}
