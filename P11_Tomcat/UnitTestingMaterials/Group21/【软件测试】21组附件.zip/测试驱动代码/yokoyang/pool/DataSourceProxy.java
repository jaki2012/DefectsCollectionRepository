package cases.yokoyang.pool;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.Iterator;
import java.util.Properties;
import java.util.concurrent.Future;
import java.util.logging.Logger;

import javax.sql.XAConnection;
import javax.xml.validation.Validator;

import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import sun.jdbc.odbc.ee.ConnectionPool;

/**
 * Created by 13987 on 2017/5/29.
 */

public class DataSourceProxy implements PoolConfiguration {
    private static final Log log = LogFactory.getLog(DataSourceProxy.class);

    protected volatile ConnectionPool pool = null;

    protected volatile PoolConfiguration poolProperties = null;

    public DataSourceProxy() {
        this(new PoolProperties());
    }

    public DataSourceProxy(PoolConfiguration poolProperties) {
        if (poolProperties == null) throw new NullPointerException("PoolConfiguration cannot be null.");
        this.poolProperties = poolProperties;
    }


    @Override
    public void setValidator(Validator validator) {

    }

    @Override
    public void setAbandonWhenPercentageFull(int percentage) {

    }

    @Override
    public int getAbandonWhenPercentageFull() {
        return 0;
    }

    @Override
    public boolean isFairQueue() {
        return false;
    }

    @Override
    public void setFairQueue(boolean fairQueue) {

    }

    @Override
    public boolean isAccessToUnderlyingConnectionAllowed() {
        return false;
    }

    @Override
    public void setAccessToUnderlyingConnectionAllowed(boolean accessToUnderlyingConnectionAllowed) {

    }

    @Override
    public String getConnectionProperties() {
        return null;
    }

    @Override
    public void setConnectionProperties(String connectionProperties) {

    }

    @Override
    public Properties getDbProperties() {
        return null;
    }

    @Override
    public void setDbProperties(Properties dbProperties) {

    }

    @Override
    public Boolean isDefaultAutoCommit() {
        return null;
    }

    @Override
    public Boolean getDefaultAutoCommit() {
        return null;
    }

    @Override
    public void setDefaultAutoCommit(Boolean defaultAutoCommit) {

    }

    @Override
    public String getDefaultCatalog() {
        return null;
    }

    @Override
    public void setDefaultCatalog(String defaultCatalog) {

    }

    @Override
    public Boolean isDefaultReadOnly() {
        return null;
    }

    @Override
    public Boolean getDefaultReadOnly() {
        return null;
    }

    @Override
    public void setDefaultReadOnly(Boolean defaultReadOnly) {

    }

    @Override
    public int getDefaultTransactionIsolation() {
        return 0;
    }

    @Override
    public void setDefaultTransactionIsolation(int defaultTransactionIsolation) {

    }

    @Override
    public String getDriverClassName() {
        return null;
    }

    @Override
    public void setDriverClassName(String driverClassName) {

    }

    @Override
    public int getInitialSize() {
        return 0;
    }

    @Override
    public void setInitialSize(int initialSize) {

    }

    @Override
    public boolean isLogAbandoned() {
        return false;
    }

    @Override
    public void setLogAbandoned(boolean logAbandoned) {

    }

    @Override
    public int getMaxActive() {
        return 0;
    }

    @Override
    public void setMaxActive(int maxActive) {

    }

    @Override
    public int getMaxIdle() {
        return 0;
    }

    @Override
    public void setMaxIdle(int maxIdle) {

    }

    @Override
    public int getMaxWait() {
        return 0;
    }

    @Override
    public void setMaxWait(int maxWait) {

    }

    @Override
    public int getMinEvictableIdleTimeMillis() {
        return 0;
    }

    @Override
    public void setMinEvictableIdleTimeMillis(int minEvictableIdleTimeMillis) {

    }

    @Override
    public int getMinIdle() {
        return 0;
    }

    @Override
    public void setMinIdle(int minIdle) {

    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public void setName(String name) {

    }

    @Override
    public int getNumTestsPerEvictionRun() {
        return 0;
    }

    @Override
    public void setNumTestsPerEvictionRun(int numTestsPerEvictionRun) {

    }

    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public void setPassword(String password) {

    }

    @Override
    public String getPoolName() {
        return null;
    }

    @Override
    public String getUsername() {
        return null;
    }

    @Override
    public void setUsername(String username) {

    }

    @Override
    public boolean isRemoveAbandoned() {
        return false;
    }

    @Override
    public void setRemoveAbandoned(boolean removeAbandoned) {

    }

    @Override
    public void setRemoveAbandonedTimeout(int removeAbandonedTimeout) {

    }

    @Override
    public int getRemoveAbandonedTimeout() {
        return 0;
    }

    @Override
    public boolean isTestOnBorrow() {
        return false;
    }

    @Override
    public void setTestOnBorrow(boolean testOnBorrow) {

    }

    @Override
    public boolean isTestOnReturn() {
        return false;
    }

    @Override
    public void setTestOnReturn(boolean testOnReturn) {

    }

    @Override
    public boolean isTestWhileIdle() {
        return false;
    }

    @Override
    public void setTestWhileIdle(boolean testWhileIdle) {

    }

    @Override
    public int getTimeBetweenEvictionRunsMillis() {
        return 0;
    }

    @Override
    public void setTimeBetweenEvictionRunsMillis(int timeBetweenEvictionRunsMillis) {

    }

    @Override
    public String getUrl() {
        return null;
    }

    @Override
    public void setUrl(String url) {

    }

    @Override
    public String getValidationQuery() {
        return null;
    }

    @Override
    public void setValidationQuery(String validationQuery) {

    }

    @Override
    public int getValidationQueryTimeout() {
        return 0;
    }

    @Override
    public void setValidationQueryTimeout(int validationQueryTimeout) {

    }

    @Override
    public String getValidatorClassName() {
        return null;
    }

    @Override
    public void setValidatorClassName(String className) {

    }

    @Override
    public Validator getValidator() {
        return null;
    }

    @Override
    public long getValidationInterval() {
        return 0;
    }

    @Override
    public void setValidationInterval(long validationInterval) {

    }

    @Override
    public String getInitSQL() {
        return null;
    }

    @Override
    public void setInitSQL(String initSQL) {

    }

    @Override
    public boolean isTestOnConnect() {
        return false;
    }

    @Override
    public void setTestOnConnect(boolean testOnConnect) {

    }

    @Override
    public String getJdbcInterceptors() {
        return null;
    }

    @Override
    public void setJdbcInterceptors(String jdbcInterceptors) {

    }

    @Override
    public PoolProperties.InterceptorDefinition[] getJdbcInterceptorsAsArray() {
        return new PoolProperties.InterceptorDefinition[0];
    }

    @Override
    public boolean isJmxEnabled() {
        return false;
    }

    @Override
    public void setJmxEnabled(boolean jmxEnabled) {

    }

    @Override
    public boolean isPoolSweeperEnabled() {
        return false;
    }

    @Override
    public boolean isUseEquals() {
        return false;
    }

    @Override
    public void setUseEquals(boolean useEquals) {

    }

    @Override
    public long getMaxAge() {
        return 0;
    }

    @Override
    public void setMaxAge(long maxAge) {

    }

    @Override
    public boolean getUseLock() {
        return false;
    }

    @Override
    public void setUseLock(boolean useLock) {

    }

    @Override
    public void setSuspectTimeout(int seconds) {

    }

    @Override
    public int getSuspectTimeout() {
        return 0;
    }

    @Override
    public void setDataSource(Object ds) {

    }

    @Override
    public Object getDataSource() {
        return null;
    }

    @Override
    public void setDataSourceJNDI(String jndiDS) {

    }

    @Override
    public String getDataSourceJNDI() {
        return null;
    }

    @Override
    public boolean isAlternateUsernameAllowed() {
        return false;
    }

    @Override
    public void setAlternateUsernameAllowed(boolean alternateUsernameAllowed) {

    }

    @Override
    public void setCommitOnReturn(boolean commitOnReturn) {

    }

    @Override
    public boolean getCommitOnReturn() {
        return false;
    }

    @Override
    public void setRollbackOnReturn(boolean rollbackOnReturn) {

    }

    @Override
    public boolean getRollbackOnReturn() {
        return false;
    }

    @Override
    public void setUseDisposableConnectionFacade(boolean useDisposableConnectionFacade) {

    }

    @Override
    public boolean getUseDisposableConnectionFacade() {
        return false;
    }

    @Override
    public void setLogValidationErrors(boolean logValidationErrors) {

    }

    @Override
    public boolean getLogValidationErrors() {
        return false;
    }

    @Override
    public boolean getPropagateInterruptState() {
        return false;
    }

    @Override
    public void setPropagateInterruptState(boolean propagateInterruptState) {

    }

    @Override
    public void setIgnoreExceptionOnPreLoad(boolean ignoreExceptionOnPreLoad) {

    }

    @Override
    public boolean isIgnoreExceptionOnPreLoad() {
        return false;
    }

    @Override
    public void setUseStatementFacade(boolean useStatementFacade) {

    }

    @Override
    public boolean getUseStatementFacade() {
        return false;
    }

    public ConnectionPool getPool() {
        try {
            return createPool();
        } catch (SQLException x) {
            log.error("Error during connection pool creation.", x);
            return null;
        }
    }

    public ConnectionPool createPool() throws SQLException {
        if (pool != null) {
            return pool;
        } else {
            return pCreatePool();
        }
    }

    private synchronized ConnectionPool pCreatePool() throws SQLException {
        return pool;
    }
}
