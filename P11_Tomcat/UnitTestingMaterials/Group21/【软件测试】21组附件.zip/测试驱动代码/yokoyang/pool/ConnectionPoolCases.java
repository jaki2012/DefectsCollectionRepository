package cases.yokoyang.pool;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import sun.jdbc.odbc.ee.ConnectionPool;
import org.apache.log4j.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by 13987 on 2017/5/29.
 */
@RunWith(Parameterized.class)
public class ConnectionPoolCases {
    private boolean fairQueue;
    public static final Logger logger = Logger.getLogger(ConnectionPoolCases.class);

    public ConnectionPoolCases(boolean fair) {
        this.fairQueue = fair;
    }

    @Parameterized.Parameters
    public static Collection<Object[]> parameters() {
        return Arrays.asList(new Object[][]{
                new Object[]{Boolean.TRUE},
                new Object[]{Boolean.FALSE},
        });
    }

    @Test
    public void testPool_successCon() throws SQLException, InterruptedException {
        DriverManager.setLoginTimeout(1);
        PoolProperties poolProperties = new PoolProperties();
        int threadsCount = 3;
        poolProperties.setMaxActive(threadsCount);
        poolProperties.setMaxIdle(threadsCount);
        poolProperties.setMinIdle(0);
        poolProperties.setMaxWait(5000);
        poolProperties.setInitialSize(0);
        poolProperties.setRemoveAbandoned(true);
        poolProperties.setRemoveAbandonedTimeout(300);
        poolProperties.setRollbackOnReturn(true);
        poolProperties.setFairQueue(fairQueue);
        final DataSource ds = new DataSource(poolProperties);

        final CountDownLatch openedLatch = new CountDownLatch(threadsCount);
        final CountDownLatch closedLatch = new CountDownLatch(threadsCount);
        final CountDownLatch toCloseLatch = new CountDownLatch(1);

        for (int i = 0; i < threadsCount; i++) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Connection connection = ds.getConnection();
                        openedLatch.countDown();

                        toCloseLatch.await();
                        connection.close();

                        closedLatch.countDown();

                    } catch (Exception e) {
                        System.err.println("Step 1:" + e.getMessage());
                    }
                }
            }).start();
        }

        openedLatch.await();
        ConnectionPool pool = ds.getPool();
        //Now we have 3 initialized busy connections


        List<Thread> threads = new ArrayList<>();
        for (int i = 0; i < threadsCount; i++) {
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        ds.getConnection();
                    } catch (Exception e) {
                        System.err.println("Step 2:" + e.getMessage());
                    }
                }
            });
            thread.start();
            threads.add(thread);
        }

        for (Thread thread : threads) {
            thread.join();
        }


        toCloseLatch.countDown();
        closedLatch.await();

        //Here comes the bug! No more active connections and unable to establish new connections.


        final AtomicInteger failedCount = new AtomicInteger();
        final ArrayBlockingQueue<Connection> cons = new ArrayBlockingQueue<>(threadsCount);
        threads.clear();
        for (int i = 0; i < threadsCount; i++) {
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                }
            });
            thread.start();
            threads.add(thread);
        }

        for (Thread thread : threads) {
            thread.join();
        }
        Assert.assertEquals(0, failedCount.get());

        Assert.assertEquals(0, pool.getName());
        Assert.assertEquals(threadsCount, pool.getTracer());
        Assert.assertEquals(threadsCount, pool.getCurrentSize());
        for (Connection con : cons) {
            con.close();
        }

    }

    @Test
    public void testPool_apply() throws SQLException, InterruptedException {
        DriverManager.setLoginTimeout(1);
        PoolProperties poolProperties = new PoolProperties();
        int threadsCount = 2;
        poolProperties.setMaxActive(threadsCount);
        poolProperties.setMaxIdle(threadsCount);
        poolProperties.setMinIdle(0);
        poolProperties.setMaxWait(5000);
        poolProperties.setInitialSize(0);
        poolProperties.setRemoveAbandoned(true);
        poolProperties.setRemoveAbandonedTimeout(300);
        poolProperties.setRollbackOnReturn(true);
        poolProperties.setFairQueue(fairQueue);
        final DataSource ds = new DataSource(poolProperties);

        final CountDownLatch openedLatch = new CountDownLatch(threadsCount);
        final CountDownLatch closedLatch = new CountDownLatch(threadsCount);
        final CountDownLatch toCloseLatch = new CountDownLatch(1);

        for (int i = 0; i < threadsCount + 1; i++) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Connection connection = ds.getConnection();
                        openedLatch.countDown();

                        toCloseLatch.await();
                        connection.close();

                        closedLatch.countDown();

                    } catch (Exception e) {
                        System.err.println("Step 1:" + e.getMessage());
                    }
                }
            }).start();
        }

        openedLatch.await();
        ConnectionPool pool = ds.getPool();
        //Now we have 3 initialized busy connections


        List<Thread> threads = new ArrayList<>();
        for (int i = 0; i < threadsCount; i++) {
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        ds.getConnection();
                    } catch (Exception e) {
                        System.err.println("Step 2:" + e.getMessage());
                    }
                }
            });
            thread.start();
            threads.add(thread);
        }
        for (Thread thread : threads) {
            thread.interrupt();
        }
        for (Thread thread : threads) {
            thread.join();
        }


        toCloseLatch.countDown();
        closedLatch.await();

        //Here comes the bug! No more active connections and unable to establish new connections.


        final AtomicInteger failedCount = new AtomicInteger();
        final ArrayBlockingQueue<Connection> cons = new ArrayBlockingQueue<>(threadsCount);
        threads.clear();
        for (int i = 0; i < threadsCount; i++) {
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                }
            });
            thread.start();
            threads.add(thread);
        }

        for (Thread thread : threads) {
            thread.join();
        }
        Assert.assertEquals(0, failedCount.get());

        Assert.assertEquals(0, pool.getName());
        Assert.assertEquals(threadsCount, pool.getTracer());
        Assert.assertEquals(threadsCount, pool.getCurrentSize());
        for (Connection con : cons) {
            con.close();
        }
    }

    @Test
    public void testPool_midway() throws SQLException, InterruptedException {
        DriverManager.setLoginTimeout(1);
        PoolProperties poolProperties = new PoolProperties();
        int threadsCount = 3;
        poolProperties.setMaxActive(threadsCount);
        poolProperties.setMaxIdle(threadsCount);
        poolProperties.setMinIdle(0);
        poolProperties.setMaxWait(5000);
        poolProperties.setInitialSize(0);
        poolProperties.setRemoveAbandoned(true);
        poolProperties.setRemoveAbandonedTimeout(300);
        poolProperties.setRollbackOnReturn(true);
        poolProperties.setFairQueue(fairQueue);
        final DataSource ds = new DataSource(poolProperties);
        ds.getConnection();
        final CountDownLatch openedLatch = new CountDownLatch(threadsCount);
        final CountDownLatch closedLatch = new CountDownLatch(threadsCount);
        final CountDownLatch toCloseLatch = new CountDownLatch(1);

        for (int i = 0; i < threadsCount; i++) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Connection connection = ds.getConnection();
                        openedLatch.countDown();

                        toCloseLatch.await();
                        connection.close();

                        closedLatch.countDown();

                    } catch (Exception e) {
                        logger.error("Exception caught in test " + "DN-21-00103" + ":", e);
                        return;
//                        System.err.println("Step 1:" + e.getMessage());
                    }
                }
            }).start();
        }

        openedLatch.await();
        ConnectionPool pool = ds.getPool();
        //Now we have 3 initialized busy connections


        List<Thread> threads = new ArrayList<>();
        for (int i = 0; i < threadsCount; i++) {
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        ds.getConnection();
                    } catch (Exception e) {
                        System.err.println("Step 2:" + e.getMessage());
                    }
                }
            });
            thread.start();
            threads.add(thread);
        }
        for (Thread thread : threads) {
            thread.interrupt();
        }
        for (Thread thread : threads) {
            thread.join();
        }


        toCloseLatch.countDown();
        closedLatch.await();

        //Here comes the bug! No more active connections and unable to establish new connections.


        final AtomicInteger failedCount = new AtomicInteger();
        final ArrayBlockingQueue<Connection> cons = new ArrayBlockingQueue<>(threadsCount);
        threads.clear();
        for (int i = 0; i < threadsCount; i++) {
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                }
            });
            thread.start();
            threads.add(thread);
        }

        for (Thread thread : threads) {
            thread.join();
        }
        Assert.assertEquals(0, failedCount.get());

        Assert.assertEquals(0, pool.getName());
        Assert.assertEquals(threadsCount, pool.getTracer());
        Assert.assertEquals(threadsCount, pool.getCurrentSize());
        for (Connection con : cons) {
            con.close();
        }
    }
}
