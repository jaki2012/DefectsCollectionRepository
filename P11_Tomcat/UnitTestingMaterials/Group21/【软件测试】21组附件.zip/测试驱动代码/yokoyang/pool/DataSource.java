package cases.yokoyang.pool;

/**
 * Created by 13987 on 2017/5/29.
 */

import java.io.PrintWriter;
import java.lang.management.ManagementFactory;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.Hashtable;
import java.util.logging.Logger;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanRegistration;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.sql.ConnectionPoolDataSource;
import javax.sql.PooledConnection;

import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import sun.jdbc.odbc.ee.ConnectionPool;

public class DataSource extends DataSourceProxy implements javax.sql.DataSource, MBeanRegistration, ConnectionPoolMBean, ConnectionPoolDataSource {
    private static final Log log = LogFactory.getLog(DataSource.class);
    protected volatile ObjectName oname = null;

    public DataSource() {
    }

    public DataSource(PoolConfiguration poolProperties) {
        super(poolProperties);
    }

    public void postDeregister() {
        if (this.oname != null) {
            this.unregisterJmx();
        }

    }

    public void postRegister(Boolean registrationDone) {
    }

    public void preDeregister() throws Exception {
    }

    public ObjectName preRegister(MBeanServer server, ObjectName name) throws Exception {
        try {
            if (this.isJmxEnabled()) {
                this.oname = this.createObjectName(name);
                if (this.oname != null) {
                    this.registerJmx();
                }
            }
        } catch (MalformedObjectNameException var4) {
            log.error("Unable to create object name for JDBC pool.", var4);
        }

        return name;
    }

    public ObjectName createObjectName(ObjectName original) throws MalformedObjectNameException {
        String domain = "tomcat.jdbc";
        Hashtable<String, String> properties = original.getKeyPropertyList();
        String origDomain = original.getDomain();
        properties.put("type", "ConnectionPool");
        properties.put("class", this.getClass().getName());
        if (original.getKeyProperty("path") != null || properties.get("context") != null) {
            properties.put("engine", origDomain);
        }

        ObjectName name = new ObjectName(domain, properties);
        return name;
    }

    protected void registerJmx() {


    }

    protected void unregisterJmx() {
        try {
            MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
            mbs.unregisterMBean(this.oname);
        } catch (InstanceNotFoundException var2) {
            ;
        } catch (Exception var3) {
            log.error("Unable to unregister JDBC pool with JMX", var3);
        }

    }

    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        return null;
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        return false;
    }

    @Override
    public PooledConnection getPooledConnection() throws SQLException {
        return null;
    }

    @Override
    public PooledConnection getPooledConnection(String user, String password) throws SQLException {
        return null;
    }

    @Override
    public Connection getConnection() throws SQLException {
        return null;
    }

    @Override
    public Connection getConnection(String username, String password) throws SQLException {
        return null;
    }

    @Override
    public PrintWriter getLogWriter() throws SQLException {
        return null;
    }

    @Override
    public void setLogWriter(PrintWriter out) throws SQLException {

    }

    @Override
    public void setLoginTimeout(int seconds) throws SQLException {

    }

    @Override
    public int getLoginTimeout() throws SQLException {
        return 0;
    }

    @Override
    public Logger getParentLogger() throws SQLFeatureNotSupportedException {
        return null;
    }

    @Override
    public int getSize() {
        return 0;
    }

    @Override
    public int getIdle() {
        return 0;
    }

    @Override
    public int getActive() {
        return 0;
    }

    @Override
    public int getNumIdle() {
        return 0;
    }

    @Override
    public int getNumActive() {
        return 0;
    }

    @Override
    public int getWaitCount() {
        return 0;
    }

    @Override
    public long getBorrowedCount() {
        return 0;
    }

    @Override
    public long getReturnedCount() {
        return 0;
    }

    @Override
    public long getCreatedCount() {
        return 0;
    }

    @Override
    public long getReleasedCount() {
        return 0;
    }

    @Override
    public long getReconnectedCount() {
        return 0;
    }

    @Override
    public long getRemoveAbandonedCount() {
        return 0;
    }

    @Override
    public long getReleasedIdleCount() {
        return 0;
    }

    @Override
    public void checkIdle() {

    }

    @Override
    public void checkAbandoned() {

    }

    @Override
    public void testIdle() {

    }

    @Override
    public void purge() {

    }

    @Override
    public void purgeOnReturn() {

    }

    @Override
    public void resetStats() {

    }
}
