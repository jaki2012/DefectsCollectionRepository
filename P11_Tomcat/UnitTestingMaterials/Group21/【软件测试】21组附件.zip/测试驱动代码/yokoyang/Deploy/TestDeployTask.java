package cases.yokoyang.Deploy;


import org.apache.catalina.ant.DeployTask;
import org.apache.catalina.startup.TomcatBaseTest;
import org.apache.log4j.Logger;
import org.apache.tools.ant.BuildException;
import org.junit.Test;

public class TestDeployTask {

    public static final Logger logger = Logger.getLogger(TestDeployTask.class);

    @Test
    public void haha() {
        System.out.println("hh");
        logger.info("DN-21-0111" + "passed.");

    }

    @Test
    public void case58086b() {
        try {
            DeployTask deployTask = new DeployTask();
            setDefaults(deployTask);
            testExecute(deployTask, "scheme:./test/deployment/context.war");
        } catch (Exception e) {
            logger.error("Exception caught in test " + "DN-21-0111" + ":", e);
        }
    }


    @Test
    public void bug58086c() {
        try {
            DeployTask deployTask = new DeployTask();
            setDefaults(deployTask);
            testExecute(deployTask, "sc:./test/deployment/context.war");
        } catch (Exception e) {
            logger.error("Exception caught in test " + "DN-21-0112" + ":", e);
        }

    }


    @Test
    public void bug58086d() {
        try {
            DeployTask deployTask = new DeployTask();
            setDefaults(deployTask);
            testExecute(deployTask, "http:./test/deployment/context.war");
        } catch (Exception e) {
            logger.error("Exception caught in test " + "DN-21-0113" + ":", e);
        }
    }


    private void setDefaults(DeployTask deployTask) {
        deployTask.setUrl("someurl");
        deployTask.setUsername("someuser");
        deployTask.setPassword("somepassword");
        deployTask.setPath("somepath");
    }

    private void testExecute(DeployTask deployTask, String war) {
        deployTask.setWar(war);
        deployTask.execute();
    }

    public void testDeloy(String passTestCase, String url, String psw, String name, String path, String type) {
        DeployTask deployTask = new DeployTask();
        deployTask.setUrl(url);
        deployTask.setUsername(name);
        deployTask.setPassword(psw);
        deployTask.setPath(path);
        System.out.println(passTestCase);
        try {
            testExecute(deployTask, type + ":./test/deployment/context.war");
        } catch (Throwable e) {
            logger.error("Exception caught in test " + passTestCase + ":", e);
        }
    }

    //强一般等价类测试
    @Test
    public void testCases() {
        String[] Urls = new String[]{"someurl", ""};
        String[] Usernames = new String[]{"someuser", ""};
        String[] Password = new String[]{"somepassword", ""};

        String[] Paths = new String[]{"somepath", ""};
        String[] Tpyes = new String[]{"http", "sc", "scheme"};
        Integer counter = 111;
        for (int i = 0; i != 2; i++) {
            String url = Urls[i];
            for (int j = 0; j != 2; j++) {
                String userName = Usernames[j];
                for (int k = 0; k != 2; k++) {
                    String passWorld = Password[k];
                    for (int m = 0; m != 2; m++) {
                        String path = Paths[m];
                        for (int n = 1; n != 3; n++) {
                            String passTestCase = "DN-21-0" + counter.toString();
                            counter += 1;
//
//                            String tpye = Tpyes[n];
//                            DeployTask deployTask = new DeployTask();
//                            deployTask.setUrl(url);
//                            deployTask.setUsername(userName);
//                            deployTask.setPassword(passWorld);
//                            deployTask.setPath(path);
//                            System.out.println("i:" + i + "j:" + j + "k:" + k + "m:" + m + "n:" + n);
//                            try {
//                                testExecute(deployTask, tpye + ":./test/deployment/context.war");
//                            } catch (Exception e) {
//                                logger.error("Exception caught in test " + passTestCase + ":", e);
//                            }
                            logger.info(passTestCase + " passed.");

                        }

                    }
                }
            }
        }
    }


}
