package cases.novemser.el.value;

/**
 * Project: apache-tomcat-7.0.0-src
 * Package: cases.novemser.el.value
 * Author:  Novemser
 * 2017/5/30
 */
public class TestBeanA {
    public int getIntegerVal() {
        return 10;
    }

    public String getStringVal() {
        return "Hello";
    }
}
