package com.github.sd4324530.fastweixin.api.entity;

/**
 * @author peiyu
 */
public class UpstreamMsgWeek extends UpstreamMsg {
}
