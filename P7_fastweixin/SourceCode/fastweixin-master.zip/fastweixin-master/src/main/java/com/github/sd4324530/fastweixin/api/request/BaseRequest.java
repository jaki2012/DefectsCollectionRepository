package com.github.sd4324530.fastweixin.api.request;

import com.github.sd4324530.fastweixin.api.entity.BaseModel;

/**
 * @author peiyu
 */
public class BaseRequest extends BaseModel {
}
