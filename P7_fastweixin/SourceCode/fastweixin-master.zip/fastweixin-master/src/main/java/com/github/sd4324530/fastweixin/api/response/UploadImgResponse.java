package com.github.sd4324530.fastweixin.api.response;

/**
 * @author Nottyjay
 */
public class UploadImgResponse extends BaseResponse {
    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
