// Copyright (C) 1998-2001 by Jason Hunter <jhunter_AT_acm_DOT_org>.
// All rights reserved.  Use of this class is limited.
// Please see the LICENSE for more information.

package com.baomidou.framework.upload.multipart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;

/**
 * A utility class to handle <code>multipart/form-data</code> requests, the kind
 * of requests that support file uploads. This class uses a "pull" model where
 * the reading of incoming files and parameters is controlled by the client
 * code, which allows incoming files to be stored into any
 * <code>OutputStream</code>. If you wish to use an API which resembles
 * <code>HttpServletRequest</code>, use the "push" model
 * <code>MultipartRequest</code> instead. It's an easy-to-use wrapper around
 * this class.
 * <p>
 * This class can receive arbitrarily large files (up to an artificial limit you
 * can set), and fairly efficiently too. It cannot handle nested data (multipart
 * content within multipart content). It <b>can</b> now with the latest release
 * handle internationalized content (such as non Latin-1 filenames).
 * <p>
 * It also optionally includes enhanced buffering and Content-Length limitation.
 * Buffering is only required if your servlet container is poorly implemented
 * (many are, including Tomcat 3.2), but it is generally recommended because it
 * will make a slow servlet container a lot faster, and will only make a fast
 * servlet container a little slower. Content-Length limiting is usually only
 * required if you find that your servlet is hanging trying to read the input
 * stram from the POST, and it is similarly recommended because it only has a
 * minimal impact on performance.
 * <p>
 * See the included upload.war for an example of how to use this class.
 * <p>
 * The full file upload specification is contained in experimental RFC 1867,
 * available at
 * <a href="http://www.ietf.org/rfc/rfc1867.txt"> http://www.ietf.org/rfc/
 * rfc1867.txt</a>.
 *
 * @see com.baomidou.framework.upload.cos.MultipartRequest
 *
 * @author Jason Hunter
 * @author Geoff Soutter
 * @version 1.13, 2004/09/01, added workaround if content-length is -1
 * @version 1.12, 2004/05/17, added trim on disposition
 * @version 1.11, 2002/11/01, added constructor that takes an encoding, to make
 *          sure chars are always read correctly
 * @version 1.10, 2002/11/01, added support for a preamble before the first
 *          boundary marker
 * @version 1.9, 2002/11/01, added support to parse odd Opera Content-Type
 * @version 1.8, 2002/11/01, added support for lynx with unquoted param vals
 * @version 1.7, 2002/04/30, fixed bug if a line was '\n' alone
 * @version 1.6, 2002/04/30, added better internationalization support, thanks
 *          to Changshin Lee
 * @version 1.5, 2002/04/30, added Opera header fix, thanks to Nic Ferrier
 * @version 1.4, 2001/03/23, added IE5 bug workaround supporting \n as line
 *          ending, thanks to Michael Alyn Miller
 * @version 1.3, 2001/01/22, added support for boundaries surrounded by quotes
 *          and content-disposition after content-type, thanks to Scott Stark
 * @version 1.2, 2001/01/22, getFilePath() support thanks to Stefan Eissing
 * @version 1.1, 2000/10/29, integrating old WebSphere fix
 * @version 1.0, 2000/10/27, initial revision
 */
public class MultipartParser {
    private static final String LOGGER_NAME="com.zhangfeng.framework";
    private static final Logger log = LoggerFactory.getLogger(LOGGER_NAME);

    /** input stream to read parts from */
	private ServletInputStream in;

	/** MIME boundary that delimits parts */
	private String boundary;

	/** reference to the last file part we returned */
	private FilePart lastFilePart;

	/** buffer for readLine method */
	private byte[] buf = new byte[8 * 1024];

	/** default encoding */
	private static String DEFAULT_ENCODING = "ISO-8859-1";

	/** preferred encoding */
	private String encoding = DEFAULT_ENCODING;

	/**
	 * Creates a <code>MultipartParser</code> from the specified request, which
	 * limits the upload size to the specified length, buffers for performance
	 * and prevent attempts to read past the amount specified by the
	 * Content-Length.
	 *
	 * @param req
	 *            the servlet request.
	 * @param maxSize
	 *            the maximum size of the POST content.
	 */
	public MultipartParser(HttpServletRequest req, int maxSize) throws IOException {
		this(req, maxSize, true, true);
	}

	/**
	 * Creates a <code>MultipartParser</code> from the specified request, which
	 * limits the upload size to the specified length, and optionally buffers
	 * for performance and prevents attempts to read past the amount specified
	 * by the Content-Length.
	 *
	 * @param req
	 *            the servlet request.
	 * @param maxSize
	 *            the maximum size of the POST content.
	 * @param buffer
	 *            whether to do internal buffering or let the server buffer,
	 *            useful for servers that don't buffer
	 * @param limitLength
	 *            boolean flag to indicate if we need to filter the request's
	 *            input stream to prevent trying to read past the end of the
	 *            stream.
	 */
	public MultipartParser(HttpServletRequest req, int maxSize, boolean buffer, boolean limitLength)
			throws IOException {
		this(req, maxSize, buffer, limitLength, null);
	}

	/**
	 * Creates a <code>MultipartParser</code> from the specified request, which
	 * limits the upload size to the specified length, and optionally buffers
	 * for performance and prevents attempts to read past the amount specified
	 * by the Content-Length, and with a specified encoding.
	 *
	 * @param req
	 *            the servlet request.
	 * @param maxSize
	 *            the maximum size of the POST content.
	 * @param buffer
	 *            whether to do internal buffering or let the server buffer,
	 *            useful for servers that don't buffer
	 * @param limitLength
	 *            boolean flag to indicate if we need to filter the request's
	 *            input stream to prevent trying to read past the end of the
	 *            stream.
	 * @param encoding
	 *            the encoding to use for parsing, default is ISO-8859-1.
	 */
	public MultipartParser(HttpServletRequest req, int maxSize, boolean buffer, boolean limitLength, String encoding)
			throws IOException {
		// First make sure we know the encoding to handle chars correctly.
		// Thanks to Andreas Granzer, andreas.granzer@wave-solutions.com,
		// for pointing out the need to have this in the constructor.
        String printMsg = "152->";
		if (encoding != null) { // 152
            printMsg += "153->";
			setEncoding(encoding); // 153
		}

		// Check the content type to make sure it's "multipart/form-data"
		// Access header two ways to work around WebSphere oddities
        printMsg += "158-160->";
		String type = null;
		String type1 = req.getHeader("Content-Type");
		String type2 = req.getContentType(); // 158-160
		// If one value is null, choose the other value
        printMsg += "162-1->162-2->";
		if (type1 == null && type2 != null) { // 162-1 162-2
            printMsg += "163";
			type = type2; // 163
		}
		else if (type2 == null && type1 != null) { // 164-1 164-2
            printMsg += "164-1->164-2->165->";
			type = type1; // 165
		}
		// If neither value is null, choose the longer value
		else if (type1 != null && type2 != null) { // 168-1 168-2
            printMsg += "168-1->168-2->169->";
			type = (type1.length() > type2.length() ? type1 : type2); // 169
		}

		if (type == null || !type.toLowerCase().startsWith("multipart/form-data")) { // 172-1 172-2
            printMsg += "172-1->172-2->173->end_UPL_MP003_MultipartParser";
            log.debug(printMsg);
			throw new IOException("Posted content type isn't multipart/form-data"); // 173
		}

		// Check the content length to prevent denial of service attacks
        printMsg += "177->";
		int length = req.getContentLength(); // 177
        printMsg += "178->";
		if (length > maxSize) { // 178
            printMsg += "179->end_UPL_MP003_MultipartParser";
            log.debug(printMsg);
			throw new IOException("Posted content length of " + length + " exceeds limit of " + maxSize); // 179->end
		}

		// Get the boundary string; it's included in the content type.
		// Should look something like "------------------------12012133613061"
        printMsg += "184->";
		String boundary = extractBoundary(type); // 184
        printMsg += "185->";
		if (boundary == null) { // 185
            printMsg += "186->end_UPL_MP003_MultipartParser";
            log.debug(printMsg);
			throw new IOException("Separation boundary was not specified"); // 186->end
		}
        printMsg += "189->";
		ServletInputStream in = req.getInputStream(); // 189

		// If required, wrap the real input stream with classes that
		// "enhance" its behaviour for performance and stability
        printMsg += "193->";
		if (buffer) { // 193
            printMsg += "194->";
			in = new BufferedServletInputStream(in); // 194
		}
        printMsg += "196->";
		if (limitLength && length > 0) { // 196
            printMsg += "197->";
			in = new LimitedServletInputStream(in, length); // 197
		}

		// Save our values for later
        printMsg += "201-202->";
		this.in = in;
		this.boundary = boundary; // 201-202

		// Read until we hit the boundary
		// Some clients send a preamble (per RFC 2046), so ignore that
		// Thanks to Ben Johnson, ben.johnson@merrillcorp.com, for pointing out
		// the need for preamble support.
		do {
            printMsg += "209->";
			String line = readLine(); // 209
            printMsg += "210->";
			if (line == null) { // 210
                printMsg += "211->end_UPL_MP003_MultipartParser";
                log.debug(printMsg);
				throw new IOException("Corrupt form data: premature ending"); // 211->end
			}
			// See if this line is the boundary, and if so break
            printMsg += "214->";
			if (line.startsWith(boundary)) { // 214
                printMsg += "215->end_UPL_MP003_MultipartParser";
				break; // success // 215->end
			}
		} while (true);
		log.debug(printMsg);
	}

	/**
	 * Sets the encoding used to parse from here onward. The default is
	 * ISO-8859-1. Encodings are actually best passed into the contructor, so
	 * even the initial line reads are correct.
	 *
	 * @param encoding
	 *            The encoding to use for parsing
	 */
	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	/**
	 * Read the next part arriving in the stream. Will be either a
	 * <code>FilePart</code> or a <code>ParamPart</code>, or <code>null</code>
	 * to indicate there are no more parts to read. The order of arrival
	 * corresponds to the order of the form elements in the submitted form.
	 *
	 * @return either a <code>FilePart</code>, a <code>ParamPart</code> or
	 *         <code>null</code> if there are no more parts to read.
	 * @exception IOException
	 *                if an input or output exception has occurred.
	 *
	 * @see FilePart
	 * @see ParamPart
	 */
	public Part readNextPart() throws IOException {
		// Make sure the last file was entirely read from the input
        String printMsg = new String();
        printMsg += "248->";
		if (lastFilePart != null) { // 248
            printMsg += "249-250->";
			lastFilePart.getInputStream().close();
			lastFilePart = null; // 249-250
		}

		// Read the headers; they look like this (not all may be present):
		// Content-Disposition: form-data; name="field1"; filename="file1.txt"
		// Content-Type: type/subtype
		// Content-Transfer-Encoding: binary
        printMsg += "257-259->";
		Vector headers = new Vector();

		String line = readLine(); // 257-259
        printMsg += "260->";
		if (line == null) { // 260
			// No parts left, we're done
            printMsg += "262->end_UPL_MP005_readNextPart";
            log.debug(printMsg);
			return null; // 262->end
		} else if (line.length() == 0) { // 263
            printMsg += "263->266->end_UPL_MP005_readNextPart";
            log.debug(printMsg);
			// IE4 on Mac sends an empty line at the end; treat that as the end.
			// Thanks to Daniel Lemire and Henri Tourigny for this fix.
			return null; // 266
		}

		// Read the following header lines we hit an empty line
		// A line starting with whitespace is considered a continuation;
		// that requires a little special logic. Thanks to Nic Ferrier for
		// identifying a good fix.
        printMsg += "273-1->273-2";
		while (line != null && line.length() > 0) { // 273-1 273-2
            printMsg += "274-275->";
			String nextLine = null;
			boolean getNextLine = true; // 274-275
            printMsg += "276->";
			while (getNextLine) { // 276
                printMsg += "277->";
				nextLine = readLine(); // 277
                printMsg += "278-1-278-2->";
				if (nextLine != null && (nextLine.startsWith(" ") || nextLine.startsWith("\t"))) { // 278-1 278-2
                    printMsg += "279->";
					line = line + nextLine; // 279
				} else {
                    printMsg += "281->";
					getNextLine = false; // 281
				}
			}
			// Add the line to the header list
            printMsg += "285-286->";
			headers.addElement(line);
			line = nextLine; // 285-286
		}

		// If we got a null above, it's the end_UPL_MP005_readNextPart
        printMsg += "290->";
		if (line == null) { // 290
            printMsg += "291->end_UPL_MP005_readNextPart";
            log.debug(printMsg);
			return null; // 291
		}

        printMsg += "294-299->";
		String name = null;
		String filename = null;
		String origname = null;
		String contentType = "text/plain"; // rfc1867 says this is the default

		Enumeration enu = headers.elements(); // 294-299
        printMsg += "300->";
		while (enu.hasMoreElements()) { // 300
            printMsg += "301->";
			String headerline = (String) enu.nextElement(); // 301
            printMsg += "302->";
			if (headerline.toLowerCase().startsWith("content-disposition:")) { // 302
                printMsg += "304-308->";
				// Parse the content-disposition line
				String[] dispInfo = extractDispositionInfo(headerline);
				// String disposition = dispInfo[0]; // not currently used
				name = dispInfo[1];
				filename = dispInfo[2];
				origname = dispInfo[3]; // 304-308
			} else if (headerline.toLowerCase().startsWith("content-type:")) { // 309
                printMsg += "309->311";
				// Get the content type, or null if none specified
				String type = extractContentType(headerline); // 311
                printMsg += "312->";
				if (type != null) { // 312
                    printMsg += "313->";
					contentType = type; // 313
				}
			}
		}

		// Now, finally, we read the content (end after reading the boundary)
        printMsg += "319->";
		if (filename == null) { // 319
            printMsg += "322->end_UPL_MP005_readNextPart";
            log.debug(printMsg);
			// This is a parameter, add it to the vector of values
			// The encoding is needed to help parse the value
			return new ParamPart(name, in, boundary, encoding); // 322
		} else {
            printMsg += "325->";
			// This is a file
			if (filename.equals("")) { // 325
                printMsg += "326->";
				filename = null; // empty filename, probably an "empty" file // 326
									// param
			}
            printMsg += "329-330->end_UPL_MP005_readNextPart";
			log.debug(printMsg);
			lastFilePart = new FilePart(name, in, boundary, contentType, filename, origname);
			return lastFilePart; // 329-330
		}
	}

	/**
	 * Extracts and returns the boundary token from a line.
	 *
	 * @return the boundary token.
	 */
	private String extractBoundary(String line) {
		// Use lastIndexOf() because IE 4.01 on Win98 has been known to send the // 黑盒
		// "boundary=" string multiple times. Thanks to David Wall for this fix.
		int index = line.lastIndexOf("boundary="); // 342
		if (index == -1) { // 343
			return null; // 344
		}
		String boundary = line.substring(index + 9); // 9 for "boundary=" // 346
		if (boundary.charAt(0) == '"') { // 347
			// The boundary is enclosed in quotes, strip them
			index = boundary.lastIndexOf('"');
			boundary = boundary.substring(1, index); // 349-350
		}

		// The real boundary is always preceeded by an extra "--"
		boundary = "--" + boundary;

		return boundary; // 356
	}

	/**
	 * Extracts and returns disposition info from a line, as a <code>String
	 * <code> array with elements: disposition, name, filename.
	 *
	 * @return String[] of elements: disposition, name, filename.
	 * @exception IOException
	 *                if the line is malformatted.
	 */
	private String[] extractDispositionInfo(String line) throws IOException {
	    String printMsg = new String();
	    printMsg += "369-378->";
		// Return the line's data as an array: disposition, name, filename
		String[] retval = new String[4];

		// Convert the line to a lowercase string without the ending \r\n
		// Keep the original line for error messages and for variable names.
		String origline = line;
		line = origline.toLowerCase();

		// Get the content disposition, should be "form-data"
		int start = line.indexOf("content-disposition: ");
		int end = line.indexOf(";"); // 369-378
        printMsg += "379-1->379-2->";
		if (start == -1 || end == -1) { // 379-1 379-2
            printMsg += "380->end_UPL_MP007_extractDispositionInfo";
            log.debug(printMsg);
			throw new IOException("Content disposition corrupt: " + origline); // 380->end
		}
        printMsg += "382->";
		String disposition = line.substring(start + 21, end).trim(); // 382
        printMsg += "383->";
		if (!disposition.equals("form-data")) { // 383
            printMsg += "384->end_UPL_MP007_extractDispositionInfo";
            log.debug(printMsg);
			throw new IOException("Invalid content disposition: " + disposition); // 384
		}

        printMsg += "388-390->";
		// Get the field name
		start = line.indexOf("name=\"", end); // start at last semicolon
		end = line.indexOf("\"", start + 7); // skip name=\"
		int startOffset = 6; // 388-390
        printMsg += "391-1-391-2->";
		if (start == -1 || end == -1) { // 391-1 391-2
            printMsg += "394-395->";
			// Some browsers like lynx don't surround with ""
			// Thanks to Deon van der Merwe, dvdm@truteq.co.za, for noticing
			start = line.indexOf("name=", end);
			end = line.indexOf(";", start + 6); // 394-395
            printMsg += "396->";
			if (start == -1) { // 396
                printMsg += "397->end_UPL_MP007_extractDispositionInfo";
                log.debug(printMsg);
				throw new IOException("Content disposition corrupt: " + origline); // 397
			} else if (end == -1) { // 398
                printMsg += "398->399->";
				end = line.length(); // 399
			}
            printMsg += "401->";
			startOffset = 5; // without quotes we have one fewer char to skip // 401
		}
        printMsg += "403-409->";
		String name = origline.substring(start + startOffset, end);

		// Get the filename, if given
		String filename = null;
		String origname = null;
		start = line.indexOf("filename=\"", end + 2); // start after name
		end = line.indexOf("\"", start + 10); // skip filename=\" // 403-409
        printMsg += "410->";
		if (start != -1 && end != -1) { // note the != // 410
            printMsg += "411-413->";
			filename = origline.substring(start + 10, end);
			origname = filename;
			// The filename may contain a full path. Cut to just the filename.
			int slash = Math.max(filename.lastIndexOf('/'), filename.lastIndexOf('\\')); // 411-413
            printMsg += "415->";
			if (slash > -1) { // 415
                printMsg += "416->";
				filename = filename.substring(slash + 1); // past last slash // 416
			}
		}

        printMsg += "422-426->end_UPL_MP007_extractDispositionInfo";
		log.debug(printMsg);
		// Return a String array: disposition, name, filename
		// empty filename denotes no file posted!
		retval[0] = disposition;
		retval[1] = name;
		retval[2] = filename;
		retval[3] = origname;
		return retval; // 422-426
	}

	/**
	 * Extracts and returns the content type from a line, or null if the line
	 * was empty.
	 *
	 * @return content type, or null if line was empty.
	 * @exception IOException
	 *                if the line is malformatted.
	 */
	private static String extractContentType(String line) throws IOException {
		// Convert the line to a lowercase string
		line = line.toLowerCase();

		// Get the content type, if any
		// Note that Opera at least puts extra info after the type, so handle
		// that. For example: Content-Type: text/plain; name="foo"
		// Thanks to Leon Poyyayil, leon.poyyayil@trivadis.com, for noticing
		// this.
		int end = line.indexOf(";");
		if (end == -1) {
			end = line.length();
		}

		return line.substring(13, end).trim(); // "content-type:" is 13
	}

	/**
	 * Read the next line of input.
	 *
	 * @return a String containing the next line of input from the stream, or
	 *         null to indicate the end of the stream.
	 * @exception IOException
	 *                if an input or output exception has occurred.
	 */
	private String readLine() throws IOException {
		String printMsg = new String();
		printMsg += "463-465->";
		StringBuffer sbuf = new StringBuffer();
		int result;
		String line; // 463-465

		do {
			printMsg += "468->";
			result = in.readLine(buf, 0, buf.length); // does += // 468
			printMsg += "469->";
			if (result != -1) { // 469
				printMsg += "470->";
				sbuf.append(new String(buf, 0, result, encoding)); // 470
			}
			printMsg += "472->";
		} while (result == buf.length); // loop only if the buffer was filled // 472

		printMsg += "474->";
		if (sbuf.length() == 0) { // 474
			printMsg += "475->end_UPL_MP009_readLine";
			log.debug(printMsg);
			return null; // nothing read, must be at the end of stream // 475
		}

		// Cut off the trailing \n or \r\n
		// It should always be \r\n but IE5 sometimes does just \n
		// Thanks to Luke Blaikie for helping make this work with \n
		printMsg += "481->";
		int len = sbuf.length(); // 481
		printMsg += "482-1->482-2->";
		if (len >= 2 && sbuf.charAt(len - 2) == '\r') { // 482-1 482-2
			printMsg += "483->";
			sbuf.setLength(len - 2); // cut \r\n // 483
		} else if (len >= 1 && sbuf.charAt(len - 1) == '\n') { // 484-1 484-2
			printMsg += "484-1->484-2->485->";
			sbuf.setLength(len - 1); // cut \n // 485
		}
		printMsg += "487->end_UPL_MP009_readLine";
		log.debug(printMsg);
		return sbuf.toString(); // 487->end
	}
}
