package com.zhangfeng.framework;

import com.baomidou.framework.common.JarHelper;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.jar.JarFile;

/**
 * Created by zhangfeng on 2017/6/3.
 */
public class COM_JH_Test {

    public static File file;
    public static JarFile jarFile;

    @BeforeTest
    public void setUp() {
        file = new File("/Users/zhangfeng/Desktop/J2SE.jar");
        try {
            jarFile = new JarFile(file);
        } catch (IOException e) {

        }
    }

    @Test
    public void listFileTest() {
        List<String> result = JarHelper.listFiles(jarFile, "class");
        System.out.println(result.get(1));
    }

    @Test
    public void readLinesTest() {
        try {
            List<String> result = JarHelper.readLines(jarFile, "ClassLoaderTest/HackSystem.class");
            System.out.println(result);
        } catch (IOException e) {

        }
    }
}
