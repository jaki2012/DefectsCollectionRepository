package com.baomidou.framework.common;

import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class Pinyin4jHelperTest extends TestCase {
    Pinyin4jHelper p;
    protected void setUp() throws Exception {
        super.setUp();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    @Before
    public void Create(){
        p =  new Pinyin4jHelper();
    }

    /**
     * <p>
     * 拼音首字母，获取第一个结果。 （北京市长:bjsz,bjsc 返回 bjsz）
     * </p>
     *
     * @param chines
     *            	汉字
     * @return 拼音首字母
     */
    @Test
    public void testConverterToFirstSpell() {
        System.out.println("一："+p.converterToFirstSpell("长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长，长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长"));
    }

    /**
     * <p>
     * 汉字转换位汉语拼音首字母，英文字符不变，特殊字符丢失 支持多音字。 （北京市长:bjsz,bjsc）
     * </p>
     *
     * @param chines
     *            	汉字
     * @return 拼音首字母
     */
    @Test
    public void testConverterToAllFirstSpell() {
        System.out.println("二："+p.converterToAllFirstSpell("长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长，长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长"));
    }

    /**
     * <p>
     * 汉语全拼，获取第一个结果。（北京市长:beijingshizhang,beijingshichang 返回 beijingshizhang）
     * </p>
     *
     * @param chines
     *            	汉字
     * @return 拼音
     */
    @Test
    public void testConverterToSpell() {
        System.out.println("三："+p.converterToSpell("长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长，长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长"));
    }

    /**
     * <p>
     * 汉字转换位汉语全拼，英文字符不变，特殊字符丢失
     * 支持多音字，生成方式如（北京市长:beijingshizhang,beijingshichang）
     * </p>
     *
     * @param chines
     *            	汉字
     * @return 拼音
     */
    @Test
    public void testConverterToAllSpell() {
        System.out.println("四："+p.converterToAllSpell("长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长，长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长"));
    }

    /**
     * <p>
     * 去除多音字重复数据
     * </p>
     *
     * @param theStr
     * 				多音字
     * @return
     */
    @Test
    public void testDiscountTheChinese() {
        System.out.println("五："+p.discountTheChinese("长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长，长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长长"));
    }

    /**
     * 解析并组合拼音，对象合并方案(推荐使用)
     *
     * @return
     */
//	@Test
//	public void testParseTheChineseByObject() {
//		//List<Map<String, Integer>> list = new List<Map<String, Integer>>();
//		p.parseTheChineseByObject("北京市长");
//	}

}