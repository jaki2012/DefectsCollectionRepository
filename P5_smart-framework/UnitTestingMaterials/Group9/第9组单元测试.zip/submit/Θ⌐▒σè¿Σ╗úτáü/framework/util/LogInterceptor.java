package com.zhangfeng.framework.util;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.core.AppenderBase;
import ch.qos.logback.core.OutputStreamAppender;
import ch.qos.logback.core.filter.Filter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

/**
 * Created by jixunzhen on 30/05/2017.
 */
public class LogInterceptor extends OutputStreamAppender{
    private static ArrayList<String> errors=new ArrayList<String>();
    private static ArrayList<String > warns=new ArrayList<String>();
    private static ArrayList<String> infos=new ArrayList<String>();
    private static ArrayList<String > debugs=new ArrayList<String>();

    private static ByteArrayOutputStream stream=new ByteArrayOutputStream();

    @Override
    public void start() {
        this.setOutputStream(stream);
        super.start();
    }

    @Override
    public void doAppend(Object eventObject) {
        String content=eventObject.toString();
        String headInfo=content.substring(0,7);
        if(headInfo.contains("ERROR")){
            errors.add(content.substring(8));
        }else if(headInfo.contains("WARN")){
            warns.add(content.substring(7));
        }else if(headInfo.contains("INFO")){
            infos.add(content.substring(7));
        }else if(headInfo.contains("DEBUG")){
            debugs.add(content.substring(8));
        }
        super.doAppend(eventObject);
    }

    public static boolean assertLog(LogLevel level, String content){
        ArrayList<String> list=getList(level);
        if (list!=null){
            for(String string:list){
                if(string.equals(content)) {
                    return true;
                }
            }
        }

        return false;
    }

    private static ArrayList<String> getList(LogLevel level){
        switch (level) {
            case DEBUG:
                return debugs;
            case INFO:
                return infos;
            case ERROR:
                return errors;
            case WARN:
                return warns;
            default:
                return null;
        }
    }

    public static void clear(){
        debugs.clear();
        infos.clear();
        warns.clear();
        errors.clear();
    }

    public static void printLog(LogLevel level){
        ArrayList<String> list=getList(level);
        if(list!=null){
            System.out.println("[Print Log] - "+level.toString());
            for(String string:list){
                System.out.println(string);
            }
        }
    }
}

