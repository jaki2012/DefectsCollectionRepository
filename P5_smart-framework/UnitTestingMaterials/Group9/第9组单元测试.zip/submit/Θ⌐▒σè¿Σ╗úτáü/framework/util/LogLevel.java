package com.zhangfeng.framework.util;

/**
 * Created by jixunzhen on 30/05/2017.
 */
public enum LogLevel{
    ERROR,
    WARN,
    INFO,
    DEBUG
}
