package com.zhangfeng.framework;

import com.baomidou.framework.common.GraphicsMagickHelper;
import org.testng.annotations.Test;

/**
 * Created by zhangfeng on 2017/6/3.
 */
public class COM_GMH_Test {
    @Test
    public void rotateTest() {
        GraphicsMagickHelper gmh = new GraphicsMagickHelper();
        gmh.rotate("/Users/zhangfeng/Desktop/hhh.jpeg", "/Users/zhangfeng/Desktop/new_hhh.jpeg", 90);
    }
}
