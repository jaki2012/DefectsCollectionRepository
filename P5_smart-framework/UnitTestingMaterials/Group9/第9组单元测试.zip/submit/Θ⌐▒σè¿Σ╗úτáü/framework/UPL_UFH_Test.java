package com.zhangfeng.framework;

import com.baomidou.framework.upload.UploadFileHeader;
import org.testng.annotations.Test;

import java.lang.reflect.Field;

/**
 * Created by zhangfeng on 2017/6/1.
 */
public class UPL_UFH_Test {


    @Test
    public void bytesToHexStringTest() throws Exception {
        byte[] data = {1,2,3,4,5};
        System.out.println(UploadFileHeader.bytesToHexString(data));
    }

    @Test
    public void getThreeBytesTest() throws Exception {
        String data = "sdf";
        System.out.println(UploadFileHeader.getThreeBytes(data));
    }

}
