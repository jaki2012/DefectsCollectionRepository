package com.zhangfeng.framework;

import com.baomidou.framework.common.SwConstants;
import com.baomidou.framework.upload.UploadFileRenamePolicy;
import com.baomidou.framework.upload.UploadMultipartRequest;
import com.baomidou.framework.upload.multipart.FilePart;
import com.baomidou.framework.upload.multipart.FileRenamePolicy;
import com.baomidou.framework.upload.multipart.MultipartParser;
import com.baomidou.framework.upload.multipart.Part;
import com.zhangfeng.framework.util.LogInterceptor;
import com.zhangfeng.framework.util.LogLevel;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.mock.web.MockMultipartHttpServletRequest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.lang.reflect.Method;

/**
 * Created by zhangfeng on 2017/5/28.
 */
public class UPL_UMR_Test {
    public static MockHttpServletRequest request;
    public static MockMultipartHttpServletRequest mRequest;
    public static MockMultipartFile mFile;
    public byte[] file;
    private static final String LOGGER_NAME = "com.zhangfeng.framework";
    private static final Logger log = LoggerFactory.getLogger(LOGGER_NAME);

    @BeforeTest
    public void setUpRequest() {
        request = new MockHttpServletRequest();
        mRequest = new MockMultipartHttpServletRequest();
        mFile = new MockMultipartFile("faq.txt", "original.txt", "plain/text", "this is fucking content".getBytes());
        mRequest.addFile(mFile);
        file = ("--???\n" +
                "Content-Disposition: form-data; name=\"title\" \n\n" +
                "first mock multipart request\n" +
                "--???\n" +
                "Content-Disposition: form-data; name=\"name\" \n\n" +
                "fuck you stupid asshole\n" +
                "--???\n" +
                "Content-Disposition: form-data; name=\"file\" filename=\"test.txt\" \n" +
                "Content-Type: text/plain\n\n" +
                "And! This is the very motherfucker I am looking for!!!!!!!!1234\n" +
                "--???--").getBytes();
        request.setContentType("multipart/form-data;boundary=???");
        request.setContent(file);
    }


    @DataProvider(name = "upload")
    public static Object[][] uploadData() {
        return new Object[][]{
                {request, "/Users/zhangfeng/Desktop/upload_directory", 1024 * 1024, "description"},
                {null, "/Users/zhangfeng/Desktop/upload_directory", 1024*1024, "description"},
                {request, null, 1024*1024, "description"},
                {request, "/Users/zhangfeng/Desktop/upload_directory", null, "description"},
                {request, "/Users/zhangfeng/Desktop/upload_directory/asd.txt", 1024*1024, "description"},
                {request, "/Users/zhangfeng/Desktop/upload_directory/not_writable", 1024*1024, "description"}
        };
    }

    @DataProvider(name = "writeTo")
    public static Object[][] writeToData() {
        return new Object[][]{
                //directory, filename, policy, fileHeaderExts
                {"/Users/zhangfeng/Desktop/upload_directory", "asd.txt", new UploadFileRenamePolicy(), null},
                {"/Users/zhangfeng/Desktop/uploaddirectory/none.txt", "asd.txt", new UploadFileRenamePolicy(), null},
                {"/Users/zhangfeng/Desktop/upload_directory", null, new UploadFileRenamePolicy(), null},
                {"/Users/zhangfeng/Desktop/upload_directory", "asd.txt", null, null},
                {"/Users/zhangfeng/Desktop/upload_directory", "asd.txt", new UploadFileRenamePolicy(), "416e64.txt"},
                {"/Users/zhangfeng/Desktop/upload_directory", "asd.txt", new UploadFileRenamePolicy(), "416e65.txt"},

        };
    }

//"
//    @Test
//    public void writeToTest() throws Exception {
//        log.error("dasdasd");
//        assert  LogInterceptor.assertLog(LogLevel.ERROR,"dasdasd");
//    }


    @Test(dataProvider = "upload")
    public void uploaddTest(Object request, Object saveDir, Object postSize, Object description) throws Exception {
        LogInterceptor.clear();
        UploadMultipartRequest uploadMultipartRequest = new UploadMultipartRequest((MockHttpServletRequest) request, (String) saveDir);
        try {
            uploadMultipartRequest.upload();
        } catch (Exception e) {

        }
        LogInterceptor.printLog(LogLevel.DEBUG);
    }

    @Test(dataProvider = "writeTo")
    public void writeToTest(Object directory, Object filename, Object policy, Object fileHeaderExts) throws Exception {
        UploadMultipartRequest uploadMultipartRequest = new UploadMultipartRequest(request, "/Users/zhangfeng/Desktop/upload_directory");
        uploadMultipartRequest.setFileHeaderExts((String)fileHeaderExts);
        MultipartParser parser = new MultipartParser(request, 1024 * 1024, true, true, SwConstants.UTF_8);
        Method f_writeTo = uploadMultipartRequest.getClass().getDeclaredMethod("writeTo", File.class, String.class, FileRenamePolicy.class, FilePart.class);
        f_writeTo.setAccessible(true);
        Part part;
        while ((part = parser.readNextPart()) != null) { // 133
            if (part.isFile()) {
                FilePart filePart = (FilePart) part;
                LogInterceptor.clear();
                f_writeTo.invoke(uploadMultipartRequest, new File((String)directory), (String)filename, (UploadFileRenamePolicy)policy, filePart);
                LogInterceptor.printLog(LogLevel.DEBUG);
            }
        }
    }

}
