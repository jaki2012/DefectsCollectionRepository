package com.zhangfeng.framework;

import com.baomidou.framework.common.Base58Helper;
import org.testng.annotations.Test;

import java.util.UUID;

/**
 * Created by zhangfeng on 2017/5/29.
 */
public class COM_BH_Test {
    @Test
    public void encodeTest() throws Exception {
        System.out.println(Base58Helper.encode("00004G".getBytes()));
    }

    @Test
    public void decoodeTest() throws Exception {
//        byte[] tmp = Base58Helper.decodeInner("Qznfg3p2");
//        System.out.println();
        String tmp = Base58Helper.compressedUUID();
        System.out.println(tmp);
    }
}
