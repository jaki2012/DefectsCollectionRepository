package com.zhangfeng.framework;

import com.baomidou.framework.common.FileHashHelper;
import com.baomidou.framework.common.SwConstants;
import com.baomidou.framework.upload.multipart.Part;
import com.zhangfeng.framework.util.LogInterceptor;
import com.zhangfeng.framework.util.LogLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.mock.web.MockMultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartFile;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.baomidou.framework.upload.multipart.MultipartParser;

import javax.servlet.ServletInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangfeng on 2017/5/30.
 */
public class UPL_MP_MP_Test {

    private static final String LOGGER_NAME = "com.zhangfeng.framework";
    private static final Logger log = LoggerFactory.getLogger(LOGGER_NAME);

    public static MockHttpServletRequest request;
    public static MockMultipartHttpServletRequest mRequest;
    public static MockMultipartFile mFile;
    public static String universalContent = "--???\n" +
            "Content-Disposition: form-data; name=\"title\" \n\n" +
            "first mock multipart request\n" +
            "--???\n" +
            "Content-Disposition: form-data; name=\"name\" \n\n" +
            "fuck you stupid asshole\n" +
            "--???\n" +
            "Content-Disposition: form-data; name=\"file\" filename=\"test.txt\" \n" +
            "Content-Type: text/plain\n\n" +
            "this is the content in a text file\n\n" +
            "--???--";
    public static String longContent = "--???\n" +
            "Content-Disposition: form-data; name=\"title\" \n\n" +
            "first mock multipart request\n" +
            "--???\n" +
            "Content-Disposition: form-data; name=\"name\" \n\n" +
            "fuck you stupid asshole\n" +
            "--???\n" +
            "Content-Disposition: form-data; name=\"file\" filename=\"test.txt\" \n" +
            "Content-Type: text/plain\n" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file" +
            "this is the content in a text file\n\n" +
            "--???--";
    public byte[] file;
    public byte[] file2;

    @DataProvider(name = "MultipartParser")
    public static Object[][] MultipartParserData() {
        return new Object[][]{
                //encoding, request.contentType(null/”multipart/form-data”/”application/x-javascript”), request.contentLength, boundary, buffer, limitLength,
                // maxSize, buffer, limitLength, encoding, contentType, content
                {1024 * 1024, true, true, "UTF-8", "multipart/form-data;boundary=???", universalContent},
                {1024 * 1024, true, true, null, "multipart/form-data;boundary=???", universalContent},
                {1024 * 1024, true, true, "UTF-8", null, universalContent},
                {1024 * 1024, true, true, "UTF-8", "multipart/form-data;", universalContent},
                {1024 * 1024, true, true, "UTF-8", "application/x-javascript;boundary=???", universalContent},
                {1024 * 1024, true, true, "UTF-8", "multipart/form-data;boundary=???", ""},
                {1024 * 1024, false, true, "UTF-8", "multipart/form-data;boundary=???", universalContent},
                {1024 * 1024, true, false, "UTF-8", "multipart/form-data;boundary=???", universalContent},
                {1024, true, false, "UTF-8", "multipart/form-data;boundary=???", longContent}
        };
    }

    @DataProvider(name = "readNextPart")
    public static Object[][] readNextPartData() {
        return new Object[][]{
                {"--???\n"},
                {"Content-Disposition: form-data; name=\"title\" \n\n"},
                {"first mock multipart request\n"},
                {"--???\n"},
                {"Content-Disposition: form-data; name=\"name\" \n\n"},
                {"fuck you stupid asshole\n"},
                {"--???\n"},
                {"Content-Disposition: form-data; name=\"file\" filename=\"test.txt\" \n"},
                {"Content-Disposition: form-data; name=\"file\" filename=\"test.txt\" \n"},
                {"Content-Type: text/plain\n\n"},
                {"this is the content in a text file\r\n"},
                {"--???--"}
        };
    }

    @DataProvider(name = "extractDispositionInfo")
    public static Object[][] extractDispositionInfoData() {
        return new Object[][]{
                {"Content-Disposition: form-data; name=\"title\" filename=\"test.txt\""},
                {"Content-Disposition: form-data, name=\"title\" filename=\"test.txt\""},
                {"Content_Disposition: form-data; name=\"title\" filename=\"test.txt\""},
                {"Content-Disposition: from-data; name=\"title\" filename=\"test.txt\""},
                {"Content-Disposition: form-data; anme=\"title\" filename=\"test.txt\""},
                {"Content-Disposition: form-data; name=\"title   filename=\"test.txt\""},
                {"Content-Disposition: form-data; name=title; filename=\"test.txt\""},
                {"Content-Disposition: form-data; anme=title; filename=\"test.txt\""},
                {"Content-Disposition: form-data; name=title filename=\"test.txt\""},
                {"Content-Disposition: form-data; name=\"title\" fileanme=\"test.txt "},
        };
    }

    @BeforeTest
    public void setUp() {
        request = new MockHttpServletRequest();
        file = ("--???\n" +
                "Content-Disposition: form-data; name=\"title\" \n\n" +
                "first mock multipart request\n" +
                "--???\n" +
                "Content-Disposition: form-data; name=\"name\" \n\n" +
                "hhh\n" +
                "--???\n" +
                "Content-Disposition: form-data; name=\"file\" filename=\"test.txt\" \n" +
                "Content-Type: text/plain\n" +
                "this is the content in a text file\r\n" +
                "--???--").getBytes();
        file2 = ("i think this is a file content which is so amazing").getBytes();
        request.setContentType("multipart/form-data;boundary=???");
        request.setContent(file);
        mFile = new MockMultipartFile("a.txt", file);
    }

    @Test(dataProvider = "MultipartParser")
    public void multipartParserTest(Object maxSize, Object buffer, Object limitLength, Object encoding, Object contentType, Object content) throws Exception {
        file = ((String) content).getBytes();
        request.setContent(file);
        request.setContentType((String)contentType);
        request.setCharacterEncoding((String)encoding);
        LogInterceptor.clear();
        try {
            MultipartParser mp = new MultipartParser(request, (Integer) maxSize, (Boolean) buffer, (Boolean) limitLength, request.getCharacterEncoding());
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
        LogInterceptor.printLog(LogLevel.DEBUG);
        LogInterceptor.clear();
    }

    @Test
    public void readNextPartTest() throws Exception {
//        StringBuffer contentLines = new StringBuffer();
        //测试用例
//        contentLines.append("--???\n");
//        contentLines.append("Content-Disposition: form-data; name=\"title\" \n\n");
//        contentLines.append("first mock multipart request\n");
//        contentLines.append("--???\n");
//        contentLines.append("Content-Disposition: form-data; name=\"name\" \n\n");
//        contentLines.append("fuck you stupid asshole\n");
//        contentLines.append("--???\n");
//        contentLines.append("Content-Disposition: form-data; name=\"file\" filename=\"test.txt\" \n");
//        contentLines.append("Content-Disposition: form-data; name=\"file\" filename=\"test.txt\" \n");
//        contentLines.append("Content-Type: text/plain\n");
//        contentLines.append("this is the content in a text file\r\n");
//        contentLines.append("--???--");
//        System.out.println(contentLines.toString());
//        byte[] testContent = contentLines.toString().getBytes();
//        request.setContent(testContent);
//        ServletInputStream in = request.getInputStream();
//        request.addParameter("title", "faq");
//        System.out.println(request.getParameter("title"));

        MultipartParser parser = new MultipartParser(request, 1024 * 1024, true, true, SwConstants.UTF_8);
        parser.readNextPart();
        parser.readNextPart();
        parser.readNextPart();
        parser.readNextPart();
        LogInterceptor.printLog(LogLevel.DEBUG);
        LogInterceptor.clear();

    }

    @Test
    public void readLineTest() throws Exception {
        MultipartParser parser = new MultipartParser(request, 1024 * 1024, true, true, SwConstants.UTF_8);
        Method f_readLine = parser.getClass().getDeclaredMethod("readLine");
        f_readLine.setAccessible(true);
        Field f_in = parser.getClass().getDeclaredField("in");
        f_in.setAccessible(true);
        ServletInputStream inputStream = request.getInputStream();
        f_in.set(parser, inputStream);
        String tmp = new String();
        do  {
            LogInterceptor.clear();
            tmp = (String)f_readLine.invoke(parser);
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~``");
            System.out.println(tmp);
            LogInterceptor.printLog(LogLevel.DEBUG);
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~``");
        } while (tmp != null);
    }

    @Test(dataProvider = "extractDispositionInfo")
    public void extractDispositionInfoTest(Object line) throws Exception {
        MultipartParser parser = new MultipartParser(request, 1024 * 1024, true, true, SwConstants.UTF_8);
        Method f_extractDispositionInfo = parser.getClass().getDeclaredMethod("extractDispositionInfo", String.class);
        f_extractDispositionInfo.setAccessible(true);
        LogInterceptor.clear();
        try {
            String[] result = (String[])f_extractDispositionInfo.invoke(parser, (String) line);
            System.out.println(result[0]);
            System.out.println(result[1]);
            System.out.println(result[2]);
            System.out.println(result[3]);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        LogInterceptor.printLog(LogLevel.DEBUG);
        LogInterceptor.clear();
    }

    // 黑盒
    @Test
    public void extractBoundaryTest() throws Exception {

    }

}
