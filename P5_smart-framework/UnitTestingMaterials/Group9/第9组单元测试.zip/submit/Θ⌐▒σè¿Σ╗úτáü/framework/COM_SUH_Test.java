package com.zhangfeng.framework;

import com.baomidou.framework.common.ShortUrlHelper;
import org.testng.annotations.Test;

/**
 * Created by zhangfeng on 2017/6/3.
 */
public class COM_SUH_Test {

    @Test
    public void generateTest() {
        String[] result = ShortUrlHelper.generate("", "salt");
        System.out.println(result);
    }
}
