package com.zhangfeng.framework;

import com.baomidou.framework.common.RelativeDateFormat;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.Date;

/**
 * Created by zhangfeng on 2017/6/3.
 */
public class COM_RDF_Test {

    public static Date date;

    @BeforeTest
    public void setUp() {
        date = new Date();
    }

    @Test
    public void formatTest() {
        date.setTime(date.getTime()-60000);
        String result = RelativeDateFormat.format(date);
        System.out.println(result);
    }
}
