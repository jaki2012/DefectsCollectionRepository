package com.zhangfeng.framework;

import com.baomidou.framework.common.SwfToolsHelper;
import org.testng.annotations.Test;

import java.io.IOException;

/**
 * Created by zhangfeng on 2017/6/3.
 */
public class COM_STH_Test {
    @Test
    public void convertPDF2SWFTest() {
        try {
            SwfToolsHelper.convertPDF2SWF("/Users/zhangfeng/Desktop/单元测试计划书.pdf", "/Users/zhangfeng/Desktop/单元测试计划书.swf");
        } catch (IOException e) {

        }
    }
}
