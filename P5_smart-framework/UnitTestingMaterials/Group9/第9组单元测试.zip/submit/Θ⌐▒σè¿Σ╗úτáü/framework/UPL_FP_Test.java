package com.zhangfeng.framework;

import com.baomidou.framework.common.SwConstants;
import com.baomidou.framework.upload.UploadFileRenamePolicy;
import com.baomidou.framework.upload.UploadMultipartRequest;
import com.baomidou.framework.upload.multipart.FilePart;
import com.baomidou.framework.upload.multipart.FileRenamePolicy;
import com.baomidou.framework.upload.multipart.MultipartParser;
import com.baomidou.framework.upload.multipart.Part;
import com.zhangfeng.framework.util.LogInterceptor;
import com.zhangfeng.framework.util.LogLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.web.MockHttpServletRequest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Created by zhangfeng on 2017/6/2.
 */
public class UPL_FP_Test {
    public static MockHttpServletRequest request;
    public byte[] file;
    private static final String LOGGER_NAME = "com.zhangfeng.framework";
    private static final Logger log = LoggerFactory.getLogger(LOGGER_NAME);

    @BeforeTest
    public void setUpRequest() {
        request = new MockHttpServletRequest();
        file = ("--???\n" +
                "Content-Disposition: form-data; name=\"title\" \n\n" +
                "first mock multipart request\n" +
                "--???\n" +
                "Content-Disposition: form-data; name=\"name\" \n\n" +
                "fuck you stupid asshole\n" +
                "--???\n" +
                "Content-Disposition: form-data; name=\"file\" filename=\"excuseme.txt\" \n" +
                "Content-Type: text/plain\n\n" +
                "And! This is the very motherfucker I am looking for!!!!!!!!1faq\n" +
                "--???--").getBytes();
        request.setContentType("multipart/form-data;boundary=???");
        request.setContent(file);
    }

    @DataProvider(name = "writeTo")
    public static Object[][] writeToData() {
        return new Object[][] {
          // filename, isDirectory, policy,
                {"qwe.txt", "/Users/zhangfeng/Desktop/upload_directory", new UploadFileRenamePolicy()},
                {null, "/Users/zhangfeng/Desktop/upload_directory", new UploadFileRenamePolicy()},
                {"qwe.txt", "/Users/zhangfeng/Desktop/not_exists/no.txt", new UploadFileRenamePolicy()},
                {"qwe.txt", "/Users/zhangfeng/Desktop/upload_directory", null}
        };
    }

    @Test(dataProvider = "writeTo")
    public void writeToTest(Object filename, Object directory, Object policy) throws Exception {
        UploadMultipartRequest uploadMultipartRequest = new UploadMultipartRequest(request, "/Users/zhangfeng/Desktop/upload_directory");
        MultipartParser parser = new MultipartParser(request, 1024 * 1024, true, true, SwConstants.UTF_8);
        Part part;
        while ((part = parser.readNextPart()) != null) { // 133
            if (part.isFile()) {
                FilePart filePart = (FilePart) part;
                filePart.setRenamePolicy((FileRenamePolicy)policy);
                Field f_filename = filePart.getClass().getDeclaredField("fileName");
                f_filename.setAccessible(true);
                f_filename.set(filePart, filename);
                LogInterceptor.clear();
                try {
                    filePart.writeTo(new File((String)directory));
                } catch (Exception e) {

                }
                LogInterceptor.printLog(LogLevel.DEBUG);
            }
        }
    }
}
