package org.apache.rocketmq.store.CommitLogTest;
import org.apache.rocketmq.common.message.MessageDecoder;
import org.apache.rocketmq.store.*;
import org.apache.rocketmq.store.config.MessageStoreConfig;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.junit.*;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.Console;
import java.io.IOError;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.ByteBuffer;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import static org.mockito.Mockito.*;
/**
 * Created by Vsooong on 2017/5/30.
 */
public class CommitLogTest {

  @Mock  private CommitLog commitLog;
  @Mock  private DefaultMessageStore master;

    private class MyMessageArrivingListener implements MessageArrivingListener {
        @Override
        public void arriving(String topic, int queueId, long logicOffset, long tagsCode) {
        }
    }
    @BeforeClass
//    public void init() throws IOException {
//
//    }

    @DataProvider(name = "isMappedFileMatchedRecoverTestCase")
    public static Object[][] con(){
        return new Object[][]{
                {true,null,null,null,null,null},
                {false,true,null,null,null,null},
                {false,false,true,true,true,null},
                {false,false,false,true,null,true},
                {false,false,false,false,null,true},
                {false,false,false,true,null,false},
                {false,false,false,false,null,false}
        };
    }
    @Test(dataProvider = "isMappedFileMatchedRecoverTestCase")
    public void  isMappedFileMatchedRecoverTest(
            Object magicNE,Object zeroEstore,Object isMessageIndexEnable,Object isMesagSafe,
            Object smlTimestampIndex, Object smlTimestamp
    ) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, IOException, NoSuchFieldException {

        master=Mockito.mock(DefaultMessageStore.class);
        commitLog=Mockito.mock(CommitLog.class);

        MappedFile mappedFile=Mockito.mock(MappedFile.class);
        ByteBuffer byteBuffer=Mockito.mock(ByteBuffer.class);
        if(magicNE!=null && (boolean)magicNE){
            when(byteBuffer.getInt(MessageDecoder.MESSAGE_MAGIC_CODE_POSTION)).thenReturn(0);
            doReturn(byteBuffer).when(mappedFile).sliceByteBuffer();
            Boolean res=(Boolean)commitLog.isMappedFileMatchedRecover(mappedFile);
            assertEquals(res,false);
            return;
        }
        else {
            when(byteBuffer.getInt(MessageDecoder.MESSAGE_MAGIC_CODE_POSTION)).thenReturn(MessageDecoder.MESSAGE_MAGIC_CODE);
            doReturn(byteBuffer).when(mappedFile).sliceByteBuffer();
        }

        if(zeroEstore!=null &&(boolean)zeroEstore){
            when(byteBuffer.getLong(MessageDecoder.MESSAGE_STORE_TIMESTAMP_POSTION)).thenReturn((long) 0);
            Boolean res=(Boolean)commitLog.isMappedFileMatchedRecover(mappedFile);
            assertEquals(res,false);
            return;
        }
        else {
            when(byteBuffer.getLong(MessageDecoder.MESSAGE_STORE_TIMESTAMP_POSTION)).thenReturn((long) 1);
        }

        MessageStoreConfig mmessageStoreConfig=Mockito.mock(MessageStoreConfig.class);
        when(master.getMessageStoreConfig()).thenReturn(mmessageStoreConfig);

        if(isMessageIndexEnable!=null && (boolean)isMessageIndexEnable && isMesagSafe!=null
                && (boolean)isMesagSafe)
        {

            when(master.getMessageStoreConfig().isMessageIndexEnable()).thenReturn(true);
            when(master.getMessageStoreConfig().isMessageIndexSafe()).thenReturn(true);
            if(smlTimestampIndex!=null&& (boolean)smlTimestampIndex){
                StoreCheckpoint storeCheckpoint=when(Mockito.mock(StoreCheckpoint.class).getMinTimestampIndex()).thenReturn((long) 100).getMock();
                when(commitLog.isMappedFileMatchedRecover(mappedFile)).thenReturn(true);
                when(master.getStoreCheckpoint()).thenReturn(storeCheckpoint);

                Boolean res=(Boolean)commitLog.isMappedFileMatchedRecover(mappedFile);
                assertEquals(res,true);
                return;
            }
            StoreCheckpoint storeCheckpoint=when(Mockito.mock(StoreCheckpoint.class).getMinTimestampIndex()).thenReturn((long) -100).getMock();
            when(master.getStoreCheckpoint()).thenReturn(storeCheckpoint);
            Boolean res=(Boolean)commitLog.isMappedFileMatchedRecover(mappedFile);
            assertEquals(res,false);


        }
        else {
            if(smlTimestamp!=null && (boolean)smlTimestamp){
                StoreCheckpoint storeCheckpoint=when(Mockito.mock(StoreCheckpoint.class).getMinTimestamp()).thenReturn((long) 200).getMock();
                when(master.getStoreCheckpoint()).thenReturn(storeCheckpoint);
                Boolean res=(Boolean)commitLog.isMappedFileMatchedRecover(mappedFile);
                assertEquals(res,false);
                return;
            }
            StoreCheckpoint storeCheckpoint=when(Mockito.mock(StoreCheckpoint.class).getMinTimestamp()).thenReturn((long) -100).getMock();
            when(master.getStoreCheckpoint()).thenReturn(storeCheckpoint);
            Boolean res=(Boolean)commitLog.isMappedFileMatchedRecover(mappedFile);
            assertEquals(res,false);
        }

    }



    @DataProvider(name = "checkMessageAndReturnSizeTestCase")
    public static Object[][] dp2(){
        return new Object[][]{
                {"readLength","MESSAGE_MAGIC_CODE",1,"crc+1",1,0,false,false,false},
                {"readLength+1","MESSAGE_MAGIC_CODE",0,"crc",0,1,true,true,false},
                {"readLength+1","BLANK_MAGIC_CODE",1,"crc",0,0,true,false,true},
                {"readLength","default",0,"crc+1",0,1,false,true,false},
        {"readLength+1","default",0,"crc",1,1,true,false,false},
        {"readLength+1","BLANK_MAGIC_CODE",0,"crc+1",1,0,false,true,true},
        {"readLength","BLANK_MAGIC_CODE",1,"crc+1",1,1,true,true,true},
        {"readLength","default",1,"crc",1,0,false,false,false}
        };
    }
   @Test(dataProvider ="checkMessageAndReturnSizeTestCase" )
    public void  checkMessageAndReturnSizeTest(
            Object totalSize,Object magicCode,Object bodyLen,Object bodyCRC,
            Object propertiesLength, Object getTiming, Object checkCRC, Object readBody,
            Object expectedSuc
    ) {
        commitLog = Mockito.mock(CommitLog.class);
       when(commitLog.calMsgLength(anyInt(),anyInt(),anyInt())).thenCallRealMethod();

       int readl=commitLog.calMsgLength(100,100,100);
        ByteBuffer byteBuffer=ByteBuffer.allocate(readl+100);
        if( ((String) totalSize).equals("readLength")){
            byteBuffer.putInt(readl);
        }
        else byteBuffer.putInt(readl+1);

        if(((String)magicCode).equals("MESSAGE_MAGIC_CODE")){
            byteBuffer.putInt(0xAABBCCDD ^ 1880681586 + 8);
        }
        else if(((String)magicCode).equals("BLANK_MAGIC_CODE")){
            byteBuffer.putInt(0xBBCCDDEE ^ 1880681586 + 8);
        }
        else byteBuffer.putInt(0);

        if(((String)bodyCRC).equals("crc")){
            byteBuffer.putInt(0);
        }
        else byteBuffer.putInt(1);

        byteBuffer.putInt(100);// 4 QUEUEID
        byteBuffer.putInt(1);// 5 FLAG
        byteBuffer.putInt(1);// 6 QUEUEOFFSET
       byteBuffer.putLong(1);// 7 PHYSICALOFFSET
       byteBuffer.putInt(1);// 8 SYSFLAG
       byteBuffer.putLong(100);// 9 BORNTIMESTAMP
       ByteBuffer newBytebuffer=ByteBuffer.allocate(8);
       byteBuffer.put(newBytebuffer);
       byteBuffer.putLong(100);// 11 STORETIMESTAMP
       newBytebuffer=ByteBuffer.allocate(8);
       byteBuffer.put(newBytebuffer);
       byteBuffer.putInt(1);// 13 RECONSUMETIMES
       byteBuffer.putLong(100);// 14 Prepared Transaction Offset
       byteBuffer.putInt(100);// 15 BODY
       newBytebuffer=ByteBuffer.allocate(1);
       byteBuffer.put(newBytebuffer);// 16 TOPIC
       if((int)propertiesLength==0)// 17 properties
           byteBuffer.putShort((short) 0);
       else byteBuffer.putShort((short)1);

       byteBuffer.flip();
        when(commitLog.checkMessageAndReturnSize((ByteBuffer) any(),anyBoolean(),anyBoolean())).thenCallRealMethod();
        DispatchRequest newdr=commitLog.checkMessageAndReturnSize(byteBuffer,(boolean)checkCRC,(boolean)readBody);
        verify(commitLog).checkMessageAndReturnSize(byteBuffer,(boolean)checkCRC,(boolean)readBody);
        assertEquals(newdr.isSuccess(),(boolean)expectedSuc);
    }

    @DataProvider(name="calMsgLengthTestCase")
    public static Object[][] dp3(){
        return new Object[][]{
                {-1,100,100,291},
                {0,100,100,291},
                {100,100,100,391},
                {2147483647,100,100,32962},
                {100,-1,100,290},
                {100,0,100,291},
                {100,127,100,418},
                {100,100,-1,291},
                {100,100,0,291},
                {100,100,32671,32962}
        };
    }
    @Test(dataProvider = "calMsgLengthTestCase")
    public void calMsgLengthTest(Object bodylen, Object topiclen, Object propertylen,Object expect)
            throws NoSuchMethodException, InvocationTargetException, IllegalAccessException
    {
        commitLog=Mockito.mock(CommitLog.class);
        when(commitLog.calMsgLength(anyInt(),anyInt(),anyInt())).thenCallRealMethod();
        int res=commitLog.calMsgLength((int)bodylen,(int)topiclen,(int)propertylen);
       // verify(commitLog).calMsgLength(anyInt(),anyInt(),anyInt());
        assertEquals(res,(int)expect);
    }
    @DataProvider(name="runTestCase")
    public static Object[][] dp4(){
        return new Object[][]{
                {false,false,false},
                {true,false,false},
                {false,false,true}
        };
    }
    @Ignore
    @Test(dataProvider = "runTestCase")
    public  void runTest(
            Object isStop,Object exception,  Object InterruptedException
    ){
        commitLog=Mockito.mock(CommitLog.class);
        CommitLog.GroupCommitService groupCommitService=commitLog.new GroupCommitService();
      //  CommitLog.GroupCommitService groupCommitService=Mockito.mock(CommitLog.GroupCommitService.class);
        groupCommitService.run();
        groupCommitService.shutdown();
        if((boolean)isStop){
            groupCommitService.shutdown();
        }
        verify(groupCommitService,timeout(2000)).run();
    }
}












