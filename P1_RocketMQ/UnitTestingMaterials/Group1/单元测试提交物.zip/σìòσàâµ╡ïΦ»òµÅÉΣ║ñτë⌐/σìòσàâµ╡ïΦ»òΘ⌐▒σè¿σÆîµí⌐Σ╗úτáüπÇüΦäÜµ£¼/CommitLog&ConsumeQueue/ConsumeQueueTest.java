package org.apache.rocketmq.store.ConsumeQueueTest;

import org.apache.rocketmq.common.BrokerConfig;
import org.apache.rocketmq.common.message.MessageDecoder;
import org.apache.rocketmq.store.*;
import org.apache.rocketmq.store.config.MessageStoreConfig;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import java.io.IOException;
import static org.junit.Assert.assertEquals;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.junit.*;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import java.util.List;

import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.*;
/**
 * Created by Vsooong on 2017/5/30.
 */
public class ConsumeQueueTest
{
    private ConsumeQueue consumeQueue;
    private DefaultMessageStore master;
    private class MyMessageArrivingListener implements MessageArrivingListener {
        @Override
        public void arriving(String topic, int queueId, long logicOffset, long tagsCode) {
        }
    }
    public ConsumeQueueTest() throws IOException {
        MessageStoreConfig messageStoreConfig = new MessageStoreConfig();
        messageStoreConfig.setMapedFileSizeCommitLog(1024 * 8);
        messageStoreConfig.setMapedFileSizeConsumeQueue(1024 * 4);
        messageStoreConfig.setMaxHashSlotNum(100);
        messageStoreConfig.setMaxIndexNum(100 * 10);
        master = new DefaultMessageStore(messageStoreConfig, null, new MyMessageArrivingListener(), new BrokerConfig());
        consumeQueue=new ConsumeQueue("topic1",1,"f:/storepath",100,master );
    }
    @DataProvider(name = "putMessagePositionInfoTestCase")
    public static Object[][] dp1(){
        return new Object[][]{
                {0,0,true},
                {0,1,true},
                {1000,0,true},
                {1000,1,true}
        };
    }
    @Test(dataProvider = "putMessagePositionInfoTestCase")
    public void  putMessagePositionInfoTest(
            Object offset, Object cqoffset, Object expect
    ) throws  IOException, NoSuchFieldException
    {
        boolean res=consumeQueue.putMessagePositionInfo(Long.parseLong(offset.toString()),100, Long.parseLong("100"),Long.parseLong(cqoffset.toString()));
        assertEquals(res,(boolean)expect);
    }

    @DataProvider (name="getIndexBufferTestCase")
    public static Object[][] dp2(){
        return new Object[][]{
                {5,"null"},{6,"res"},{10,"res"},{0,"null"},{-1,"null"}
        };
    }
    @Test (dataProvider = "getIndexBufferTestCase")
    public void getIndexBufferTest(Object startIndex, Object Null) throws IOException {

        consumeQueue.setMinLogicOffset(100);
        SelectMappedBufferResult result=consumeQueue.getIndexBuffer(Long.parseLong(startIndex.toString()));
        if(((String)Null).equals("null")){
            assert (result==null);
        }
        else assert(result!=null);
    }
    @DataProvider(name = "correctMinOffsetTestCase")
    public static Object[][] dp3(){
        return new Object[][]{
                {0},
                {10},
                {20},
                {21}
        };
    }
    @Test(dataProvider = "correctMinOffsetTestCase")
    public void  correctMinOffsetTest(
            Object phyMinOffset
    ) throws  IOException, NoSuchFieldException
    {
        consumeQueue.correctMinOffset(Long.parseLong(phyMinOffset.toString()));
    }
    @DataProvider(name = "getLastOffsetTestCase")
    public static Object[][] dp4(){
        return new Object[][]{
                {true,true,true,true},
                {true,false,true,true},
                {true,true,false,true},
                {true,false,false,true}
        };
    }
    @Test(dataProvider = "getLastOffsetTestCase")
    public void  getLastOffsetTest(
            Object mappedFileNotEm, Object positionSM ,Object offset ,Object size
    ) throws  IOException, NoSuchFieldException
    {
        ConsumeQueue  consumeQueue;
        MessageStoreConfig messageStoreConfig = new MessageStoreConfig();
        messageStoreConfig.setMapedFileSizeCommitLog(1024 * 8);
        messageStoreConfig.setMapedFileSizeConsumeQueue(1024 * 4);
        messageStoreConfig.setMaxHashSlotNum(100);
        messageStoreConfig.setMaxIndexNum(100 * 10);
        DefaultMessageStore master = new DefaultMessageStore(messageStoreConfig, null, new MyMessageArrivingListener(), new BrokerConfig());
        if(mappedFileNotEm!=null && (boolean)mappedFileNotEm){
             consumeQueue=new ConsumeQueue("topic1",1,"f:/storepath",100,master );
             if(positionSM!=null && (boolean)positionSM){
                // consumeQueue.getMFQ().getLastMappedFile().setWrotePosition(-1);
             }
             else{
              //   consumeQueue.getMFQ().getLastMappedFile().setWrotePosition(10);
             }
             if(offset!=null&& (boolean)offset && size!=null && (boolean)size){
                 consumeQueue.getMFQ().getLastMappedFile().getMappedByteBuffer().reset();
                 consumeQueue.getMFQ().getLastMappedFile().getMappedByteBuffer().putLong(1);
                 consumeQueue.getMFQ().getLastMappedFile().getMappedByteBuffer().putInt(1);
                 consumeQueue.getMFQ().getLastMappedFile().getMappedByteBuffer().flip();
             }
             else {
                 consumeQueue.getMFQ().getLastMappedFile().getMappedByteBuffer().reset();
                 consumeQueue.getMFQ().getLastMappedFile().getMappedByteBuffer().putLong(-1);
                 consumeQueue.getMFQ().getLastMappedFile().getMappedByteBuffer().putInt(0);
                 consumeQueue.getMFQ().getLastMappedFile().getMappedByteBuffer().flip();
             }

            long res=consumeQueue.getLastOffset();
            assertEquals(res,-1);
        }
        else {
             consumeQueue=new ConsumeQueue("topic1",1,"/",0,master );
            long res=consumeQueue.getLastOffset();
            assertNotEquals(res,(long)-1);
        }

    }
    @DataProvider(name = "rollNextFileTestCase")
    public static Object[][] dp5(){
        return new Object[][]{
                {100,100,105},
                {0,100,5},
                {-1,100,5},
                {101,100,105},
                {51,50,52},
                {50,50,52}
        };
    }
    @Test(dataProvider = "rollNextFileTestCase")
    public void  rollNextFileTest(
            Object index,Object mappedfilesize,Object expect
    ) throws  IOException, NoSuchFieldException
    {
        consumeQueue=new ConsumeQueue("topic1",1,"/",(int)mappedfilesize, master );

        long res= consumeQueue.rollNextFile(Long.parseLong(index.toString()));
        assertEquals(res,Long.parseLong(expect.toString()));
        System.out.println(res);
    }
    @DataProvider(name = "getOffsetInQueueByTimeTestCase")
    public static Object[][] dp6(){
        return new Object[][]{
                {19690101000000L,100},
                {20170601123453L,100},
                {20380119031499L,100},
                {20170601123453L,0},
                {20380119031499L,0}
        };
    }
    @Test(dataProvider = "getOffsetInQueueByTimeTestCase")
    public void  getOffsetInQueueByTimeTest(
            Object stamp,Object mappedfilesize
    ) throws  IOException, NoSuchFieldException
    {
        consumeQueue=new ConsumeQueue("topic1",1,"F:/mappedFiles",(int)mappedfilesize, master );
        MappedFileQueue mfq=consumeQueue.getMFQ();
        mfq.destroy();
        List<MappedFile> mappedFiles=mfq.getMappedFiles();
        MappedFile mappedFile = new MappedFile("1", (int)mappedfilesize);
        mappedFile.setWrotePosition((int)mappedfilesize);
        mappedFile.setFlushedPosition((int)mappedfilesize);
        mappedFile.setCommittedPosition((int)mappedfilesize);
        long timestamp= mappedFile.getLastModifiedTimestamp();
        mappedFiles.add(mappedFile);

        long res= consumeQueue.getOffsetInQueueByTime(Long.parseLong(stamp.toString()));
        System.out.println(res);
    }

}


