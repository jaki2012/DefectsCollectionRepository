package com.wave.store.util;

import ch.qos.logback.core.OutputStreamAppender;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

/**
 * Created by jixunzhen on 30/05/2017.
 */
public class LogInterceptor extends OutputStreamAppender{
    private static ArrayList<String> errors=new ArrayList<>();
    private static ArrayList<String > warns=new ArrayList<>();
    private static ArrayList<String> infos=new ArrayList<>();
    private static ArrayList<String > debugs=new ArrayList<>();

    private static ByteArrayOutputStream stream=new ByteArrayOutputStream();

    @Override
    public void start() {
        this.setOutputStream(stream);
        super.start();
    }

    @Override
    public void doAppend(Object eventObject) {
        String content=eventObject.toString();
        String headInfo=content.substring(0,7);
        if(headInfo.contains("ERROR")){
            errors.add(content.substring(8));
        }else if(headInfo.contains("WARN")){
            warns.add(content.substring(7));
        }else if(headInfo.contains("INFO")){
            infos.add(content.substring(7));
        }else if(headInfo.contains("DEBUG")){
            debugs.add(content.substring(8));
        }
        super.doAppend(eventObject);
    }

    public static boolean assertLog(LogLevel level, String content) {
        ArrayList<String> list = null;
        switch (level) {
            case DEBUG:
                list = debugs;
                break;
            case INFO:
                list = infos;
                break;
            case ERROR:
                list = errors;
                break;
            case WARN:
                list = warns;
                break;
            default:
                break;
        }
        if (list != null) {
            for (String string : list) {
                if (string.equals(content)) {
                    return true;
                }
            }
        }

        return false;
    }

    public static void clear(){
        debugs.clear();
        infos.clear();
        warns.clear();
        errors.clear();
    }

    public static void printLog(LogLevel level){
        ArrayList<String> list=null;

        switch (level){
            case ERROR:
                list=errors;
                break;
            case WARN:
                list=warns;
                break;
            case INFO:
                list=infos;
                break;
            case DEBUG:
                list=debugs;
                break;
            default:
                break;
        }
        if(list!=null){
            System.out.println("[Print Log] - "+level.toString());
            for(String string:list){
                System.out.println(string);
            }
        }
    }
}

