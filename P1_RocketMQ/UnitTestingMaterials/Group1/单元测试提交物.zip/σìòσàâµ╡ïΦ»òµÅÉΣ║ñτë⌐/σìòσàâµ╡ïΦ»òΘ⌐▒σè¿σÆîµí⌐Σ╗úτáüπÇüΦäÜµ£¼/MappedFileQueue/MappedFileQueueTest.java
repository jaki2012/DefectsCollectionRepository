
//DataProvider 读取Excel并返回数据表格
//用法：name用于被外部调用
//@DataProvider(name = "getMinOffset")
//public static Object[][]  getMinOffsetData()throws Exception{
//    return ExcelUtil.getxxxx();
//}

//BeforeTest 再函数被调用之前调用的方法
//用法：groups声明组别，当同组函数被调用时就会调用这个beforeTest
//@BeforeTest(groups = {"whiteBox"})
//public void init(){
//        mappedFileQueue =
//        new MappedFileQueue("target/unit_test_store/a/", 1024, null);
//        }

//测试函数，groups用于声明组别，方便调用beforeTest，dataProvider调用同名的DataProvider
//@Test(groups = {"whiteBox"},dataProvider = "getMinOffset")
//public void getMinOffsetTest(Object val){
//}
package com.wave.store;

import com.wave.store.util.ExcelUtil;
import com.wave.store.util.LogInterceptor;
import com.wave.store.util.LogLevel;
import org.apache.rocketmq.store.*;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.omg.CORBA.OBJ_ADAPTER;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.awt.*;
import java.awt.List;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.shouldHaveThrown;
import static org.mockito.Matchers.booleanThat;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

/**
 * Created by Administrator on 2017/5/29.
 */
public class MappedFileQueueTest {
    MappedFileQueue mappedFileQueue;                        //文件队列
    CopyOnWriteArrayList<MappedFile> mappedFiles;           //mock的队列数组
    private static final String className = "MappedFileQueue";
    private static final String rootPath = "C:\\Users\\Administrator\\Desktop\\tool\\projects\\软件测试\\期末测试\\test\\";

    private static final Map<String,String> filePaths = new HashMap<String,String>(){{
        put("oneFile","oneFile");
        put("twoFileErr","twoFileErr");
        put("twoFileSucc","twoFileSucc");
        put("threeFileErr","threeFileErr");
        put("threeFileSucc","threeFileSucc");
        put("empty","empty");
        put("files","files");
        put("null","null");
    }
    };


    @BeforeTest(groups = {"whiteBox"})
    public void init() {
        mappedFileQueue =
                new MappedFileQueue("target/unit_test_store/a/", 1024, null);
        mappedFiles = Mockito.mock(CopyOnWriteArrayList.class);
    }

    //添加文件到文件队列中
    private void loadInit(Integer fileSize,boolean isAllMatch){
        String filePath = "files";
        switch (fileSize){
            case -1:
                filePath = filePaths.get("null");
                break;
            case 0:
                filePath = filePaths.get("empty");
                break;
            case 1:
                filePath = filePaths.get("oneFile");
                break;
            case 2:
                if(isAllMatch) filePath = filePaths.get("twoFileSucc");
                else filePath = filePaths.get("twoFileErr");
                break;
            case 3:
                if(isAllMatch) filePath = filePaths.get("threeFileSucc");
                else filePath = filePaths.get("threeFileErr");
                break;
        }
        load("C:\\Users\\Administrator\\Desktop\\tool\\projects\\软件测试\\期末测试\\test\\" + filePath);
    }
    private void load(String fileName) {
        init();
        File dir = new File(fileName);
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                try {
                    MappedFile mappedFile = new MappedFile(file.getPath(), 1024);
                    mappedFile.setWrotePosition(1024);
                    mappedFile.setFlushedPosition(1024);
                    mappedFile.setCommittedPosition(1024);
                    mappedFileQueue.getMappedFiles().add(mappedFile);
                } catch (IOException e) {
                }
            }
        }
    }

    //通过反射把队列中的数组用mock的数组替换
    private void field() throws NoSuchFieldException, IllegalAccessException {
        Field mappedFilesField = mappedFileQueue.getClass().getDeclaredField("mappedFiles");
        mappedFilesField.setAccessible(true);
        mappedFilesField.set(mappedFileQueue, mappedFiles);
    }



    @DataProvider(name = "deleteExpiredFileByTime")
    public static Object[][] deleteExpireFileByTimeData() throws Exception {
        return ExcelUtil.getInputData("deleteExpiredFileByTime",className);
    }
    @Test(groups = {"whiteBox"},dataProvider = "deleteExpiredFileByTime")
    public void deleteExpiredFileByTimeTest(Object fileSize,Object expiredTime,Object clean,Object destroy,Object size,Object interval){
        Integer fsize = Integer.parseInt(fileSize.toString());
        Long expiredT = expiredTime.toString().equals("-") ? 0L : Long.parseLong(expiredTime.toString());
        Integer deleteInterval = interval.toString().equals("-") ? 0 : Integer.parseInt(interval.toString());
        boolean cleanInmi = clean.toString().equals("false") ? false :true;
        init();

        //mock select方法
        if(fsize > 1){
            MappedFile mappedFile = Mockito.mock(MappedFile.class);
            when(mappedFile.destroy(Mockito.anyInt())).thenReturn(destroy.toString().equals("false") ? false : true);
            when(mappedFile.getLastModifiedTimestamp()).thenReturn(System.currentTimeMillis() - 1000);

            for(int i = 0;i < fsize; i ++){
                mappedFileQueue.getMappedFiles().add(mappedFile);
            }
        }
        else loadInit(fsize,true);

        System.out.println("[ deleteExpiredFileByTime ] " + mappedFileQueue.deleteExpiredFileByTime(expiredT,deleteInterval,1000,cleanInmi));
    }

    /**
     * deleteExpiredFileByOffset test
     * @return
     * @throws Exception
     */
    @DataProvider(name = "deleteExpiredFileByOffset")
    public static Object[][] deleteExpiredFileByOffsetData() throws Exception {
        return ExcelUtil.getInputData("deleteExpiredFileByOffset",className);
    }
    @Test(groups = {"whiteBox"},dataProvider = "deleteExpiredFileByOffset")
    public void deleteExpiredFileByOffsetTest(Object fileSize,Object selectBuffer,Object isFileAvailable,Object maxOffset,Object offset,Object isDestory) throws NoSuchFieldException, IllegalAccessException {
        Integer size = Integer.parseInt(fileSize.toString());
        Long off = offset.toString().equals("-") ? 0L :Long.parseLong(offset.toString());
        init();

        //mock select方法
        if(size > 1){
            ByteBuffer byteBuffer = Mockito.mock(ByteBuffer.class);
            when(byteBuffer.getLong()).thenReturn(maxOffset.toString().equals("-") ? 0L : Long.parseLong(maxOffset.toString()));

            SelectMappedBufferResult selectMappedBufferResult = Mockito.mock(SelectMappedBufferResult.class);
            when(selectMappedBufferResult.getByteBuffer()).thenReturn(byteBuffer);

            MappedFile mappedFile = Mockito.mock(MappedFile.class);
            when(mappedFile.selectMappedBuffer(Mockito.anyInt())).thenReturn(selectBuffer.toString().equals("!null") ? selectMappedBufferResult : null);
            when(mappedFile.isAvailable()).thenReturn(isFileAvailable.toString().equals("false") ? false :true);
            when(mappedFile.destroy(Mockito.anyInt())).thenReturn(isDestory.toString().equals("false") ? false : true);

            mappedFileQueue.getMappedFiles().add(mappedFile);
            mappedFileQueue.getMappedFiles().add(mappedFile);
        }
        else loadInit(size,true);

        System.out.println("[ deleteExpiredFileByOffset ] " + mappedFileQueue.deleteExpiredFileByOffset(off,100));
    }


    /**
     * howMuchFallBehind test
     * @return
     * @throws Exception
     */
    @DataProvider(name = "howMuchFallBehind")
    public static Object[][] howMuchFallBehindData() throws Exception {
        return ExcelUtil.getInputData("howMuchFallBehind", className);
    }

    @Test(groups = {"whiteBox"}, dataProvider = "howMuchFallBehind")
    public void howMuchFallBehindTest(Object fileSize,Object flushed,Object lastFile) throws NoSuchFieldException, IllegalAccessException {
        init();
        Integer size = Integer.parseInt(fileSize.toString());
        Integer flush = flushed.toString().equals("-") ? 0 : Integer.parseInt(flushed.toString());

        loadInit(size,true);
        Field flushedWhereField = mappedFileQueue.getClass().getDeclaredField("flushedWhere");
        flushedWhereField.setAccessible(true);
        flushedWhereField.set(mappedFileQueue, flush);

        if(lastFile.toString().equals("null")){
            when(mappedFiles.isEmpty()).thenReturn(false);
            field();
        }

        System.out.println("[ howMuchFallBehind ] " + mappedFileQueue.howMuchFallBehind());

    }


    /**
     * getLastMappedFileArgs test
     * @return
     * @throws Exception
     */
    @DataProvider(name = "getLastMappedFileArgs")
    public static Object[][] getLastMappedFileArgsData() throws Exception {
        return ExcelUtil.getInputData("getLastMappedFileArgs",className);
    }
    @Test(groups = {"whiteBox"},dataProvider = "getLastMappedFileArgs")
    public void getLastMappedFileArgs(Object fileSize,Object isFull,Object startOffset,Object needCreate,Object allocate,Object mappedFile) throws IOException {
        Integer size = Integer.parseInt(fileSize.toString());
        boolean full = isFull.toString().equals("false") ? false : true;
        boolean create = needCreate.toString().equals("false") ? false : true;
        init();

        if(allocate.toString().equals("!null")){
            AllocateMappedFileService allocateMappedFileService = Mockito.mock(AllocateMappedFileService.class);
            when(allocateMappedFileService.putRequestAndReturnMappedFile(Mockito.anyString(),Mockito.anyString(),Mockito.anyInt())).thenReturn(mappedFile.toString().equals("null") ? null : new MappedFile());
            mappedFileQueue =
                    new MappedFileQueue("target/unit_test_store/a/", 1024, allocateMappedFileService);
        }

        if(size > 0){
            MappedFile fullFile = new MappedFile(rootPath + "oneFile\\0",1024);
            if(full){
                fullFile.setWrotePosition(1024);
                fullFile.setFlushedPosition(1024);
                fullFile.setCommittedPosition(1024);
            }
            mappedFileQueue.getMappedFiles().add(fullFile);
        }

        System.out.println("[ getLastMappedFileArgs ]" + mappedFileQueue.getLastMappedFile(100,create));
    }


    /**
     * findMappedFileByOffset test
     * @return
     * @throws Exception
     */
    @DataProvider(name = "findMappedFileByOffset")
    public  static Object[][] findMappedFileByOffsetData() throws Exception {
        return ExcelUtil.getInputData("findMappedFileByOffset",className);
    }
    @Test(groups = {"whiteBox"},dataProvider = "findMappedFileByOffset")
    public void findMappedFileByOffsetTest(Object fileSize,Object offset,Object returnFirstOnNotFound){
        Integer size = Integer.parseInt(fileSize.toString());
        Long off = size > 0 ? Long.parseLong(offset.toString()): 0L;
        boolean isReturn = size > 0 ? (boolean)returnFirstOnNotFound : false;

        loadInit(size,true);
        System.out.println("[ findMappedFileByOffsetTest ] "+ mappedFileQueue.findMappedFileByOffset(off,isReturn));
    }


    /**
     * truncateDirtyFiles test
     * @return
     * @throws Exception
     */
    @DataProvider(name = "truncateDirtyFiles")
    public static Object[][] truncateDirtyFiles() throws Exception {
        return ExcelUtil.getInputData("truncateDirtyFiles",className);
    }
    @Test(groups = {"whiteBox"},dataProvider = "truncateDirtyFiles")
    public void truncateDirtyFilesTest(Object fileSize,Object offset){
        Integer size = Integer.parseInt(fileSize.toString());
        Long off = size > 0 ? Long.parseLong(offset.toString()): 0L;

        loadInit(size,true);
        mappedFileQueue.truncateDirtyFiles(off);
    }

    /**
     * retryDeleteFirstFile
     * 需要创建3个文件，每次执行后悔删光所有的文件
     * @return
     * @throws Exception
     */
    @DataProvider(name = "retryDeleteFirstFile")
    public static Object[][] retryDeleteFirstFileData() throws Exception {
        return ExcelUtil.getInputData("retryDeleteFirstFile",className);
    }
    @Test(groups = {"whiteBox"},dataProvider = "retryDeleteFirstFile")
    public void retryDeleteFirstFileTest(Object mappefFileSize,Object isAvailable,Object isDestory) throws IOException, NoSuchFieldException, IllegalAccessException {

        //加载文件
        Integer size = Integer.parseInt(mappefFileSize.toString());
        loadInit(size,true);
        System.out.println("[ BEFORE DELETE ] QUEUE SIZE :" + mappedFileQueue.getMappedFiles().size());

        //让第一个文件状态为不可获得，即之前删除过但是没有移除
        if(mappedFileQueue.getMappedFiles().size() > 0 && isAvailable.toString().equals("false")){
            mappedFileQueue.getMappedFiles().get(0).shutdown(1000);
        }

        //mock destory方法，以此覆盖result为false的路径
        if(isDestory.toString().equals("true")){
            MappedFile mappedFile = Mockito.mock(MappedFile.class);
            when(mappedFile.destroy(Mockito.anyInt())).thenReturn(false);
            mappedFile.shutdown(1000);

            mappedFileQueue.getMappedFiles().set(0,mappedFile);
        }

        //运行结果
        System.out.println("[ retryDeleteFirstFile ]" + mappedFileQueue.retryDeleteFirstFile(1000));
        System.out.println("[ AFTER  DELETE ] QUEUE SIZE :" + mappedFileQueue.getMappedFiles().size() + "\n");
    }

    /**
     * deleteExpiredFile test
     * @return
     * @throws Exception
     */
    @DataProvider(name = "deleteExpiredFile")
    public static Object[][] deleteExpiredFileData() throws Exception {
        return ExcelUtil.getInputData("deleteExpiredFile",className);
    }
    @Test(groups = {"whiteBox"},dataProvider = "deleteExpiredFile")
    public void deleteExpiredFileTest(Object filesSize,Object isAllContained,Object isRemoveAll) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, NoSuchFieldException, IOException {

        //装载文件
        Integer size = Integer.parseInt(filesSize.toString());
        loadInit(size,true);
        System.out.println("[ BEFORE DELETE ] QUEUE SIZE :" + mappedFileQueue.getMappedFiles().size());

        //填充files文件
        java.util.List<MappedFile> files = new ArrayList<MappedFile>();
        if(mappedFileQueue.getMappedFiles().size() > 0 && isAllContained.toString().equals("true")){
            files.add(mappedFileQueue.getMappedFiles().get(0));
        }
        else if(size > 0){
            files.add(new MappedFile("1",10));
        }
        if(mappedFileQueue.getMappedFiles().size() > 0 && isAllContained.toString().equals("false") && isRemoveAll.toString().equals("true")){
            files.add(mappedFileQueue.getMappedFiles().get(0));
        }

        //反射调用deleteExpiredFile方法
        Method  method = mappedFileQueue.getClass().getDeclaredMethod("deleteExpiredFile", java.util.List.class);
        method.setAccessible(true);
        method.invoke(mappedFileQueue, files);
        System.out.println("[ AFTER  DELETE ] QUEUE SIZE :" + mappedFileQueue.getMappedFiles().size() + "\n");
    }



    /**
     * getMappedFileByTime test
     * @return
     * @throws Exception
     */
    @DataProvider(name = "getMappedFileByTime")
    public static Object[][] getMappedFileByTimeData() throws Exception {
        return ExcelUtil.getInputData("getMappedFileByTime",className);
    }
    @Test(groups = {"whiteBox"},dataProvider = "getMappedFileByTime")
    public void getMappedFileByTime(Object fileSize,Object noUse,Object timestamp){
        Integer size = Integer.parseInt(fileSize.toString());
        Long time = 0L;

        loadInit(size,true);

        if(size > 0) {
            time = Long.parseLong("1496" + timestamp.toString());
        }


        System.out.println("[ getMappedFileByTime ]" + mappedFileQueue.getMappedFileByTime(time));
    }



    /**
     * load test
     * 测试之前需要修改twoFileErr中的文件，是一个文件的大小为0K
     *
     * @return
     * @throws Exception
     */
    @DataProvider(name = "load")
    public static Object[][] loadData() throws Exception {
        return ExcelUtil.getInputData("load", className);
    }

    @Test(groups = {"whiteBox"}, dataProvider = "load")
    public void loadTest(Object fileSize,Object isAllMatch) {
        Integer size = Integer.parseInt(fileSize.toString());
        boolean isMatch = !isAllMatch.toString().equals("false");
        String path = "";
        switch (size){
            case -1:
                path = filePaths.get("null");
                break;
            case 0:
                path = filePaths.get("empty");
                break;
            case 2:
                if(isMatch) path = filePaths.get("twoFileSucc");
                else path = filePaths.get("twoFileErr");
                break;
        }
        mappedFileQueue =
                new MappedFileQueue(rootPath + path, 1024, null);
        mappedFileQueue.load();
    }


    /**
     * getMappedMemorySize test
     *
     * @return
     * @throws Exception
     */
    @DataProvider(name = "getMappedMemorySize")
    public static Object[][] getMappedMemorySizeData() throws Exception {
        return ExcelUtil.getInputData("getMappedMemorySize", className);
    }

    @Test(groups = {"whiteBox"}, dataProvider = "getMappedMemorySize")
    public void getMappedMemorySizeTest(Object filesSize, Object isAllAvailable) {
        Integer size = Integer.parseInt(filesSize.toString());
        loadInit(size,true);

        if (mappedFileQueue.getMappedFiles().size() > 0 && !isAllAvailable.toString().equals("true")) {
            //关闭第一个文件
            mappedFileQueue.getMappedFiles().get(0).shutdown(1000);
        }
        System.out.println("[ getMappedMemorySize ] files count :" + mappedFileQueue.getMappedFiles().size() + " mappedMemorySize :" + mappedFileQueue.getMappedMemorySize());
    }

    /**
     * getLastMappedFile test
     *
     * @return
     * @throws Exception
     */
    @DataProvider(name = "getLastMappedFile")
    public static Object[][] getLastMappedFileData() throws Exception {
        return ExcelUtil.getInputData("getLastMappedFile", className);
    }

    @Test(groups = {"whiteBox"}, dataProvider = "getLastMappedFile")
    public void getLastMappedFileTest(Object filesSize, Object mockIsEmpty, Object mockGet) throws NoSuchFieldException, IllegalAccessException {
        Integer size = Integer.parseInt(filesSize.toString());
        loadInit(size,true);

        if (mockIsEmpty.toString().equals("true")) {
            when(mappedFiles.isEmpty()).thenReturn(false);
            field();
        }
        if (mockGet.toString().equals("true")) {
            when(mappedFiles.get(Mockito.anyInt())).thenThrow(new IndexOutOfBoundsException());
            field();
        }
        System.out.println("[ getLastMappedFile ] files count :" + mappedFileQueue.getMappedFiles().size() + " lastMappedFile :" + mappedFileQueue.getLastMappedFile());
    }


    /**
     * getFirstMappedFile test
     *
     * @return
     * @throws Exception
     */
    @DataProvider(name = "getFirstMappedFile")
    public static Object[][] getFirstMappedFileData() throws Exception {
        return ExcelUtil.getInputData("getFirstMappedFile", className);
    }

    @Test(groups = {"whiteBox"}, dataProvider = "getFirstMappedFile")
    public void getFirstMappedFileTest(Object filesSize, Object mockIsEmpty, Object mockGet) throws NoSuchFieldException, IllegalAccessException {
        Integer size = Integer.parseInt(filesSize.toString());
        loadInit(size,true);

        if (mockIsEmpty.toString().equals("true")) {
            when(mappedFiles.isEmpty()).thenReturn(false);
            field();
        }

        if (mockGet.toString().equals("true")) {
            when(mappedFiles.get(Mockito.anyInt())).thenThrow(new IndexOutOfBoundsException());
            field();
        }
        //路径覆盖1，由于文件队列为空，所以应该返回为null
        System.out.println("[ getFirstMappedFile ] files count :" + mappedFileQueue.getMappedFiles().size() + " firstMappedFile :" + mappedFileQueue.getFirstMappedFile());
    }


    /**
     * getMinOffset test
     *
     * @return
     * @throws Exception
     */
    @DataProvider(name = "getMinOffset")
    public static Object[][] getMinOffsetData() throws Exception {
        return ExcelUtil.getInputData("getMinOffset", className);
    }

    @Test(groups = {"whiteBox"}, dataProvider = "getMinOffset")
    public void getMinOffsetTest(Object filesSize, Object mockIsEmpty, Object mockGet) throws NoSuchFieldException, IllegalAccessException {
        Integer size = Integer.parseInt(filesSize.toString());
        loadInit(size,true);
        if (mockIsEmpty.toString().equals("true")) {
            when(mappedFiles.isEmpty()).thenReturn(false);
            field();
        }
        if (mockGet.toString().equals("true")) {
            when(mappedFiles.get(Mockito.anyInt())).thenThrow(new IndexOutOfBoundsException());
            field();
        }
        System.out.println("[ GetMinOffest ] files count :" + mappedFileQueue.getMappedFiles().size() + " minOffset :" + mappedFileQueue.getMinOffset());
    }


    /**
     * checkSelf test
     *
     * @return
     * @throws Exception
     */
    @DataProvider(name = "checkSelf")
    public static Object[][] checkSelfData() throws Exception {
        return ExcelUtil.getInputData("checkSelf", className);
    }

    @Test(groups = {"whiteBox"}, dataProvider = "checkSelf")
    public void checkSelfTest(Object filesSize, Object isAllMatch, Object exception) throws NoSuchFieldException, IllegalAccessException {
        Integer size = Integer.parseInt(filesSize.toString());
        boolean isMatch = isAllMatch.toString().equals("true");

        loadInit(size,isMatch);

        mappedFileQueue.checkSelf();
        assert LogInterceptor.assertLog(LogLevel.WARN, exception.toString());
        LogInterceptor.clear();
    }
}
