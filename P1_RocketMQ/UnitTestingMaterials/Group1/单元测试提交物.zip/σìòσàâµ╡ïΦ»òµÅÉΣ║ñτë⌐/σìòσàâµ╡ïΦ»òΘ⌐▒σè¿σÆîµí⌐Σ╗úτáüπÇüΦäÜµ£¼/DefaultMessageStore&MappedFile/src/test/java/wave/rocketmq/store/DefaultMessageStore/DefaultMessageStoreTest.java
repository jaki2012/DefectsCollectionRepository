package wave.rocketmq.store.DefaultMessageStore;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;
import org.apache.rocketmq.common.BrokerConfig;
import org.apache.rocketmq.common.ThreadFactoryImpl;
import org.apache.rocketmq.common.protocol.heartbeat.SubscriptionData;
import org.apache.rocketmq.common.sysflag.MessageSysFlag;
import org.apache.rocketmq.store.*;
import org.apache.rocketmq.store.config.BrokerRole;
import org.apache.rocketmq.store.config.FlushDiskType;
import org.apache.rocketmq.store.config.MessageStoreConfig;
import org.apache.rocketmq.store.schedule.ScheduleMessageService;
import org.apache.rocketmq.store.util.MockUtilAll;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.testng.annotations.*;
import sun.rmi.runtime.Log;
import wave.rocketmq.store.util.ExcelUtil;
import wave.rocketmq.store.util.LogInterceptor;
import wave.rocketmq.store.util.LogLevel;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Created by jixunzhen on 25/05/2017.
 */
public class DefaultMessageStoreTest {
    private final String INPUT = "Test For DefaultMessageStore.";
    private static final String className = "DefaultMessageStore";
    private int QUEUE_TOTAL = 100;
    private AtomicInteger QueueId = new AtomicInteger(0);
    private SocketAddress BornHost;
    private SocketAddress StoreHost;
    private DefaultMessageStore store;
    private MessageStoreConfig messageStoreConfig;
    private MessageExtBrokerInner msg;

    private static int count = 1;

    public MessageExtBrokerInner buildMessage() {
        MessageExtBrokerInner msg = new MessageExtBrokerInner();
        msg.setTopic("FooBar");
        msg.setTags("TAG1");
        msg.setKeys("Hello");
        msg.setBody(INPUT.getBytes());
        msg.setKeys(String.valueOf(System.currentTimeMillis()));
        msg.setQueueId(0);
        msg.setSysFlag(4);
        msg.setBornTimestamp(System.currentTimeMillis());
        msg.setStoreHost(StoreHost);
        msg.setBornHost(BornHost);
        return msg;
    }

    public MessageExtBrokerInner buildMessageByNum(int id) {
        MessageExtBrokerInner msg = new MessageExtBrokerInner();
        msg.setTopic("FooBar");
        msg.setTags("TAG1");
        msg.setKeys("Hello");
        msg.setBody((INPUT + id).getBytes());
        msg.setKeys(String.valueOf(System.currentTimeMillis()));
        msg.setQueueId(Math.abs(QueueId.getAndIncrement()) % QUEUE_TOTAL);
        msg.setSysFlag(4);
        msg.setBornTimestamp(System.currentTimeMillis());
        msg.setStoreHost(StoreHost);
        msg.setBornHost(BornHost);
        return msg;
    }

    public PutMessageResult mockPutMessage(boolean isEclipseTime, boolean resultIsNone, boolean resultIsNotOk) {
        if (isEclipseTime) {
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (resultIsNone) {
            return null;
        } else {
            PutMessageResult result = Mockito.mock(PutMessageResult.class);
            Mockito.when(result.isOk()).thenReturn(!resultIsNotOk);
            return result;
        }
    }


    @BeforeGroups(groups = "Init")
    public void init() throws Exception {
        StoreHost = new InetSocketAddress(InetAddress.getLocalHost(), 8123);
        BornHost = new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0);
        MessageStoreConfig messageStoreConfig = new MessageStoreConfig();
        messageStoreConfig.setDiskFallRecorded(false);
        messageStoreConfig.setMapedFileSizeCommitLog(1024 * 8);
        messageStoreConfig.setFlushDiskType(FlushDiskType.SYNC_FLUSH);
        store = new DefaultMessageStore(messageStoreConfig, null, new MessageArrivingListener() {
            @Override
            public void arriving(String topic, int queueId, long logicOffset, long tagsCode) {
            }
        }, new BrokerConfig());

        store.load();
        store.start();

    }

    @AfterGroups(groups = "Init")
    public void destroy() {
        store.shutdown();
    }

    /**
     * test for putMessage
     */

    @DataProvider(name = "putMessageTestCase")
    public static Object[][] putMessageData() throws Exception {
        return ExcelUtil.getInputData("putMessage", "DefaultMessageStore");
    }

    @Test(dataProvider = "putMessageTestCase")
    public void putMessageTest(Object shutdown,
                               Object slaveMode,
                               Object valueMod50000,
                               Object isUnWriteable,
                               Object topicLength,
                               Object propertiesString,
                               Object propertiesLength,
                               Object isOSPageCacheBusy,
                               Object eclipseTime,
                               final Object result,
                               Object resultIsNotOk,
                               Object ret,
                               Object status) throws Exception {
        System.out.println(count);
        count++;
        QUEUE_TOTAL = 1;
        StoreHost = new InetSocketAddress(InetAddress.getLocalHost(), 8123);
        BornHost = new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0);
        messageStoreConfig = new MessageStoreConfig();
        messageStoreConfig.setMapedFileSizeCommitLog(1024 * 8);
        messageStoreConfig.setFlushDiskType(FlushDiskType.SYNC_FLUSH);
        store = new DefaultMessageStore(messageStoreConfig, null, new MessageArrivingListener() {
            @Override
            public void arriving(String topic, int queueId, long logicOffset, long tagsCode) {
            }
        }, new BrokerConfig());

        store.load();
        store.start();
        msg = buildMessage();

        if (shutdown != null && (boolean) shutdown) {
            store.shutdown();
        }

        if (slaveMode != null && (boolean) slaveMode) {
            messageStoreConfig.setBrokerRole(BrokerRole.SLAVE);
        }

        if (valueMod50000 != null && (boolean) valueMod50000) {
            AtomicLong mockPrintTimes = Mockito.mock(AtomicLong.class);
            mockPrintTimes.set(49999);
            Field printTime = store.getClass().getDeclaredField("printTimes");
            printTime.setAccessible(true);
            printTime.set(store, mockPrintTimes);
            printTime.setAccessible(false);
        }

        if (isUnWriteable != null && (boolean) isUnWriteable) {
            RunningFlags mockRunningFlags = Mockito.mock(RunningFlags.class);
            Mockito.when(mockRunningFlags.isWriteable()).thenReturn(false);
            Field runningFlags = store.getClass().getDeclaredField("runningFlags");
            runningFlags.setAccessible(true);
            runningFlags.set(store, mockRunningFlags);
            runningFlags.setAccessible(false);
        }

        if (topicLength != null && (boolean) topicLength) {
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < 200; i++) {
                stringBuilder.append("0");
            }
            msg.setTopic(stringBuilder.toString());
        }

        if (propertiesString != null && (boolean) propertiesString) {
            msg.setPropertiesString("PropertiesString");
        }

        if (propertiesLength != null && (boolean) propertiesLength) {
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < 40000; i++) {
                stringBuilder.append("0");
            }

            msg.setPropertiesString(stringBuilder.toString());
        }

        if (isOSPageCacheBusy != null && (boolean) isOSPageCacheBusy) {
            store = Mockito.mock(DefaultMessageStore.class);
            Mockito.when(store.isOSPageCacheBusy()).thenReturn(true);
        }

        boolean eT = false;
        if (eclipseTime != null && (boolean) eclipseTime) {
            eT = true;
        }

        boolean res = false;
        if (result != null && (boolean) result) {
            res = true;
        }

        boolean isNotOk = false;
        if (resultIsNotOk != null && (boolean) resultIsNotOk) {
            isNotOk = true;
        }


        CommitLog mockCommitLog = Mockito.mock(CommitLog.class);
        PutMessageResult innerResult = mockPutMessage(eT, res, isNotOk);
        Mockito.when(mockCommitLog.putMessage(Mockito.any(MessageExtBrokerInner.class))).thenReturn(innerResult);
        Field commitLog = store.getClass().getDeclaredField("commitLog");
        commitLog.setAccessible(true);
        commitLog.set(store, mockCommitLog);
        commitLog.setAccessible(false);


        PutMessageResult resultVal = store.putMessage(msg);
        store.shutdown();

        if ((boolean) ret) {
            assert resultVal != null;
        } else assert resultVal == null;

        if (status != null) {
            System.out.println(status.toString());
            System.out.println(resultVal.getPutMessageStatus());
            assert resultVal.getPutMessageStatus().toString().equals(status.toString());

        }
    }


    /**
     * test for getMessage
     */


    @DataProvider(name = "getMessageTestCase")
    public static Object[][] getMessageData() throws Exception {
        return ExcelUtil.getInputData("getMessage", "DefaultMessageStore");
    }


    /**
     * 废弃的方法，尝试白盒基路径未果
     *
     * @param shutdown
     * @param isUnReadable
     * @param consumeQueueNotNull
     * @param maxOffsetIsZero
     * @param lessThanMinOffset
     * @param equalToMaxOffset
     * @param greaterThanMaxOffset
     * @param minOffsetIsZero
     * @param bufferConsumeQueueNotNull
     * @param loopTime
     * @param nextPhyFileStartOffset
     * @param offsetPy
     * @param isTheBatchFull
     * @param isMessageMatched
     * @param selectResultNotNull
     * @param getBufferTotalSizeIsZero
     * @param isDebugEnabled
     * @param diskFallRecorded
     * @param getMessageStatus
     * @param ret
     * @throws Exception
     */
    @Test(dataProvider = "getMessageTestCase")
    public void getMessageTest(Object shutdown, Object isUnReadable, Object consumeQueueNotNull, Object maxOffsetIsZero,
                               Object lessThanMinOffset, Object equalToMaxOffset, Object greaterThanMaxOffset,
                               Object minOffsetIsZero, Object bufferConsumeQueueNotNull, Object loopTime,
                               Object nextPhyFileStartOffset, Object offsetPy, Object isTheBatchFull, Object isMessageMatched,
                               Object selectResultNotNull, Object getBufferTotalSizeIsZero, Object isDebugEnabled,
                               Object diskFallRecorded, Object getMessageStatus, Object ret) throws Exception {

        MessageStoreConfig messageStoreConfig = new MessageStoreConfig();
        messageStoreConfig.setMapedFileSizeCommitLog(1024 * 8);
        messageStoreConfig.setFlushDiskType(FlushDiskType.SYNC_FLUSH);
        DefaultMessageStore store = new DefaultMessageStore(messageStoreConfig, null, new MessageArrivingListener() {
            @Override
            public void arriving(String topic, int queueId, long logicOffset, long tagsCode) {
            }
        }, new BrokerConfig());

        MessageExtBrokerInner msg = buildMessage();

        store.load();
        store.start();

        if ((boolean) shutdown) {
            store.shutdown();
        }

        if (isUnReadable != null && (boolean) isUnReadable) {
            RunningFlags runningFlags = store.getAccessRights();
            runningFlags.getAndMakeNotReadable();
        }

        if (consumeQueueNotNull != null && (boolean) consumeQueueNotNull) {
            DefaultMessageStore mockStore = Mockito.mock(DefaultMessageStore.class);
            Field mockShutdown = mockStore.getClass().getDeclaredField("shutdown");
            mockShutdown.setAccessible(true);
            mockShutdown.set(mockStore, false);

            RunningFlags mockRunningFlags = Mockito.mock(RunningFlags.class);
            Mockito.when(mockRunningFlags.isReadable()).thenReturn(true);

            Field runningFlags = mockStore.getClass().getDeclaredField("runningFlags");
            runningFlags.setAccessible(true);
            runningFlags.set(mockStore, mockRunningFlags);
        }

        //后续放弃
    }


    @DataProvider(name = "getMessageEquivalence")
    public static Object[][] getMessageEquivalenceData() throws Exception {
        return ExcelUtil.getInputData("getMessageEquivalence", "DefaultMessageStore");
    }

    @Test(groups = {"Init"}, dataProvider = "getMessageEquivalence")
    public void getMessageByEquivalenceTest(Object group, Object topic, Object queueId, Object offset,
                                            Object maxMsgNums, Object subscriptionData,
                                            Object ret, Object status) throws Exception {
        store.putMessagePositionInfo("FooBar", 0, 0, 100, 1, 1000, 0);
        int totalMsgsCount = 100;
        for (int i = 0; i < totalMsgsCount; i++) {
            store.putMessage(buildMessageByNum(i));
        }

        SubscriptionData scriptionData = new SubscriptionData((String) topic, (String) subscriptionData);

        GetMessageResult result = store.getMessage((String) group, (String) topic, (int) queueId, (int) offset, (int) maxMsgNums, scriptionData);
        store.shutdown();

        if ((boolean) ret) {
            assert ret != null;
        }
        System.out.println(result.getStatus());
        assert result.getStatus().toString().equals(status.toString());
    }


    /**
     * test for getEarliestMessageTime
     */
    @DataProvider(name = "getEarliestMessageTimeTestCase")
    public static Object[][] getEarliestMessageTimeData() throws Exception {
        return ExcelUtil.getInputData("getEarliestMessageTime", className);
    }

    @Test(groups = {"Init"}, dataProvider = "getEarliestMessageTimeTestCase")
    public void getEarliestMessageTimeTest(Object topic, Object queueId, Object ret) throws Exception {
        store.putMessagePositionInfo("FooBar", 0, 0, 100, 1, 1000, 0);
        store.putMessage(buildMessage());

        long res = store.getEarliestMessageTime((String) topic, (int) queueId);
        store.shutdown();

        if (ret.toString().equals("System.currentTimeMillis()")) {
            assert res > 0;
        } else assert res == -1;
    }

    /**
     * test for findConsumeQueue
     */
    @DataProvider(name = "findConsumeQueueTestCase")
    public static Object[][] findConsumeQueueData() throws Exception {
        return ExcelUtil.getInputData("findConsumeQueue", className);
    }

    @Test(groups = {"Init"}, dataProvider = "findConsumeQueueTestCase")
    public void findConsumeQueueTest(Object topic, Object queueId, Object ret
    ) throws Exception {
        store.putMessagePositionInfo("FooBar", 0, 0, 100, 1, 1000, 0);

        ConsumeQueue res = store.findConsumeQueue((String) topic, (int) queueId);
        store.shutdown();

        //返回值判断
        assert (int) ret == res.getMaxOffsetInQueue();
    }

    /**
     * test for getMessageStoreTimeStamp
     */

    @DataProvider(name = "getMessageStoreTimeStampTestCase")
    public static Object[][] getMessageStoreTimeStampData() throws Exception {
        return ExcelUtil.getInputData("getMessageStoreTimeStamp", className);
    }

    @Test(groups = {"Init"}, dataProvider = "getMessageStoreTimeStampTestCase")
    public void getMessageStoreTimeStampTest(Object topic, Object queueId, Object offset, Object ret) throws Exception {
        store.putMessagePositionInfo("FooBar", 0, 0, 100, 1, 1000, 0);
        store.putMessage(buildMessage());
        store.putMessage(buildMessage());
        store.putMessage(buildMessageByNum(2));

        long res = store.getMessageStoreTimeStamp((String) topic, (int) queueId, (int) offset);

        //返回值判断
        if (ret.toString().equals("System.currentTimeMillis()")) {
            assert res > 0;
        } else assert res == -1;

    }

    /**
     * test for queryMessage
     *
     * @return
     */
    @DataProvider(name = "queryMessageTestCase")
    public static Object[][] queryMessageData() throws Exception {
        return ExcelUtil.getInputData("queryMessage", className);
    }

    @Test(groups = {"Init"}, dataProvider = "queryMessageTestCase")
    public void queryMessageTest(Object topic, Object key, Object maxNum, Object begin, Object end, Object retList) {
        store.putMessagePositionInfo("FooBar", 0, 0, 100, 1, 1000, 0);
        store.putMessage(buildMessage());

        QueryMessageResult result = store.queryMessage((String) topic, (String) key, (int) maxNum, (int) begin, (int) end);

        //返回值判断
        if (retList != null) {
            assert result != null;
        }
    }


    /**
     * test for isTheBatchFull
     */

    @DataProvider(name = "isTheBatchFullTestCase")
    public static Object[][] isTheBatchFullData() throws Exception {
        return ExcelUtil.getInputData("isTheBatchFull", className);
    }

    @Test(groups = {"Init"}, dataProvider = "isTheBatchFullTestCase")
    public void isTheBatchFullTest(Object messageTotal, Object isInDisk, Object maxMsgNums, Object bufferTotal, Object sizePy, Object ret) throws Exception {
        Method isTheBatchFull = store.getClass().getDeclaredMethod("isTheBatchFull", int.class, int.class, int.class, int.class, boolean.class);
        isTheBatchFull.setAccessible(true);
        Object res = isTheBatchFull.invoke(store, (int) sizePy, (int) maxMsgNums, (int) bufferTotal, (int) messageTotal, (boolean) isInDisk);
        assert (boolean) res == (boolean) ret;
    }


    /**
     * test for checkInDiskByConsumeOffset 917.
     */
    @DataProvider(name = "checkInDiskByConsumeOffsetTestCase")
    public static Object[][] checkInDiskByConsumeOffsetData() throws Exception {
        return ExcelUtil.getInputData("checkInDiskByConsumeOffset", className);
    }

    @Test(groups = {"Init"}, dataProvider = "checkInDiskByConsumeOffsetTestCase")
    public void checkInDiskByConsumeOffsetTest(Object topic, Object queueId, Object consumeOffset, Object ret) throws Exception {
        store.putMessagePositionInfo("FooBar", 0, 0, 100, 1, 1000, 0);

        store.putMessage(buildMessage());

        if (topic.toString().equals("FooBar") && (int) queueId == 0 && (int) consumeOffset == 0) {
            CommitLog mockLog = Mockito.mock(CommitLog.class);

            double maxOffset = 7e10;
            Mockito.when(mockLog.getMaxOffset()).thenReturn((long) maxOffset);
            Field commitLogField = store.getClass().getDeclaredField("commitLog");
            commitLogField.setAccessible(true);
            commitLogField.set(store, mockLog);

        }

        boolean resVal = store.checkInDiskByConsumeOffset((String) topic, (int) queueId, (int) consumeOffset);

        //返回值判断
        assert resVal == (boolean) ret;

    }

    /**
     * test for load
     */

    @DataProvider(name = "loadTestCase")
    public static Object[][] loadData() throws Exception {
        return ExcelUtil.getInputData("load", className);
    }

    @Test(dataProvider = "loadTestCase")
    public void loadTest(Object scheduleMessageService, Object result, Object hasException, Object ret) throws Exception {
        StoreHost = new InetSocketAddress(InetAddress.getLocalHost(), 8123);
        BornHost = new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0);
        MessageStoreConfig messageStoreConfig = new MessageStoreConfig();
        messageStoreConfig.setDiskFallRecorded(false);
        messageStoreConfig.setMapedFileSizeCommitLog(1024 * 8);
        messageStoreConfig.setFlushDiskType(FlushDiskType.SYNC_FLUSH);
        store = new DefaultMessageStore(messageStoreConfig, null, new MessageArrivingListener() {
            @Override
            public void arriving(String topic, int queueId, long logicOffset, long tagsCode) {
            }
        }, new BrokerConfig());

        ScheduleMessageService mockScheduleMessageService = null;
        if (scheduleMessageService.toString().equals("exist")) {
            mockScheduleMessageService = Mockito.mock(ScheduleMessageService.class);
            Mockito.when(mockScheduleMessageService.load()).thenReturn(true);
        }

        Field serviceField = store.getClass().getDeclaredField("scheduleMessageService");
        serviceField.setAccessible(true);
        serviceField.set(store, mockScheduleMessageService);

        if (!(boolean) result) {
            CommitLog mockCommitLog = Mockito.mock(CommitLog.class);
            Mockito.when(mockCommitLog.load()).thenReturn(false);
            Field commitLogField = store.getClass().getDeclaredField("commitLog");
            commitLogField.setAccessible(true);
            commitLogField.set(store, mockCommitLog);
        }

        if ((boolean) hasException) {
            messageStoreConfig.setStorePathRootDir("/non-exist/non-exist");
        }

        LogInterceptor.clear();
        boolean retVal = store.load();

        //返回值判断
        assert (boolean) ret == retVal;
        if ((boolean) hasException) {
            assert LogInterceptor.assertLog(LogLevel.ERROR, "load exception");
        }
    }


    /**
     * test for doFlush
     */

    @DataProvider(name = "doFlushTestCase")
    public static Object[][] doFlushData() throws Exception {
        return ExcelUtil.getInputData("doFlush", className);
    }

    @Test(groups = {"Init"}, dataProvider = "doFlushTestCase")
    public void doFlushTest(Object retryTime, Object lastFlushTimestamp, Object consumeQueueTableSize,
                            Object mapsSize, Object flushConsumeLeastPages, Object logicsMsgTimestamp,
                            Object path) throws Exception {

        Field flushConsumeQueueServiceField = store.getClass().getDeclaredField("flushConsumeQueueService");
        flushConsumeQueueServiceField.setAccessible(true);
        Object serviceDomain = flushConsumeQueueServiceField.get(store);
        Method doFlushMethod = serviceDomain.getClass().getDeclaredMethod("doFlush", int.class);
        doFlushMethod.setAccessible(true);

        Field lastFlushTimestampField = serviceDomain.getClass().getDeclaredField("lastFlushTimestamp");
        lastFlushTimestampField.setAccessible(true);

        if (!lastFlushTimestamp.toString().equals("0")) {
            lastFlushTimestampField.set(serviceDomain, System.currentTimeMillis());
        } else {
            lastFlushTimestampField.set(serviceDomain, 0);
        }

        ConcurrentHashMap<String, ConcurrentHashMap<Integer, ConsumeQueue>> tables = new ConcurrentHashMap<>();
        Field tableField = store.getClass().getDeclaredField("consumeQueueTable");
        tableField.setAccessible(true);
        tableField.set(store, tables);

        if ((int) consumeQueueTableSize == 1) {
            store.findConsumeQueue("FooBar", 0);
        }

        if (logicsMsgTimestamp != null) {
            store.getStoreCheckpoint().setLogicsMsgTimestamp((int) logicsMsgTimestamp);
        }
        doFlushMethod.invoke(serviceDomain, (int) retryTime);

        assert LogInterceptor.assertLog(LogLevel.WARN, (String) path);
    }

    /**
     * test for loadConsumeQueue
     */
    @DataProvider(name = "loadConsumeQueueTestCase")
    public static Object[][] loadConsumeQueueData() throws Exception {
        return ExcelUtil.getInputData("loadConsumeQueue", className);
    }

    @Test(groups = {"Init"}, dataProvider = "loadConsumeQueueTestCase")
    public void loadConsumeQueueTest(Object fileTopicList, Object fileQueueIdList, Object hasException,
                                     Object logicLoad, Object ret, Object resPath) throws Exception {
        Method loadConsumeQueueMethod = store.getClass().getDeclaredMethod("loadConsumeQueue");
        loadConsumeQueueMethod.setAccessible(true);
        String path = "target/wave_unit_test_store/default_message_store/load_consume_queue/case" + count;
        System.out.println(count);
        count++;
        store.getMessageStoreConfig().setStorePathRootDir(path);

        Object res = loadConsumeQueueMethod.invoke(store);

        assert (boolean) res == (boolean) ret;
        LogInterceptor.printLog(LogLevel.WARN);
        assert LogInterceptor.assertLog(LogLevel.WARN, (String) resPath);
        LogInterceptor.clear();

    }

    /**
     * test for isSpaceToDelete
     */
    @DataProvider(name = "isSpaceToDeleteTestCase")
    public static Object[][] isSpaceToDeleteData() throws Exception {
        return ExcelUtil.getInputData("isSpaceToDelete", className);
    }

    @Test(groups = {"Init"}, dataProvider = "isSpaceToDeleteTestCase")
    public void isSpaceToDeleteTest(Object physicRatio, Object diskok, Object diskok2, Object ratio, Object logicRatio, Object ret) throws Exception {

        store.getMessageStoreConfig().setDiskMaxUsedSpaceRatio((int) ((double) ratio * 100));
        RunningFlags mockRunningFlag = Mockito.mock(RunningFlags.class);
        if (diskok != null && diskok2 != null) {
            Mockito.when(mockRunningFlag.getAndMakeDiskFull()).thenReturn((boolean) diskok);
            Mockito.when(mockRunningFlag.getAndMakeDiskOK()).thenReturn((boolean) diskok2);
        }

        if (physicRatio != null) {
            MockUtilAll.setArgumentDouble((double) physicRatio);
        }
        if (logicRatio != null) {
            MockUtilAll.setArgumentDouble2((double) logicRatio);
        }

        Field cleanCommitLogServiceField = store.getClass().getDeclaredField("cleanCommitLogService");
        cleanCommitLogServiceField.setAccessible(true);
        Object serviceDomain = cleanCommitLogServiceField.get(store);
        Method method = serviceDomain.getClass().getDeclaredMethod("isSpaceToDelete");
        method.setAccessible(true);

        Object res = method.invoke(serviceDomain);

        //验证
        assert (boolean) res == (boolean) ret;
    }

    /**
     * test for shutdown
     */

    @DataProvider(name = "shutdownTestCase")
    public static Object[][] shutdownData() throws Exception {
        return ExcelUtil.getInputData("shutdown", className);
    }

    @Test(dataProvider = "shutdownTestCase")
    public void shutdownTest(Object shutdown, Object noException, Object scheduleMessageService, Object isWriteable, Object path) throws Exception {

        StoreHost = new InetSocketAddress(InetAddress.getLocalHost(), 8123);
        BornHost = new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0);
        MessageStoreConfig messageStoreConfig = new MessageStoreConfig();
        messageStoreConfig.setDiskFallRecorded(false);
        messageStoreConfig.setMapedFileSizeCommitLog(1024 * 8);
        messageStoreConfig.setFlushDiskType(FlushDiskType.SYNC_FLUSH);
        store = new DefaultMessageStore(messageStoreConfig, null, new MessageArrivingListener() {
            @Override
            public void arriving(String topic, int queueId, long logicOffset, long tagsCode) {
            }
        }, new BrokerConfig());

        store.load();
        store.start();

        if ((boolean) shutdown) {
            store.shutdown();
        }

        if (noException != null && !(boolean) noException) {
            //do nothing, or nothing we can do
        }

        if (scheduleMessageService != null && scheduleMessageService.toString().equals("non-exist")) {
            Field scheduleMessageServiceField = store.getClass().getDeclaredField("scheduleMessageService");
            scheduleMessageServiceField.setAccessible(true);
            scheduleMessageServiceField.set(store, null);
        }

        if (isWriteable != null && !(boolean) isWriteable) {
            store.getRunningFlags().getAndMakeNotWriteable();
        }

        LogInterceptor.clear();
        store.shutdown();

        //路径判断
        assert LogInterceptor.assertLog(LogLevel.WARN, (String) path);



    }


    /**
     * test for doDispatch
     */

    @DataProvider(name = "doDispatchTestCase")
    public static Object[][] doDispatchData() throws Exception {
        return ExcelUtil.getInputData("doDispatch", className);
    }

    @Test(groups = {"Init"}, dataProvider = "doDispatchTestCase")
    public void doDispatchTest(Object trantype, Object isMessageIndexEnable, Object path) {
        int sysFlag = 0;
        switch (trantype.toString()) {
            case "TRANSACTION_NOT_TYPE":
                sysFlag = 0;
                break;
            case "TRANSACTION_COMMIT_TYPE":
                sysFlag = 8;
                break;
            case "TRANSACTION_PREPARED_TYPE":
                sysFlag = 4;
                break;
            case "TRANSACTION_ROLLBACK_TYPE":
                sysFlag = 12;
                break;
            default:
                break;
        }


        DispatchRequest request = new DispatchRequest("FooBar", 0, 0,
                0, 0, 0, 0, "Key", "1001",
                sysFlag, 0);

        if (!(boolean) isMessageIndexEnable) {
            store.getMessageStoreConfig().setMessageIndexEnable(false);
        } else {
            store.getMessageStoreConfig().setMessageIndexEnable(true);
        }

        store.doDispatch(request);

        //路径判断
        assert LogInterceptor.assertLog(LogLevel.WARN, (String) path);
        LogInterceptor.clear();
    }

    /**
     * test for start
     */
    @DataProvider(name = "startTestCase")
    public static Object[][] startData() throws Exception {
        return ExcelUtil.getInputData("start", className);
    }

    @Test(dataProvider = "startTestCase")
    public void startTest(Object scheduleMessageService, Object brokerRole, Object isDuplicationEnable, Object path) throws Exception {
        StoreHost = new InetSocketAddress(InetAddress.getLocalHost(), 8123);
        BornHost = new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0);
        MessageStoreConfig messageStoreConfig = new MessageStoreConfig();
        messageStoreConfig.setDiskFallRecorded(false);
        messageStoreConfig.setMapedFileSizeCommitLog(1024 * 8);
        messageStoreConfig.setFlushDiskType(FlushDiskType.SYNC_FLUSH);
        store = new DefaultMessageStore(messageStoreConfig, null, new MessageArrivingListener() {
            @Override
            public void arriving(String topic, int queueId, long logicOffset, long tagsCode) {
            }
        }, new BrokerConfig());

        if (scheduleMessageService.toString().equals("non-exist")) {
            Field serviceField = store.getClass().getDeclaredField("scheduleMessageService");
            serviceField.setAccessible(true);
            serviceField.set(store, null);
        }

        if (brokerRole != null) {
            store.getMessageStoreConfig().setBrokerRole(brokerRole.toString());
        }

        if ((boolean)isDuplicationEnable){
            store.getMessageStoreConfig().setDuplicationEnable(true);
        }else {
            store.getMessageStoreConfig().setDuplicationEnable(false);
        }

        store.load();
        try {
            store.start();
            store.shutdown();
        }catch (Exception e){

        }

        assert LogInterceptor.assertLog(LogLevel.WARN, (String)path);
        LogInterceptor.clear();
    }

    /**
     * 用于尝试新想法
     */
    @Test
    public void anyTest() {
//        File dir=new File("/Users/jixunzhen/sore.txt");
//        File[] files=dir.listFiles();
//        assert files==null;
//        final double diskSpaceWarningLevelRatio =
//                Double.parseDouble(System.getProperty("rocketmq.broker.diskSpaceWarningLevelRatio", "0.90"));
//        System.out.println(diskSpaceWarningLevelRatio);

        int[] arr = {MessageSysFlag.TRANSACTION_NOT_TYPE, MessageSysFlag.TRANSACTION_COMMIT_TYPE,
                MessageSysFlag.TRANSACTION_PREPARED_TYPE, MessageSysFlag.TRANSACTION_ROLLBACK_TYPE};
        for (int i = 0; i < arr.length; i++) {
            int flagVal = 0;
            while (!(MessageSysFlag.getTransactionValue(flagVal) == arr[i])) {
                flagVal++;
            }
            System.out.println(flagVal);
        }
    }
}
