package wave.rocketmq.store.MappedFileQueue;

import org.apache.rocketmq.store.CommitLog;
import org.apache.rocketmq.store.MappedFile;
import org.apache.rocketmq.store.MappedFileQueue;
import org.mockito.Mockito;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.lang.reflect.Field;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.apache.xmlbeans.impl.store.Public2.test;
import static org.mockito.Mockito.when;

/**
 * Created by jixunzhen on 29/05/2017.
 */
public class MappedFileQueueTest {
    MappedFileQueue mappedFileQueue;
    @BeforeTest(groups = {"whiteBox"})
    public void init(){
        mappedFileQueue =
                new MappedFileQueue("target/unit_test_store/a/", 1024, null);
    }

    @Test
    public void simpleTest()throws Exception{
        CopyOnWriteArrayList<MappedFile> mappedFiles = Mockito.mock(CopyOnWriteArrayList.class);
        when(mappedFiles.isEmpty()).thenReturn(false);

        Field mappedFilesField=mappedFileQueue.getClass().getDeclaredField("mappedFiles");
        mappedFilesField.setAccessible(true);
        mappedFilesField.set(mappedFileQueue, mappedFiles);

        System.out.println(mappedFileQueue.getMappedFiles().isEmpty());
    }
}
