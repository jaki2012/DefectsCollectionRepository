package wave.rocketmq.store.util;

import org.apache.poi.ss.formula.eval.ErrorEval;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.util.LocaleUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;

/**
 * Created by jixunzhen on 27/05/2017.
 */
public class ExcelUtil {
    public static Object[][] getInputData(String excelName, String className) throws Exception{
        File inputFile=new File("input/"+className+"/"+excelName+".xlsx");
        InputStream is=new FileInputStream(inputFile);
        XSSFWorkbook workbook=new XSSFWorkbook(is);
        XSSFSheet sheet=workbook.getSheetAt(0);
        if(sheet==null){
            return null;
        }

        int rowCount=sheet.getLastRowNum();

        if(rowCount==0){
            return null;
        }

        XSSFRow firstRow=sheet.getRow(0);
        int colCount=firstRow.getLastCellNum();

        Object[][] res=new Object[rowCount-1][colCount-1];

        for(int row=2;row<=rowCount;row++){
            XSSFRow currentRow=sheet.getRow(row);

            for(int col=1;col<colCount;col++){
                XSSFCell cell=currentRow.getCell(col);
                Object val=getCellValue(cell);
                if(val.toString().isEmpty()){
                    res[row-2][col-1]=null;
                }
                else res[row-2][col-1]=val;
            }
        }

        return res;
    }

    private static Object getCellValue(Cell cell){

        double val;
        switch(cell.getCellType()) {
            case 0:
            case 2:
                if(DateUtil.isCellDateFormatted(cell)) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
                    sdf.setTimeZone(LocaleUtil.getUserTimeZone());
                    return sdf.format(cell.getDateCellValue());
                }
                val = cell.getNumericCellValue();
                if(val%1d==0d){
                    return (int)val;
                }else return val;
            case 1:
                String res = cell.getRichStringCellValue().toString();
                try {
                    val=Double.parseDouble(res);
                    if(val%1d==0d){
                        return Integer.toString((int)val);
                    }else return Double.toString(val);
                }catch (Exception e){
                    return res;
                }
            case 3:
                return "";
            case 4:
                return cell.getBooleanCellValue();
            case 5:
                return ErrorEval.getText(cell.getErrorCellValue());
            default:
                return "Unknown Cell Type: " + cell.getCellType();
        }
    }
}
