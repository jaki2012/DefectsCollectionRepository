package wave.rocketmq.store.MappedFile;

import org.apache.rocketmq.common.namesrv.NamesrvConfig;
import org.apache.rocketmq.store.MappedFile;
import org.apache.rocketmq.store.MessageExtBrokerInner;
import org.apache.rocketmq.store.SelectMappedBufferResult;
import org.apache.rocketmq.store.config.FlushDiskType;
import org.junit.Before;
import org.mockito.Mockito;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import sun.nio.ch.FileChannelImpl;
import wave.rocketmq.store.util.ExcelUtil;
import wave.rocketmq.store.util.LogInterceptor;
import wave.rocketmq.store.util.LogLevel;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.concurrent.atomic.AtomicInteger;


/**
 * Created by jixunzhen on 23/05/2017.
 */
public class MappedFileTest {
    private InspectMappedFile mappedFile=null;
    private MessageExtBrokerInner messageExtBrokerInner=new MessageExtBrokerInner();

    private static final String TEST_CASE_PATH="";
    private static final String FILE_STORE_PATH="target/wave_unit_test_store/mapped_file/";
    private static final int FILE_SIZE=1024*64;
    private static final String INPUT="Test for MappedFile";
    private static final AtomicInteger QueueId=new AtomicInteger(0);
    private int QUEUE_TOTAL = 100;
    private SocketAddress BornHost;
    private SocketAddress StoreHost;

    private static final String className="MappedFile";

    @BeforeTest
    public void init() throws Exception{
        StoreHost = new InetSocketAddress(InetAddress.getLocalHost(), 8123);
        BornHost = new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0);

    }

    private static final String ERROR_MSG="This is the mock exception when call ";

    /**
     * Test for commit
     * @return
     */

    @DataProvider(name = "commitTestCase")
    public static Object[][] commitData() throws Exception{
        return ExcelUtil.getInputData("commit","MappedFile");
    }

    @Test(dataProvider = "commitTestCase")
    public void commitTest(Object isWriteBufferExist,
                           Object isAbleToCommit,
                           Object isHold,
                           Object isTransientPoolExist,
                           Object committedPosition_get,
                           Object ret,
                           Object isAfterExist
    ) throws Exception{
        mappedFile = new InspectMappedFile(FILE_STORE_PATH+"000", 1024 * 64);
        int commitLeastPages=0;
        if(isWriteBufferExist!=null&&(boolean)isWriteBufferExist){
            mappedFile.initWriteBuffer();
        }

        if(isTransientPoolExist!=null&&(boolean)isTransientPoolExist){
            mappedFile.initTransientStorePool();
        }

        if(isAbleToCommit!=null&&(boolean)isAbleToCommit){
            mappedFile.appendMessageWriteBuffer(INPUT.getBytes());
            commitLeastPages=0;
        }

        if(isHold!=null&&!(boolean)isHold){
            mappedFile.shutdown(1000);
        }

        if(committedPosition_get!=null&&(boolean)committedPosition_get){
            for(int i=0;i<10000;i++){
                String commitString="test "+i+"\n";
                commitLeastPages=0;
                mappedFile.appendMessageWriteBuffer(commitString.getBytes());
            }
        }
        int retVal=mappedFile.commit(commitLeastPages);
        System.out.println(mappedFile.commit(commitLeastPages));


        if(ret!=null){
            assert retVal==(int)ret;
        }

        if((boolean)isAfterExist){
            assert mappedFile.isWriteBuffer();
        }
        else{
            assert !mappedFile.isWriteBuffer();
        }
    }

    /**
     * test for selectMappedBuffer
     */

    @DataProvider(name = "selectMappedBufferTestCase")
    public static Object[][] selectMappedBufferData() throws Exception{
        return ExcelUtil.getInputData("selectMappedBuffer","MappedFile");
    }

    @Test(dataProvider = "selectMappedBufferTestCase")
    public void selectMappedBufferTest(
            Object pos,
            Object isHold,
            Object ret
    ) throws Exception{
        mappedFile=new InspectMappedFile(FILE_STORE_PATH+"001",FILE_SIZE);
        boolean result=mappedFile.appendMessage(INPUT.getBytes());
        assert result;

        if(!(boolean)isHold){
            mappedFile.shutdown(1000);
        }

        SelectMappedBufferResult retVal = mappedFile.selectMappedBuffer((int)pos);

        if((boolean)ret){
            byte[] retData=new byte[INPUT.length()-(int)pos];
            retVal.getByteBuffer().get(retData);

            assert new String(retData).equals(INPUT.substring((int)pos));
            System.out.println(new String(retData));
        }else {
            assert retVal==null;
        }
    }

    /**
     *
     * Test for flush
     * @return
     */
    @DataProvider(name = "flushTestCase")
    public static Object[][] flushData()throws Exception{
//        return new Object[][]{
//                {true,true,false,true,null,0},
//                {false,null,null,null,null,0},
//                {true,false,null,null,null,INPUT.length()},
//                {true,true,true,null,null,INPUT.length()},
//                {true,true,false,false,true,INPUT.length()},
//                {true,true,false,false,false,INPUT.length()}
//        };
        return ExcelUtil.getInputData("flush","MappedFile");
    }


    @Test(dataProvider = "flushTestCase")
    public void flushTest(Object isAbleToFlush,
                          Object isHold,
                          Object hasException,
                          Object byWriteBuffer,
                          Object byFileChannel,
                          Object ret)throws Exception{

        MappedFile mappedFile=new MappedFile(FILE_STORE_PATH+"002",FILE_SIZE);
        FileChannel mockFileChannel= Mockito.mock(FileChannel.class);
        int flushLeastPages=0;
        ByteBuffer buffer=ByteBuffer.allocate(FILE_SIZE);
        if(byWriteBuffer!=null&&(boolean)byWriteBuffer){
            Field writeBuffer = mappedFile.getClass().getDeclaredField("writeBuffer");
            writeBuffer.setAccessible(true);
            writeBuffer.set(mappedFile, buffer);
            writeBuffer.setAccessible(false);
        }

        if(isAbleToFlush!=null&&(boolean)isAbleToFlush){
            mappedFile.appendMessage(INPUT.getBytes());
            flushLeastPages=0;
        }
        else {
            flushLeastPages=10;
        }

        if(isHold!=null&&!(boolean)isHold){
            mappedFile.shutdown(1000);
        }


        if(hasException!=null&&(boolean)hasException){
            Mockito.doThrow(new IOException(ERROR_MSG+mockFileChannel.getClass().getName()+".force")).when(mockFileChannel).force(false);

            Field fileChannel = mappedFile.getClass().getDeclaredField("fileChannel");
            fileChannel.setAccessible(true);
            fileChannel.set(mappedFile, mockFileChannel);
            fileChannel.setAccessible(false);
        }

        int retVal=mappedFile.flush(flushLeastPages);
        System.out.println(retVal);

        assert retVal==(int)ret;

    }

    /**
     * test for warmMappedFile
     */

    @DataProvider(name = "warmMappedFileTestCase")
    public static Object[][] warmMappedFileData()throws Exception{
        return ExcelUtil.getInputData("warmMappedFile", className);
    }

    @Test(dataProvider = "warmMappedFileTestCase")
    public void warmMappedFileTest(Object fileSize, Object type, Object pages, Object path)throws Exception{
        MappedFile file=new MappedFile(FILE_STORE_PATH+"002", (int)fileSize);
        FlushDiskType curType=FlushDiskType.SYNC_FLUSH;
        if(type.toString().equals("FlushDiskType.ASYNC_FLUSH")){
            curType=FlushDiskType.ASYNC_FLUSH;
        }

        file.warmMappedFile(curType, (int)pages);

        //路径判断
        assert LogInterceptor.assertContainLog(LogLevel.WARN, (String)path);
        LogInterceptor.clear();

    }

    /**
     * test for destroy
     */
    @DataProvider(name = "destroyTestCase")
    public static Object[][] destroyData()throws Exception{
        return ExcelUtil.getInputData("destroy", className);
    }

    @Test(dataProvider = "destroyTestCase")
    public void destroyTest(Object isCleanupOver, Object noException,
                            Object deleteResult, Object ret, Object logInfo, Object logLevel)throws Exception{
        MappedFile file=new MappedFile(FILE_STORE_PATH+"003", 1024*4);

        if(!(boolean)noException){
            FileChannel mockFileChannel=Mockito.mock(FileChannelImpl.class);
            Field fileChannelField=file.getClass().getDeclaredField("fileChannel");
            fileChannelField.setAccessible(true);
            fileChannelField.set(file, mockFileChannel);
        }

        Field fileField=file.getClass().getDeclaredField("file");
        fileField.setAccessible(true);
        File mockFile=Mockito.mock(File.class);
        Mockito.when(mockFile.delete()).thenReturn((boolean)deleteResult);
        fileField.set(file, mockFile);

        if(!(boolean)isCleanupOver) {
            file = Mockito.mock(MappedFile.class);
            Mockito.when(file.isCleanupOver()).thenReturn(false);
            Mockito.when(file.destroy(Mockito.anyLong())).thenCallRealMethod();
        }

        boolean result=file.destroy(1000);

        //结果判断
        assert result==(boolean)ret;
        assert LogInterceptor.assertContainLog(LogLevel.valueOf(logLevel.toString()), (String)logInfo);
    }

    @Test
    public void anyTest()throws Exception{
        MappedFile file=new MappedFile(FILE_STORE_PATH+"003", 1024*4);
        file.shutdown(10000);
        System.out.println(file.isCleanupOver());

    }

}
