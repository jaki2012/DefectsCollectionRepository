package org.apache.rocketmq.store.util;

/**
 * Created by jixunzhen on 31/05/2017.
 */
public class MockUtilAll {
    static private double argumentDouble;
    static private double argumentDouble2;
    public static void setArgumentDouble(double val){
        argumentDouble=val;
    }
    public static void setArgumentDouble2(double val){
        argumentDouble2=val;
    }

    static public double getDiskPartitionSpaceUsedPercent(String useful) {
        if(useful.contains("commitlog")){
            return argumentDouble2;
        }
        return argumentDouble;
    }
}
