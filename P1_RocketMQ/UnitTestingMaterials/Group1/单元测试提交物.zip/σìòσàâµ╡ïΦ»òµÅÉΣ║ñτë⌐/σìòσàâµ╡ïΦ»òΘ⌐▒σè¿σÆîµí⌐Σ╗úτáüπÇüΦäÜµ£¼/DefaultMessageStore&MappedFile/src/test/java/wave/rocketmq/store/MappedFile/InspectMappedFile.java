package wave.rocketmq.store.MappedFile;

import org.apache.rocketmq.store.MappedFile;
import org.apache.rocketmq.store.TransientStorePool;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.io.IOError;
import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * Created by jixunzhen on 23/05/2017.
 */
public class InspectMappedFile extends MappedFile {
    InspectMappedFile(final String filename, final int fileSize) throws IOException{
        super(filename,fileSize);
    }

    InspectMappedFile(final String filename, final int fileSize, final TransientStorePool transientStorePool) throws IOException{
        super(filename,fileSize, transientStorePool);
    }
    public boolean appendMessageWriteBuffer(byte[] data){
        int currentPos=this.wrotePosition.get();
        ByteBuffer byteBuffer=writeBuffer.slice();
        byteBuffer.position(currentPos);
        if(currentPos<this.fileSize){
            int current_len=min(fileSize-currentPos, data.length);
            byteBuffer.put(data, 0, current_len);
            wrotePosition.addAndGet(current_len);
        }
        return true;
    }

    public boolean isWriteBuffer(){
        return writeBuffer!=null;
    }

    private int min(int a, int b){
        return a<b?a:b;
    }

    public boolean initTransientStorePool(){
        this.transientStorePool=Mockito.mock(TransientStorePool.class);
        return true;
    }

    public boolean initWriteBuffer(){
        if(writeBuffer==null){
            writeBuffer=ByteBuffer.allocate(fileSize);
            return true;
        }
        return false;
    }
}
