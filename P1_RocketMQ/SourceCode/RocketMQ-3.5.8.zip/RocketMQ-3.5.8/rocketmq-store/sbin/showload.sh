#!/bin/sh
while [ "1" == "1" ]
do
	uptime
	sleep 1
done