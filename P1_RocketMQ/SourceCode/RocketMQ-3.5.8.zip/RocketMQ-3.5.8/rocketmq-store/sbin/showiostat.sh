#!/bin/sh
iostat sdb1 -x 1 -t