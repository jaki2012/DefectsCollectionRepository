/*
 * Copyright (C) 2007 The Guava Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.common.io;

import static com.google.common.io.Files.touch;
import static com.google.common.truth.Truth.assertThat;

import com.google.common.base.Charsets;
import com.google.common.collect.ImmutableList;
import com.google.common.hash.Hashing;
import com.google.common.primitives.Bytes;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel.MapMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import junit.framework.TestSuite;

/**
 * Unit test for {@link Files}.
 *
 * @author Chris Nokleberg
 */

public class FilesTest extends IoTestCase {

  public void testEqual() throws IOException {
    File asciiFile = getTestFile("ttt.txt");
    File i18nFile = getTestFile("i18n.txt");
    assertFalse(Files.equal(asciiFile, i18nFile));
    assertTrue(Files.equal(asciiFile, asciiFile));

    File temp = createTempFile();
    Files.copy(asciiFile, temp);
    assertTrue(Files.equal(asciiFile, temp));

    Files.copy(i18nFile, temp);
    assertTrue(Files.equal(i18nFile, temp));

    Files.copy(asciiFile, temp);
    RandomAccessFile rf = new RandomAccessFile(temp, "rw");
    rf.writeByte(0);
    rf.close();
    assertEquals(asciiFile.length(), temp.length());
    assertFalse(Files.equal(asciiFile, temp));

    assertTrue(Files.asByteSource(asciiFile)
        .contentEquals(Files.asByteSource(asciiFile)));

    // 0-length files have special treatment (/proc, etc.)
    assertTrue(Files.equal(asciiFile, new BadLengthFile(asciiFile, 0)));
  }

  public void testMove() throws IOException {
    File i18nFile = getTestFile("i18n.txt");
    File temp1 = createTempFile();
    File temp2 = createTempFile();

    Files.copy(i18nFile, temp1);
    moveHelper(true, temp1, temp2);
    assertTrue(Files.equal(temp2, i18nFile));
  }

  //测试复制文件的移动
  public void testMoveViaCopy() throws IOException {
    File i18nFile = getTestFile("i18n.txt");
    File temp1 = createTempFile();
    File temp2 = createTempFile();

    Files.copy(i18nFile, temp1);
    moveHelper(true, new UnmovableFile(temp1, false, true), temp2);
    assertTrue(Files.equal(temp2, i18nFile));
  }

  //移动失败的情况
  public void testMoveFailures() throws IOException {
    File temp1 = createTempFile();
    File temp2 = createTempFile();

    moveHelper(false, new UnmovableFile(temp1, false, false), temp2);
    moveHelper(false, new UnmovableFile(temp1, false, false),
        new UnmovableFile(temp2, true, false));

    try {
      File asciiFile = getTestFile("ascii.txt");
      moveHelper(false, asciiFile, asciiFile);
      fail("expected exception");
    } catch (IllegalArgumentException expected) {
    }
  }

  private void moveHelper(boolean success, File from, File to)
      throws IOException {
    try {
      Files.move(from, to);
      if (success) {
        assertFalse(from.exists());
        assertTrue(to.exists());
      } else {
        fail("expected exception");
      }
    } catch (IOException possiblyExpected) {
      if (success) {
        throw possiblyExpected;
      }
    }
  }

  //桩，用来创建不可移动的文件
  private static class UnmovableFile extends File {

    private final boolean canRename;
    private final boolean canDelete;

    public UnmovableFile(File file, boolean canRename, boolean canDelete) {
      super(file.getPath());
      this.canRename = canRename;
      this.canDelete = canDelete;
    }

    @Override
    public boolean renameTo(File to) {
      return canRename && super.renameTo(to);
    }

    @Override
    public boolean delete() {
      return canDelete && super.delete();
    }

    private static final long serialVersionUID = 0;
  }

}
