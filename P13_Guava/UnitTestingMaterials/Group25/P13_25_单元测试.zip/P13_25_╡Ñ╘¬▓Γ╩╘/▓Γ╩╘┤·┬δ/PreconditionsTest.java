package com.google.common.base;

import static com.google.common.base.Preconditions.checkState;
import static com.google.common.truth.Truth.assertThat;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.common.testing.ArbitraryInstances;
import com.google.common.testing.NullPointerTester;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import junit.framework.AssertionFailedError;
import junit.framework.TestCase;

@GwtCompatible(emulated = true)
public class PreconditionsTest extends TestCase {
 
  public void testCheckPositionIndex_ok() {
    assertEquals(0, Preconditions.checkPositionIndex(0, 0));
    assertEquals(0, Preconditions.checkPositionIndex(0, 1));
    assertEquals(1, Preconditions.checkPositionIndex(1, 1));
  }

  public void testCheckPositionIndex_badSize() {
    try {
      Preconditions.checkPositionIndex(1, -1);
      fail();
    } catch (IllegalArgumentException expected) {
      // don't care what the message text is, as this is an invalid usage of
      // the Preconditions class, unlike all the other exceptions it throws
    }
  }

  public void testCheckPositionIndex_negative() {
    try {
      Preconditions.checkPositionIndex(-1, 1);
      fail();
    } catch (IndexOutOfBoundsException expected) {
      assertThat(expected).hasMessage("index (-1) must not be negative");
    }
  }

  public void testCheckPositionIndex_tooHigh() {
    try {
      Preconditions.checkPositionIndex(2, 1);
      fail();
    } catch (IndexOutOfBoundsException expected) {
      assertThat(expected).hasMessage("index (2) must not be greater than size (1)");
    }
  }

  public void testCheckPositionIndex_withDesc_negative() {
    try {
      Preconditions.checkPositionIndex(-1, 1, "foo");
      fail();
    } catch (IndexOutOfBoundsException expected) {
      assertThat(expected).hasMessage("foo (-1) must not be negative");
    }
  }

  public void testCheckPositionIndex_withDesc_tooHigh() {
    try {
      Preconditions.checkPositionIndex(2, 1, "foo");
      fail();
    } catch (IndexOutOfBoundsException expected) {
      assertThat(expected).hasMessage("foo (2) must not be greater than size (1)");
    }
  }

  public void testCheckPositionIndexes_ok() {
    Preconditions.checkPositionIndexes(0, 0, 0);
    Preconditions.checkPositionIndexes(0, 0, 1);
    Preconditions.checkPositionIndexes(0, 1, 1);
    Preconditions.checkPositionIndexes(1, 1, 1);
  }

  public void testCheckPositionIndexes_badSize() {
    try {
      Preconditions.checkPositionIndexes(1, 1, -1);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testCheckPositionIndex_startNegative() {
    try {
      Preconditions.checkPositionIndexes(-1, 1, 1);
      fail();
    } catch (IndexOutOfBoundsException expected) {
      assertThat(expected).hasMessage("start index (-1) must not be negative");
    }
  }

  public void testCheckPositionIndexes_endTooHigh() {
    try {
      Preconditions.checkPositionIndexes(0, 2, 1);
      fail();
    } catch (IndexOutOfBoundsException expected) {
      assertThat(expected).hasMessage("end index (2) must not be greater than size (1)");
    }
  }

  public void testCheckPositionIndexes_reversed() {
    try {
      Preconditions.checkPositionIndexes(1, 0, 1);
      fail();
    } catch (IndexOutOfBoundsException expected) {
      assertThat(expected).hasMessage("end index (0) must not be less than start index (1)");
    }
  }

  public void testFormat() {
    assertEquals("%s", Preconditions.format("%s"));
    //assertEquals("%s", Preconditions.format("aaa","2"));
    assertEquals("aa", Preconditions.format("aa"));
    assertEquals("5", Preconditions.format("%s", 5,2));
    assertEquals("foo [5]", Preconditions.format("foo", 5));
    assertEquals("foo [5, 6, 7]", Preconditions.format("foo", 5, 6, 7));
    assertEquals("%s 1 2", Preconditions.format("%s %s %s", "%s", 1, 2));
    assertEquals(" [5, 6]", Preconditions.format("", 5, 6));
    assertEquals("123", Preconditions.format("%s%s%s", 1, 2, 3));
    assertEquals("1%s%s", Preconditions.format("%s%s%s", 1));
    assertEquals("5 + 6 = 11", Preconditions.format("%s + 6 = 11", 5));
    assertEquals("5 + 6 = 11", Preconditions.format("5 + %s = 11", 6));
    assertEquals("5 + 6 = 11", Preconditions.format("5 + 6 = %s", 11));
    assertEquals("5 + 6 = 11", Preconditions.format("%s + %s = %s", 5, 6, 11));
    assertEquals("null [null, null]",
        Preconditions.format("%s", null, null, null));
    assertEquals("null [5, 6]", Preconditions.format(null, 5, 6));
  }

}
