package com.google.common.net;

import static com.google.common.base.Charsets.UTF_16;
import static com.google.common.base.Charsets.UTF_8;
import static com.google.common.net.MediaType.ANY_APPLICATION_TYPE;
import static com.google.common.net.MediaType.ANY_AUDIO_TYPE;
import static com.google.common.net.MediaType.ANY_IMAGE_TYPE;
import static com.google.common.net.MediaType.ANY_TEXT_TYPE;
import static com.google.common.net.MediaType.ANY_TYPE;
import static com.google.common.net.MediaType.ANY_VIDEO_TYPE;
import static com.google.common.net.MediaType.HTML_UTF_8;
import static com.google.common.net.MediaType.JPEG;
import static com.google.common.net.MediaType.PLAIN_TEXT_UTF_8;
import static com.google.common.truth.Truth.assertThat;
import static java.lang.reflect.Modifier.isFinal;
import static java.lang.reflect.Modifier.isPublic;
import static java.lang.reflect.Modifier.isStatic;
import static java.util.Arrays.asList;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Function;
import com.google.common.base.Optional;
import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableListMultimap;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.testing.EqualsTester;
import com.google.common.testing.NullPointerTester;
import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.nio.charset.IllegalCharsetNameException;
import java.nio.charset.UnsupportedCharsetException;
import junit.framework.TestCase;


@GwtCompatible(emulated = true)
public class MediaTypeTest extends TestCase {


    public void testHasWildcard() {
        assertFalse(PLAIN_TEXT_UTF_8.hasWildcard());
        assertFalse(JPEG.hasWildcard());
        assertTrue(ANY_TYPE.hasWildcard());
        assertTrue(ANY_APPLICATION_TYPE.hasWildcard());
        assertTrue(ANY_AUDIO_TYPE.hasWildcard());
        assertTrue(ANY_IMAGE_TYPE.hasWildcard());
        assertTrue(ANY_TEXT_TYPE.hasWildcard());
        assertTrue(ANY_VIDEO_TYPE.hasWildcard());
    }

    public void testIs() {
        assertTrue(PLAIN_TEXT_UTF_8.is(ANY_TYPE));
        assertTrue(JPEG.is(ANY_TYPE));
        assertTrue(ANY_TEXT_TYPE.is(ANY_TYPE));
        assertTrue(PLAIN_TEXT_UTF_8.is(ANY_TEXT_TYPE));
        assertTrue(PLAIN_TEXT_UTF_8.withoutParameters().is(ANY_TEXT_TYPE));
        assertFalse(JPEG.is(ANY_TEXT_TYPE));
        assertTrue(PLAIN_TEXT_UTF_8.is(PLAIN_TEXT_UTF_8));
        assertTrue(PLAIN_TEXT_UTF_8.is(PLAIN_TEXT_UTF_8.withoutParameters()));
        assertFalse(PLAIN_TEXT_UTF_8.withoutParameters().is(PLAIN_TEXT_UTF_8));
        assertFalse(PLAIN_TEXT_UTF_8.is(HTML_UTF_8));
        assertFalse(PLAIN_TEXT_UTF_8.withParameter("charset", "UTF-16").is(PLAIN_TEXT_UTF_8));
        assertFalse(PLAIN_TEXT_UTF_8.is(PLAIN_TEXT_UTF_8.withParameter("charset", "UTF-16")));
    }


}
