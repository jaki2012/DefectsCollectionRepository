package com.google.common.io;

import com.google.common.collect.Lists;
import java.io.ByteArrayInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;

public class MultiInputStreamTest extends IoTestCase {

  @SuppressWarnings("CheckReturnValue") // these calls to skip always return 0
  public void testSkip() throws Exception {
    MultiInputStream multi = new MultiInputStream(
        Collections.singleton(new ByteSource() {
          @Override
          public InputStream openStream() {
            return new ByteArrayInputStream(newPreFilledByteArray(0, 50)) {
              @Override public long skip(long n) {
                return 0;
              }
            };
          }
        }).iterator());
    assertEquals(0, multi.skip(-1));
    assertEquals(0, multi.skip(-1));
    assertEquals(0, multi.skip(20));
    ByteStreams.skipFully(multi, 20);
    assertEquals(20, multi.read());
  }

}
