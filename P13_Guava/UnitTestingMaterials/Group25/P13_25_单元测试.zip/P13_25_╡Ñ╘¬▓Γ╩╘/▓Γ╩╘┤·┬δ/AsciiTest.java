package com.google.common.base;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import junit.framework.TestCase;

@GwtCompatible
public class AsciiTest extends TestCase {

  /**
   * The Unicode points {@code 00c1} and {@code 00e1} are the upper- and
   * lowercase forms of A-with-acute-accent, {@code Á} and {@code á}.
   */
  private static final String IGNORED =
      "`10-=~!@#$%^&*()_+[]\\{}|;':\",./<>?'\u00c1\u00e1\n";
  private static final String LOWER = "abcdefghijklmnopqrstuvwxyz";
  private static final String UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

  //测试字符串转小写
  public void testToLowerCase() {
    assertEquals(LOWER, Ascii.toLowerCase(UPPER));
    assertSame(LOWER, Ascii.toLowerCase(LOWER));
    assertEquals(IGNORED, Ascii.toLowerCase(IGNORED));
    assertEquals("foobar", Ascii.toLowerCase("fOobaR"));
  }

  //测试字符串转大写
  public void testToUpperCase() {
    assertEquals("", Ascii.toUpperCase(""));
    assertEquals(UPPER, Ascii.toUpperCase(LOWER));
    assertSame(UPPER, Ascii.toUpperCase(UPPER));
    assertEquals(IGNORED, Ascii.toUpperCase(IGNORED));
    assertEquals("FOOBAR", Ascii.toUpperCase("FoOBAr"));
  }

  //测试特殊字符集
  public void testCharsIgnored() {
    for (char c : IGNORED.toCharArray()) {
      String str = String.valueOf(c);
      assertTrue(str, c == Ascii.toLowerCase(c));
      assertTrue(str, c == Ascii.toUpperCase(c));
      assertFalse(str, Ascii.isLowerCase(c));
      assertFalse(str, Ascii.isUpperCase(c));
    }
  }

  //测试字母转小写
  public void testCharsLower() {
    for (char c : LOWER.toCharArray()) {
      String str = String.valueOf(c);
      assertTrue(str, c == Ascii.toLowerCase(c));
      assertFalse(str, c == Ascii.toUpperCase(c));
      assertTrue(str, Ascii.isLowerCase(c));
      assertFalse(str, Ascii.isUpperCase(c));
    }
  }

  //测试字母转大写
  public void testCharsUpper() {
    for (char c : UPPER.toCharArray()) {
      String str = String.valueOf(c);
      assertFalse(str, c == Ascii.toLowerCase(c));
      assertTrue(str, c == Ascii.toUpperCase(c));
      assertFalse(str, Ascii.isLowerCase(c));
      assertTrue(str, Ascii.isUpperCase(c));
    }
  }

 //测试比较字符串是否相等（忽略大小写）
  public void testEqualsIgnoreCase() {
    assertTrue(Ascii.equalsIgnoreCase("", ""));
    assertFalse(Ascii.equalsIgnoreCase("", "x"));
    assertFalse(Ascii.equalsIgnoreCase("x", ""));
    assertTrue(Ascii.equalsIgnoreCase(LOWER, UPPER));
    assertTrue(Ascii.equalsIgnoreCase(UPPER, LOWER));
    // Create new strings here to avoid early-out logic.
    assertTrue(Ascii.equalsIgnoreCase(new String(IGNORED), new String(IGNORED)));
    // Compare to: "\u00c1".equalsIgnoreCase("\u00e1") == true
    assertFalse(Ascii.equalsIgnoreCase("\u00c1", "\u00e1"));
    // Test chars just outside the alphabetic range ('A'-1 vs 'a'-1, 'Z'+1 vs 'z'+1)
    assertFalse(Ascii.equalsIgnoreCase("@", "`"));
    assertFalse(Ascii.equalsIgnoreCase("[", "{"));
  }

   //测试混合字符串（字母与ascii码混合）
  @GwtIncompatible // String.toUpperCase() has browser semantics
  public void testEqualsIgnoreCaseUnicodeEquivalence() {
    // The Unicode point {@code 00df} is the lowercase form of sharp-S (ß), whose uppercase is "SS".
    assertEquals("PASSWORD", "pa\u00dfword".toUpperCase()); // [*]
    assertFalse("pa\u00dfword".equalsIgnoreCase("PASSWORD"));  // [*]
    assertFalse(Ascii.equalsIgnoreCase("pa\u00dfword", "PASSWORD"));
  }
}
