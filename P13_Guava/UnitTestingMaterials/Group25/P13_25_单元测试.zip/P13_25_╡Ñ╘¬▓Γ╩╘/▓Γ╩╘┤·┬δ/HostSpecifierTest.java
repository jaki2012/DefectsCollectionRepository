package com.google.common.net;


public final class HostSpecifierTest extends TestCase {

    private static final ImmutableList<String> GOOD_IPS =
            ImmutableList.of("1.2.3.4", "2001:db8::1", "[2001:db8::1]");

    private static final ImmutableList<String> BAD_IPS =
            ImmutableList.of("1.2.3", "2001:db8::1::::::0", "[2001:db8::1", "[::]:80");

    public void testGoodIpAddresses() throws ParseException {
        for (String spec : GOOD_IPS) {
            assertGood(spec);
        }
    }

    public void testBadIpAddresses() {
        for (String spec : BAD_IPS) {
            assertBad(spec);
        }
    }

    private void assertGood(String spec) throws ParseException {
        HostSpecifier.fromValid(spec);  // Throws exception if not working correctly
        HostSpecifier.from(spec);
        assertTrue(HostSpecifier.isValid(spec));
    }
    private void assertBad(String spec) {
        try {
            HostSpecifier.fromValid(spec);
            fail("Should have thrown IllegalArgumentException: " + spec);
        } catch (IllegalArgumentException expected) {

        }

        assertFalse(HostSpecifier.isValid(spec));
    }
}
