package com.google.common.net;

import com.google.common.annotations.GwtCompatible;
import com.google.common.testing.EqualsTester;
import com.google.common.testing.SerializableTester;
import junit.framework.TestCase;


@GwtCompatible
public class HostAndPortTest extends TestCase {

    // 正确形式的输入
    public void testFromStringWellFormed() {
        checkFromStringCase("google.com",           80, "google.com", 80, false);
        checkFromStringCase("google.com",           80, "google.com", 80, false);
        checkFromStringCase("192.0.2.1",            82, "192.0.2.1",  82, false);
        checkFromStringCase("[2001::1]",            84, "2001::1",    84, false);
        checkFromStringCase("2001::3",              86, "2001::3",    86, false);
        checkFromStringCase("host:",                80, "host",       80, false);
    }

    //正确的输入带有不正确的端口号
    public void testFromStringBadDefaultPort() {
        checkFromStringCase("gmail.com:81",         -1, "gmail.com",  81, true);
        checkFromStringCase("192.0.2.2:83",         -1, "192.0.2.2",  83, true);
        checkFromStringCase("[2001::2]:85",         -1, "2001::2",    85, true);
        checkFromStringCase("goo.gl:65535",      65536, "goo.gl",  65535, true);
        checkFromStringCase("google.com",           -1, "google.com", -1, false);
        checkFromStringCase("192.0.2.1",         65536, "192.0.2.1",  -1, false);
        checkFromStringCase("[2001::1]",            -1, "2001::1",    -1, false);
        checkFromStringCase("2001::3",           65536, "2001::3",    -1, false);
    }

    // 正确的无用的端口号
    public void testFromStringUnusedDefaultPort() {

        checkFromStringCase("gmail.com:81",         77, "gmail.com",  81, true);
        checkFromStringCase("192.0.2.2:83",         77, "192.0.2.2",  83, true);
        checkFromStringCase("[2001::2]:85",         77, "2001::2",    85, true);
    }

    //超出范围以及不合法的端口号
    public void testFromStringBadPort() {
        checkFromStringCase("google.com:65536",      1, null,         99, false);
        checkFromStringCase("google.com:9999999999", 1, null,         99, false);
        checkFromStringCase("google.com:port",       1, null,         99, false);
        checkFromStringCase("google.com:-25",        1, null,         99, false);
        checkFromStringCase("google.com:+25",        1, null,         99, false);
        checkFromStringCase("google.com:25  ",       1, null,         99, false);
        checkFromStringCase("google.com:25\t",       1, null,         99, false);
        checkFromStringCase("google.com:0x25 ",      1, null,         99, false);
    }

    // 错误的输入
    public void testFromStringUnparseableNonsense() {
        checkFromStringCase("[goo.gl]",              1, null,         99, false);
        checkFromStringCase("[goo.gl]:80",           1, null,         99, false);
        checkFromStringCase("[",                     1, null,         99, false);
        checkFromStringCase("[]:",                   1, null,         99, false);
        checkFromStringCase("[]:80",                 1, null,         99, false);
        checkFromStringCase("[]bad",                 1, null,         99, false);
    }

    //错误但是代码可以解析的输入
    public void testFromStringParseableNonsense() {
        checkFromStringCase("[[:]]",                86, "[:]",        86, false);
        checkFromStringCase("x:y:z",                87, "x:y:z",      87, false);
        checkFromStringCase("",                     88, "",           88, false);
        checkFromStringCase(":",                    99, "",           99, false);
        checkFromStringCase(":123",                 -1, "",          123, true);
        checkFromStringCase("\nOMG\t",              89, "\nOMG\t",    89, false);
    }

    private static void checkFromStringCase(
            String hpString,
            int defaultPort,
            String expectHost,
            int expectPort,
            boolean expectHasExplicitPort) {
        HostAndPort hp;
        try {
            hp = HostAndPort.fromString(hpString);
        } catch (IllegalArgumentException e) {
            assertNull(expectHost);
            return;
        }
        assertNotNull(expectHost);

        final boolean badDefaultPort = (defaultPort < 0 || defaultPort > 65535);
        HostAndPort hp2 = null;
        try {
            hp2 = hp.withDefaultPort(defaultPort);
            assertFalse(badDefaultPort);
        } catch (IllegalArgumentException e) {
            assertTrue(badDefaultPort);
        }


        if (expectHasExplicitPort) {
            assertTrue(hp.hasPort());
            assertEquals(expectPort, hp.getPort());
        } else {
            assertFalse(hp.hasPort());
            try {
                hp.getPort();
            } catch (IllegalStateException expected) {
            }
        }
        assertEquals(expectHost, hp.getHost());
        assertEquals(expectHost, hp.getHostText());


        if (!badDefaultPort) {
            try {
                int port = hp2.getPort();
                assertTrue(expectPort != -1);
                assertEquals(expectPort, port);
            } catch (IllegalStateException e) {
                assertEquals(-1, expectPort);
            }
            assertEquals(expectHost, hp2.getHost());
            assertEquals(expectHost, hp2.getHostText());
        }
    }

    public void testToString() {
        // 带有端口.
        assertEquals("foo:101", "" + HostAndPort.fromString("foo:101"));
        assertEquals(":102", HostAndPort.fromString(":102").toString());
        assertEquals("[1::2]:103", HostAndPort.fromParts("1::2", 103).toString());
        assertEquals("[::1]:104", HostAndPort.fromString("[::1]:104").toString());

        // 不带端口
        assertEquals("foo", "" + HostAndPort.fromString("foo"));
        assertEquals("", HostAndPort.fromString("").toString());
        assertEquals("[1::2]", HostAndPort.fromString("1::2").toString());
        assertEquals("[::1]", HostAndPort.fromString("[::1]").toString());

        // 无意义的输入
        assertEquals("[::]]:107", HostAndPort.fromParts("::]", 107).toString());
        assertEquals("[[:]]:108", HostAndPort.fromString("[[:]]:108").toString());
    }


}
