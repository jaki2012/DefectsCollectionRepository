package com.google.common.net;

import static com.google.common.truth.Truth.assertThat;

import com.google.common.testing.NullPointerTester;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import junit.framework.TestCase;

public class InetAddressesTest extends TestCase {

    public void testForUriStringIPv4() {
        Inet4Address expected = (Inet4Address) InetAddresses.forString("192.168.1.1");
        assertEquals(expected, InetAddresses.forUriString("192.168.1.1"));
    }

    public void testForUriStringIPv6() {
        Inet6Address expected = (Inet6Address) InetAddresses.forString("3ffe:0:0:0:0:0:0:1");
        assertEquals(expected, InetAddresses.forUriString("[3ffe:0:0:0:0:0:0:1]"));
    }

    public void testForUriStringIPv4Mapped() {
        Inet4Address expected = (Inet4Address) InetAddresses.forString("192.0.2.1");
        assertEquals(expected, InetAddresses.forUriString("[::ffff:192.0.2.1]"));
    }

    public void testIsUriInetAddress() {
        assertTrue(InetAddresses.isUriInetAddress("192.168.1.1"));
        assertTrue(InetAddresses.isUriInetAddress("[3ffe:0:0:0:0:0:0:1]"));
        assertTrue(InetAddresses.isUriInetAddress("[::ffff:192.0.2.1]"));

        assertFalse(InetAddresses.isUriInetAddress("[192.168.1.1"));
        assertFalse(InetAddresses.isUriInetAddress("192.168.1.1]"));
        assertFalse(InetAddresses.isUriInetAddress(""));
        assertFalse(InetAddresses.isUriInetAddress("192.168.999.888"));
        assertFalse(InetAddresses.isUriInetAddress("www.google.com"));
        assertFalse(InetAddresses.isUriInetAddress("1:2e"));
        assertFalse(InetAddresses.isUriInetAddress("[3ffe:0:0:0:0:0:0:1"));
        assertFalse(InetAddresses.isUriInetAddress("3ffe:0:0:0:0:0:0:1]"));
        assertFalse(InetAddresses.isUriInetAddress("3ffe:0:0:0:0:0:0:1"));
        assertFalse(InetAddresses.isUriInetAddress("::ffff:192.0.2.1"));
    }

    public void testForUriStringBad() {
        try {
            InetAddresses.forUriString("");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {

        }

        try {
            InetAddresses.forUriString("192.168.999.888");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {

        }

        try {
            InetAddresses.forUriString("www.google.com");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {

        }

        try {
            InetAddresses.forUriString("[1:2e]");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {

        }

        try {
            InetAddresses.forUriString("[192.168.1.1]");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {

        }

        try {
            InetAddresses.forUriString("192.168.1.1]");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {

        }

        try {
            InetAddresses.forUriString("[192.168.1.1");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {

        }

        try {
            InetAddresses.forUriString("[3ffe:0:0:0:0:0:0:1");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {

        }

        try {
            InetAddresses.forUriString("3ffe:0:0:0:0:0:0:1]");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {

        }

        try {
            InetAddresses.forUriString("3ffe:0:0:0:0:0:0:1");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {

        }

        try {
            InetAddresses.forUriString("::ffff:192.0.2.1");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {

        }
    }

    public void testCompatIPv4Addresses() {
        String[] nonCompatAddresses = {
                "3ffe::1",
                "::",
                "::1",
        };

        for (int i = 0; i < nonCompatAddresses.length; i++) {
            InetAddress ip = InetAddresses.forString(nonCompatAddresses[i]);
            assertFalse(InetAddresses.isCompatIPv4Address((Inet6Address) ip));
            try {
                InetAddresses.getCompatIPv4Address((Inet6Address) ip);
                fail("IllegalArgumentException expected for '" +
                        nonCompatAddresses[i] + "'");
            } catch (IllegalArgumentException expected) {

            }
        }

        String[] validCompatAddresses = {
                "::1.2.3.4",
                "::102:304",
        };
        String compatStr = "1.2.3.4";
        InetAddress compat = InetAddresses.forString(compatStr);

        for (int i = 0; i < validCompatAddresses.length; i++) {
            InetAddress ip = InetAddresses.forString(validCompatAddresses[i]);
            assertTrue("checking '" + validCompatAddresses[i] + "'", ip instanceof Inet6Address);
            assertTrue("checking '" + validCompatAddresses[i] + "'",
                    InetAddresses.isCompatIPv4Address((Inet6Address) ip));
            assertEquals("checking '" + validCompatAddresses[i] + "'", compat,
                    InetAddresses.getCompatIPv4Address((Inet6Address) ip));
        }
    }

    public void testMappedIPv4Addresses() throws UnknownHostException {

        String mappedStr = "::ffff:192.168.0.1";
        assertTrue(InetAddresses.isMappedIPv4Address(mappedStr));
        InetAddress mapped = InetAddresses.forString(mappedStr);
        assertThat(mapped).isNotInstanceOf(Inet6Address.class);
        assertEquals(InetAddress.getByName("192.168.0.1"), mapped);

        mappedStr = "::FFFF:192.168.0.1";
        assertTrue(InetAddresses.isMappedIPv4Address(mappedStr));
        mapped = InetAddresses.forString(mappedStr);
        assertThat(mapped).isNotInstanceOf(Inet6Address.class);
        assertEquals(InetAddress.getByName("192.168.0.1"), mapped);

        mappedStr = "0:00:000:0000:0:ffff:1.2.3.4";
        assertTrue(InetAddresses.isMappedIPv4Address(mappedStr));
        mapped = InetAddresses.forString(mappedStr);
        assertThat(mapped).isNotInstanceOf(Inet6Address.class);
        assertEquals(InetAddress.getByName("1.2.3.4"), mapped);

        mappedStr = "::ffff:0102:0304";
        assertTrue(InetAddresses.isMappedIPv4Address(mappedStr));
        mapped = InetAddresses.forString(mappedStr);
        assertThat(mapped).isNotInstanceOf(Inet6Address.class);
        assertEquals(InetAddress.getByName("1.2.3.4"), mapped);

        assertFalse(InetAddresses.isMappedIPv4Address("::"));
        assertFalse(InetAddresses.isMappedIPv4Address("::ffff"));
        assertFalse(InetAddresses.isMappedIPv4Address("::ffff:0"));
        assertFalse(InetAddresses.isMappedIPv4Address("::fffe:0:0"));
        assertFalse(InetAddresses.isMappedIPv4Address("::1:ffff:0:0"));
        assertFalse(InetAddresses.isMappedIPv4Address("foo"));
        assertFalse(InetAddresses.isMappedIPv4Address("192.0.2.1"));
    }


    public void testGetEmbeddedIPv4ClientAddress() {
        Inet6Address testIp;


        testIp = (Inet6Address) InetAddresses.forString("2001:db8::1");
        assertFalse(InetAddresses.hasEmbeddedIPv4ClientAddress(testIp));


        testIp = (Inet6Address) InetAddresses.forString("2001:db8::5efe:102:304");
        assertFalse(InetAddresses.hasEmbeddedIPv4ClientAddress(testIp));


        testIp = (Inet6Address) InetAddresses.forString("::1.2.3.4");
        assertTrue(InetAddresses.hasEmbeddedIPv4ClientAddress(testIp));
        InetAddress ipv4 = InetAddresses.forString("1.2.3.4");
        assertEquals(ipv4, InetAddresses.getEmbeddedIPv4ClientAddress(testIp));


        testIp = (Inet6Address) InetAddresses.forString("2002:0102:0304::1");
        assertTrue(InetAddresses.hasEmbeddedIPv4ClientAddress(testIp));
        ipv4 = InetAddresses.forString("1.2.3.4");
        assertEquals(ipv4, InetAddresses.getEmbeddedIPv4ClientAddress(testIp));


        testIp = (Inet6Address) InetAddresses.forString(
                "2001:0000:4136:e378:8000:63bf:3fff:fdd2");
        assertTrue(InetAddresses.hasEmbeddedIPv4ClientAddress(testIp));
        ipv4 = InetAddresses.forString("192.0.2.45");
        assertEquals(ipv4, InetAddresses.getEmbeddedIPv4ClientAddress(testIp));
    }


    public void testIsMaximum() throws UnknownHostException {
        InetAddress address = InetAddress.getByName("255.255.255.254");
        assertFalse(InetAddresses.isMaximum(address));

        address = InetAddress.getByName("255.255.255.255");
        assertTrue(InetAddresses.isMaximum(address));

        address = InetAddress.getByName("ffff:ffff:ffff:ffff:ffff:ffff:ffff:fffe");
        assertFalse(InetAddresses.isMaximum(address));

        address = InetAddress.getByName("ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff");
        assertTrue(InetAddresses.isMaximum(address));
    }

    public void testIncrementIPv4() throws UnknownHostException {
        InetAddress address_66_0 = InetAddress.getByName("172.24.66.0");
        InetAddress address_66_255 = InetAddress.getByName("172.24.66.255");
        InetAddress address_67_0 = InetAddress.getByName("172.24.67.0");

        InetAddress address = address_66_0;
        for (int i = 0; i < 255; i++) {
            address = InetAddresses.increment(address);
        }
        assertEquals(address_66_255, address);

        address = InetAddresses.increment(address);
        assertEquals(address_67_0, address);

        InetAddress address_ffffff = InetAddress.getByName("255.255.255.255");
        address = address_ffffff;
        try {
            address = InetAddresses.increment(address);
            fail();
        } catch (IllegalArgumentException expected) {}
    }

    public void testIncrementIPv6() throws UnknownHostException {
        InetAddress addressV6_66_0 = InetAddress.getByName("2001:db8::6600");
        InetAddress addressV6_66_ff = InetAddress.getByName("2001:db8::66ff");
        InetAddress addressV6_67_0 = InetAddress.getByName("2001:db8::6700");

        InetAddress address = addressV6_66_0;
        for (int i = 0; i < 255; i++) {
            address = InetAddresses.increment(address);
        }
        assertEquals(addressV6_66_ff, address);

        address = InetAddresses.increment(address);
        assertEquals(addressV6_67_0, address);

        InetAddress addressV6_ffffff =
                InetAddress.getByName("ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff");
        address = addressV6_ffffff;
        try {
            address = InetAddresses.increment(address);
            fail();
        } catch (IllegalArgumentException expected) {}
    }

}
