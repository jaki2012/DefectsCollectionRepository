package com.google.common.net;

import com.google.common.annotations.GwtCompatible;
import com.google.common.annotations.GwtIncompatible;
import com.google.common.base.Ascii;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterables;
import com.google.common.testing.EqualsTester;
import com.google.common.testing.NullPointerTester;
import junit.framework.TestCase;


@GwtCompatible(emulated = true)
public final class InternetDomainNameTest extends TestCase {


    private static final ImmutableSet<String> PS = ImmutableSet.of(
            "com",
            "co.uk",
            "foo.bd",
            "xxxxxx.bd",
            "org.mK",
            "us",
            "uk\uFF61com.",
            "\u7f51\u7edc.Cn",
            "j\u00f8rpeland.no",
            "xn--jrpeland-54a.no"
    );

    private static final ImmutableSet<String> NO_PS = ImmutableSet.of(
            "www", "foo.ihopethiswillneverbeapublicsuffix", "x.y.z");


    public void testValidTopPrivateDomain() {
        InternetDomainName googleDomain = InternetDomainName.from("google.com");

        assertEquals(googleDomain, googleDomain.topPrivateDomain());
        assertEquals(googleDomain, googleDomain.child("mail").topPrivateDomain());
        assertEquals(googleDomain, googleDomain.child("foo.bar").topPrivateDomain());
    }

    public void testInvalidTopPrivateDomain() {
        ImmutableSet<String> badCookieDomains =
                ImmutableSet.of("co.uk", "foo", "com");

        for (String domain : badCookieDomains) {
            try {
                InternetDomainName.from(domain).topPrivateDomain();
                fail(domain);
            } catch (IllegalStateException expected) {
            }
        }
    }

    public void testPublicSuffix() {
        for (String name : PS) {
            final InternetDomainName domain = InternetDomainName.from(name);
            assertTrue(name, domain.isPublicSuffix());
            assertTrue(name, domain.hasPublicSuffix());
            assertFalse(name, domain.isUnderPublicSuffix());
            assertFalse(name, domain.isTopPrivateDomain());
            assertEquals(domain, domain.publicSuffix());
        }

        for (String name : NO_PS) {
            final InternetDomainName domain = InternetDomainName.from(name);
            assertFalse(name, domain.isPublicSuffix());
            assertFalse(name, domain.hasPublicSuffix());
            assertFalse(name, domain.isUnderPublicSuffix());
            assertFalse(name, domain.isTopPrivateDomain());
            assertNull(domain.publicSuffix());
        }
    }


}
