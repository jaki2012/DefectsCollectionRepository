package com.github.lwhite1.tablesaw.filtering;

/**
 *
 */
public interface BooleanPredicate {

  boolean test(byte i);
}
