package com.github.lwhite1.tablesaw.filtering;

import java.time.LocalDate;

/**
 *
 */
public interface LocalDatePredicate {

  boolean test(LocalDate i);

}
