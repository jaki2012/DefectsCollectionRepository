package com.github.lwhite1.tablesaw.plotting;

/**
 * TODO This is not very general, what about differing line types
 */
public enum  MarkerType {

  LINE,
  POINT,

}
