package com.github.lwhite1.tablesaw.filtering;

/**
 *
 */
public interface LongPredicate {

  boolean test(long i);

}
