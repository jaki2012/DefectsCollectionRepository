package com.github.lwhite1.tablesaw.filtering;

import java.time.LocalTime;

/**
 *
 */
public interface LocalTimePredicate {

  boolean test(LocalTime i);

}
