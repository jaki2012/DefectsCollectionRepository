package com.github.lwhite1.tablesaw.filtering;

/**
 *
 */
public interface IntPredicate {

  boolean test(int i);
}
