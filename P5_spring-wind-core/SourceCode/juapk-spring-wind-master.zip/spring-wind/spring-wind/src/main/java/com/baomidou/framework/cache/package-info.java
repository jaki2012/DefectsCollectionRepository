package com.baomidou.framework.cache;

/**
 * 
 * 缓存部分，查看源码：
 * 
 * /spring-wind/src/test/resources/wiki/cache
 * 
 * @author hubin
 * @Date 2016-04-13
 */
