package com.baomidou.framework.controller;

/**
 * 
 * 基础控制器抽象
 * 
 * @author hubin
 * @Date 2016-04-13
 */
