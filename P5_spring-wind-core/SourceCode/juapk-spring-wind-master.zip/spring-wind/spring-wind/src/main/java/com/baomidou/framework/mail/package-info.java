package com.baomidou.framework.mail;

/**
 * 
 * 邮件服务类
 * 
 * @author hubin
 * 
 */
