package com.baomidou.framework.exception;

/**
 * 
 * spring-wind 异常处理类
 * 
 * @author hubin
 * @Date 2016-04-13
 */
