package com.baomidou.framework.velocity;

/**
 * 
 * veloctiy 相关类
 * 
 * @author hubin
 * @Date 2016-04-13
 */
