package com.baomidou.framework.aop;

/**
 * 
 * aop 切面编程辅助类
 * 
 * @author hubin
 * @Date 2016-04-13
 */
