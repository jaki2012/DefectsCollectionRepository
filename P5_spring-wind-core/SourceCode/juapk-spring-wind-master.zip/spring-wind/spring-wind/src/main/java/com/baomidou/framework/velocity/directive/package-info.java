package com.baomidou.framework.velocity.directive;

/**
 * 
 * Veloctiy 实现继承逻辑类
 * 
 * @author hubin
 * 
 */
