package com.baomidou.framework.log;

/**
 * 
 * spring-wind 日志处理类
 * 
 * @author hubin
 * @Date 2016-06-28
 */
