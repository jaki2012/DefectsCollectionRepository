
# oauth2.0 使用（登录）

https://github.com/scribejava/scribejava

1、支持 GitHub , WeChat

2、核心库 MAVEN 地址：
http://search.maven.org/#search%7Cgav%7C1%7Cg%3A%22com.github.scribejava%22%20AND%20a%3A%22scribejava-core%22


