
# Quartz 使用

> 依赖 jars包: spring velocity mail 具体配置参考 app-mail.xml

```
<dependency>
    <groupId>org.quartz-scheduler</groupId>
    <artifactId>quartz</artifactId>
    <version>2.2.2</version>
</dependency>
```

> Quartz 配置

```
参考 app-quartz.xml, quartz.properties
```

