package com.baomidou.framework;

/**
 * Unit test for simple App.
 */
public class AppTest {
	//https://github.com/freewebsys/java-large-file-uploader-demo
}
