﻿![spring-wind](http://git.oschina.net/uploads/images/2016/0410/215321_0c4657f5_12260.png "SSM架构核心库")

SSM 架构核心库，带给您的只有惊喜！

[演示项目 + 文档说明 - 点击](http://git.oschina.net/juapk/SpringWind) **效果图往下拉！**


> 技术讨论 QQ 群 235079513[（有钱的捧个钱场【点击捐赠】, 没钱的捧个人场）](http://git.oschina.net/uploads/images/2015/1222/211207_0acab44e_12260.png)

------------------------------------------------
《春风》

春风如贵客，一到便繁华。

来扫千山雪，归留万国花。

------------------------------------------------


演示界面
=======

![登录效果](http://git.oschina.net/uploads/images/2016/0423/181624_cd5f4706_12260.png "登录效果")

![echarts演示效果](http://git.oschina.net/uploads/images/2016/0511/222846_6bbded27_12260.png "echarts演示效果")

![权限管理效果](http://git.oschina.net/uploads/images/2016/0423/182040_f9e11f03_12260.png "权限管理效果")

![监控效果](http://git.oschina.net/uploads/images/2016/0423/182059_de36d868_12260.png "监控效果")

![修改头像](http://git.oschina.net/uploads/images/2016/0509/224121_d6f7a3ca_12260.png "修改头像")

![日志管理](http://git.oschina.net/uploads/images/2016/0509/224142_5a4f847e_12260.png "日志管理")

![锁定效果](http://git.oschina.net/uploads/images/2016/0415/233245_dc44f2f9_12260.png "锁定效果")


Features
=======

1、欢迎提出更好的意见，帮助完善 Spring-Wind 

Copyright
====================
Apache License, Version 2.0