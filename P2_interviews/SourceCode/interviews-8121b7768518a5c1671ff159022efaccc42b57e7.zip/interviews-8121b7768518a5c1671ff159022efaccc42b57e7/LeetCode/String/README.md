List of interview questions pertaining to Strings
