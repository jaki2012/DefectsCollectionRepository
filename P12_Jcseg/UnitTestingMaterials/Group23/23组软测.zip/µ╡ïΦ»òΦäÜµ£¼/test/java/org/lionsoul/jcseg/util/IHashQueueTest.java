package org.lionsoul.jcseg.util;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Palaoa on 2017/6/5.
 */
public class IHashQueueTest {
    @Test
    public void add() throws Exception {

    }

    @Test
    public void contains() throws Exception {
    }

    @Test
    public void remove() throws Exception {
    }

    @Test
    public void size() throws Exception {
    }

}