package org.lionsoul.jcseg.tokenizer.core;

import org.junit.Test;
import org.lionsoul.jcseg.tokenizer.Chunk;
import org.lionsoul.jcseg.tokenizer.Word;
import org.lionsoul.jcseg.tokenizer.core.MMSegFilter;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import static org.junit.Assert.*;

/**
 * Created by Palaoa on 2017/6/6.
 */
public class MMSegFilterTest {
    @Test
    public void getMaximumMatchChunks() throws Exception
    {
        InputStreamReader isr;
        BufferedReader br;
        String message, inputStr, index;
        FileInputStream fis = new FileInputStream("testcase/tokenizer/MMSegFilter_getMaximumMatchChunks.txt");
        isr = new InputStreamReader(fis, "utf-8");
        br = new BufferedReader(isr);
        String temp;
        while((temp = br.readLine()) != null)
        {
            int a = temp.indexOf('#');
            message = temp.substring(0, a);
            inputStr = temp.substring(a+1);
            String[] inputs = inputStr.split(" ");
            ArrayList<Chunk> clist = new ArrayList<Chunk>(8);
            for(int i = 0; i < inputs.length; i++)
            {
                String[] words = inputs[i].split("_");
                ArrayList<IWord> mList = new ArrayList<IWord>(8);
                for(int j = 0;j<words.length;j++)
                {
                    IWord mword = new Word(words[j],IWord.T_CJK_WORD);
                    mList.add(mword);
                }
                IWord[] awords = new IWord[mList.size()];
                mList.toArray(awords);
                clist.add(new Chunk(awords));
            }
            IChunk[] ichunks = new IChunk[clist.size()];
            clist.toArray(ichunks);
            IChunk[] resultchunks = MMSegFilter.getMaximumMatchChunks(ichunks);

            System.out.print(message + " input: " + inputStr +" output: ");
            for(int k=0;k<resultchunks.length;k++)
            {
                IWord[] resultWords=resultchunks[k].getWords();
                for(int l=0;l<resultWords.length;l++)
                {
                    System.out.print(resultWords[l].getValue());
                    if(l<resultWords.length-1)
                        System.out.print("_");
                }
                System.out.print(" ");
            }
            System.out.println();
        }

    }

    @Test
    public void getLargestAverageWordLengthChunks() throws Exception {
        InputStreamReader isr;
        BufferedReader br;
        String message, inputStr, index;
        FileInputStream fis = new FileInputStream("testcase/tokenizer/MMSegFilter_getLargestAverageWordLengthChunks.txt");
        isr = new InputStreamReader(fis, "utf-8");
        br = new BufferedReader(isr);
        String temp;
        while((temp = br.readLine()) != null)
        {
            int a = temp.indexOf('#');
            message = temp.substring(0, a);
            inputStr = temp.substring(a+1);
            String[] inputs = inputStr.split(" ");
            ArrayList<Chunk> clist = new ArrayList<Chunk>(8);
            for(int i = 0; i < inputs.length; i++)
            {
                String[] words = inputs[i].split("_");
                ArrayList<IWord> mList = new ArrayList<IWord>(8);
                for(int j = 0;j<words.length;j++)
                {
                    IWord mword = new Word(words[j],IWord.T_CJK_WORD);
                    mList.add(mword);
                }
                IWord[] awords = new IWord[mList.size()];
                mList.toArray(awords);
                clist.add(new Chunk(awords));
            }
            IChunk[] ichunks = new IChunk[clist.size()];
            clist.toArray(ichunks);
            IChunk[] resultchunks = MMSegFilter.getLargestAverageWordLengthChunks(ichunks);

            System.out.print(message + " input: " + inputStr +" output: ");
            for(int k=0;k<resultchunks.length;k++)
            {
                IWord[] resultWords=resultchunks[k].getWords();
                for(int l=0;l<resultWords.length;l++)
                {
                    System.out.print(resultWords[l].getValue());
                    if(l<resultWords.length-1)
                        System.out.print("_");
                }
                System.out.print(" ");
            }
            System.out.println();
        }
    }

    @Test
    public void getSmallestVarianceWordLengthChunks() throws Exception {
        InputStreamReader isr;
        BufferedReader br;
        String message, inputStr, index;
        FileInputStream fis = new FileInputStream("testcase/tokenizer/MMSegFilter_getSmallestVarianceWordLengthChunks.txt");
        isr = new InputStreamReader(fis, "utf-8");
        br = new BufferedReader(isr);
        String temp;
        while((temp = br.readLine()) != null)
        {
            int a = temp.indexOf('#');
            message = temp.substring(0, a);
            inputStr = temp.substring(a+1);
            String[] inputs = inputStr.split(" ");
            ArrayList<Chunk> clist = new ArrayList<Chunk>(8);
            for(int i = 0; i < inputs.length; i++)
            {
                String[] words = inputs[i].split("_");
                ArrayList<IWord> mList = new ArrayList<IWord>(8);
                for(int j = 0;j<words.length;j++)
                {
                    IWord mword = new Word(words[j],IWord.T_CJK_WORD);
                    mList.add(mword);
                }
                IWord[] awords = new IWord[mList.size()];
                mList.toArray(awords);
                clist.add(new Chunk(awords));
            }
            IChunk[] ichunks = new IChunk[clist.size()];
            clist.toArray(ichunks);
            IChunk[] resultchunks = MMSegFilter.getSmallestVarianceWordLengthChunks(ichunks);

            System.out.print(message + " input: " + inputStr +" output: ");
            for(int k=0;k<resultchunks.length;k++)
            {
                IWord[] resultWords=resultchunks[k].getWords();
                for(int l=0;l<resultWords.length;l++)
                {
                    System.out.print(resultWords[l].getValue());
                    if(l<resultWords.length-1)
                        System.out.print("_");
                }
                System.out.print(" ");
            }
            System.out.println();
        }
    }

    @Test
    public void getLargestSingleMorphemicFreedomChunks() throws Exception {
    }

}