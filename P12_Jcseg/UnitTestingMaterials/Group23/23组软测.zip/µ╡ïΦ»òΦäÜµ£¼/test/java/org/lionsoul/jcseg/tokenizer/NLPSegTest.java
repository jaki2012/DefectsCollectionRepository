package org.lionsoul.jcseg.tokenizer;

import org.junit.Test;
import org.lionsoul.jcseg.tokenizer.core.IWord;
import org.lionsoul.jcseg.util.IStringBuffer;

import java.io.IOException;
import java.util.LinkedList;

import static org.junit.Assert.*;

/**
 * Created by Palaoa on 2017/6/6.
 */
public class NLPSegTest extends mSeg{

    private final LinkedList<IWord> eWordPool = new LinkedList<IWord>();
    private final IStringBuffer buffer = new IStringBuffer(64);

    @Test
    public void getNextTimeMergedWord() throws Exception {

    }

    public IWord next() throws IOException
    {
        if ( eWordPool.size() > 0 ) {
            return eWordPool.removeFirst();
        }

        IWord word = super.next();
        if ( word == null ) {
            return null;
        }

        String entity = word.getEntity();
        if ( entity == null ) {
            return word;
        }

        if ( entity.startsWith("time.")
                || entity.startsWith("numeric.integer#time.") ) {
            IWord dWord = getNextTimeMergedWord(word);
            if ( dWord != null ) {
                return dWord;
            }
        }

        if ( entity.equals("datetime.ymd") ) {
            IWord dWord = getNextDatetimeWord(word);
            if ( dWord != null ) {
                return dWord;
            }
        }

        return word;
    }

    @Test
    public void nextTest() throws Exception
    {
        // use parent next
        // change it
        eWordPool.add(new Word("测试pool", 1));
        System.out.println("eWordPool not empty: " + next().getValue());
        eWordPool.clear();
        // word == null
        if(next() == null)
            System.out.println("null word: null");
        else
            System.out.println("null word: Fault");

        // entity == null
        flag = 3;
        System.out.println("null entity: " + next().getValue());

        // entity == time.&& dWord != null
        flag = 1;
        flag2 = 1;
        System.out.println("time: " + next().getValue());

        // entity == datetime.ymd &&
        flag = 2;
        System.out.println("dateTime: " + next().getValue());

        flag = 4;
        System.out.println("other: "+next().getValue());
    }

}