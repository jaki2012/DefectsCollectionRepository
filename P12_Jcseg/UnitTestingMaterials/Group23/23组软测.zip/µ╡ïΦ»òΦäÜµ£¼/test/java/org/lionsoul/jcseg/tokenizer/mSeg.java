package org.lionsoul.jcseg.tokenizer;

import org.lionsoul.jcseg.tokenizer.core.IWord;

import java.io.IOException;

/**
 * Created by Palaoa on 2017/6/8.
 */
public class mSeg {

    int flag = 0;
    int flag2 = 0;

    public IWord next() throws IOException
    {
        IWord word = new Word("测试词汇",0);
        if(flag == 0)
            return null;
        else if(flag == 1)
        {
            word.setEntity("time.");
            return word;
        }
        else if(flag == 2)
        {
            word.setEntity("datetime.ymd");
            return word;
        }
        else if(flag == 4)
        {
            word.setEntity("other_entity");
            return word;
        }
        return word;
    }

    public IWord getNextTimeMergedWord(IWord input)
    {
        if(flag2 == 0)
            return null;
        IWord word = new Word("时间融合词",0);
        return word;
    }

    public IWord getNextDatetimeWord(IWord input)
    {
        if(flag2 == 0)
            return null;
        IWord word = new Word("日期时间词",0);
        return word;
    }

}
