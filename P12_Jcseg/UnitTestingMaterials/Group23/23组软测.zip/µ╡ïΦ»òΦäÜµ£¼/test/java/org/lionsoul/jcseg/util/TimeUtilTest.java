package org.lionsoul.jcseg.util;

import org.junit.Test;
import org.lionsoul.jcseg.tokenizer.core.IWord;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import static org.junit.Assert.*;

/**
 * Created by Palaoa on 2017/6/5.
 */
public class TimeUtilTest {
    /*@Test
    public void getDateTimeIndex() throws Exception {
        // get and return the time part index of the specified IWord#entity
        InputStreamReader isr;
        BufferedReader br;
        String message, inputStr, index;
        FileInputStream fis = new FileInputStream("testcase/tokenizer/ASegment_getNextMatch.txt");
        isr = new InputStreamReader(fis, "gbk");
        br = new BufferedReader(isr);
        String temp;
        IWord[] output;
        while((temp = br.readLine()) != null)

    }

    @Test
    public void fillTimeToPool() throws Exception {
    }
    */
}