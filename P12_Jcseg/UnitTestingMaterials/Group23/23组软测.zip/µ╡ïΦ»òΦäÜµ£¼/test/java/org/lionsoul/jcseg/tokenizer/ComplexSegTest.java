package org.lionsoul.jcseg.tokenizer;

import org.junit.Test;
import org.lionsoul.jcseg.tokenizer.core.*;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import static org.junit.Assert.*;

/**
 * Created by Palaoa on 2017/6/6.
 */
public class ComplexSegTest {
    @Test
    public void getBestCJKChunk() throws Exception {
        // get the best chunk(3 words) from the input stream
        // if counter not word
        // second layer return the largest word chunk
        // third layer
        JcsegTaskConfig conf = new JcsegTaskConfig(true);
        ADictionary dic = DictionaryFactory.createDefaultDictionary(conf);
        ComplexSeg seg = new ComplexSeg(conf,dic);
        InputStreamReader isr;
        BufferedReader br;
        String message, inputStr, index;
        FileInputStream fis = new FileInputStream("testcase/tokenizer/ComplexSeg_getBestCJKChunk.txt");
        isr = new InputStreamReader(fis, "gbk");
        br = new BufferedReader(isr);
        String temp;
        while((temp = br.readLine()) != null)
        {
            int a = temp.indexOf('#');
            message = temp.substring(0, a);
            inputStr = temp.substring(a + 1);
            char[] chars;
            chars = inputStr.toCharArray();
            IWord[] words = seg.getBestCJKChunk(chars, 0).getWords();
            System.out.print(message + ": ");
            for (int i = 0; i <words.length; i++)
                System.out.print(words[i].getValue() + " ");
            System.out.print('\n');
        }
    }

}