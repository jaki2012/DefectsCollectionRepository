package org.lionsoul.jcseg.tokenizer;

import org.junit.Test;
import org.lionsoul.jcseg.tokenizer.core.*;

import java.io.*;
import java.util.ArrayList;

import static org.junit.Assert.*;

/**
 * Created by Leo on 2017/6/5.
 */
public class ASegment2Test {
    @Test
    @SuppressWarnings("unchecked")
    public void nextCJKSentenceTest() throws Exception {
        JcsegTaskConfig conf = new JcsegTaskConfig(true);
        ADictionary dic = DictionaryFactory.createDefaultDictionary(conf);
        ASegment seg = new ASegment(conf, dic) {
            @Override
            protected IChunk getBestCJKChunk(char[] chars, int index) throws IOException {
                return null;
            }
        };
        InputStreamReader isr;
        BufferedReader br;
        String message, inputStr, index;
        FileInputStream fis = new FileInputStream("testcase/tokenizer/ASegment_nextCJKSentence.txt");
        isr = new InputStreamReader(fis, "gbk");
        br = new BufferedReader(isr);
        String temp;
        IWord[] output;
        while((temp = br.readLine()) != null)
        {
            int a = temp.indexOf('#');
            int c = 0;
            if( a < temp.length()-1 )
                c = temp.charAt(a+1);
            else
            {
                message = temp.substring(0, a);
                seg.reset(new StringReader(""));
                char[] chars = seg.nextCJKSentence('#');
                System.out.print(message + " input: " + " output: "+(new String(chars)));
                System.out.print('\n');
                continue;
            }
            message = temp.substring(0, a);
            inputStr = temp.substring(a+1);

            seg.reset(new StringReader(inputStr));
            char[] chars = seg.nextCJKSentence('#');
            System.out.print(message + " input: " + inputStr +" output: "+(new String(chars)));
            System.out.print('\n');
        }
    }

    @org.junit.Test
    public void nextLatinWordTest() throws Exception {
        JcsegTaskConfig conf = new JcsegTaskConfig(true);
        ADictionary dic = DictionaryFactory.createDefaultDictionary(conf);
        ASegment seg = new ASegment(conf, dic) {
            @Override
            protected IChunk getBestCJKChunk(char[] chars, int index) throws IOException {
                return null;
            }
        };
        InputStreamReader isr;
        BufferedReader br;
        String message, inputStr, index;
        FileInputStream fis = new FileInputStream("testcase/tokenizer/ASegment_nextLatinWordTest.txt");
        isr = new InputStreamReader(fis, "utf-8");
        br = new BufferedReader(isr);
        String temp;
        IWord output;
        while((temp = br.readLine()) != null)
        {
            int a = temp.indexOf('#');
            int pos=1;
            int c = 0; // temp.charAt(a+1);
            if( a < temp.length() - 1)
                c = temp.charAt(a+1);
            else
            {
                inputStr = "";
                seg.reset(new StringReader(inputStr));

                output = seg.nextLatinWord('#',pos);
                System.out.print("empty" + " input: " + " output: " + output.getValue());
                System.out.print('\n');
                continue;
            }
            message = temp.substring(0, a);
            inputStr = temp.substring(a+1);
            seg.reset(new StringReader(inputStr));

            output = seg.nextLatinWord('#',pos);
            System.out.print(message + " input: " + inputStr + " output: " + output.getValue());
            System.out.print('\n');
        }
    }

    @org.junit.Test
    public void nextLatinStringTest() throws Exception {
        JcsegTaskConfig conf = new JcsegTaskConfig(true);
        ADictionary dic = DictionaryFactory.createDefaultDictionary(conf);
        ASegment seg = new ASegment(conf, dic) {
            @Override
            protected IChunk getBestCJKChunk(char[] chars, int index) throws IOException {
                return null;
            }
        };
        InputStreamReader isr;
        BufferedReader br;
        String message, inputStr, index;
        FileInputStream fis = new FileInputStream("testcase/tokenizer/ASegment_nextLatinStringTest.txt");
        isr = new InputStreamReader(fis, "utf-8");
        br = new BufferedReader(isr);
        String temp;
        while((temp = br.readLine()) != null)
        {
            int a = temp.indexOf('#');
            int c = 0; //temp.charAt(a+1);
            if(a < temp.length() - 1)
                c = temp.charAt(a+1);
            else
            {
                seg.reset(new StringReader(""));
                String output = seg.nextLatinString('#');
                System.out.print("empty" + " input: " +" output: " + output);
                System.out.print('\n');
            }
            message = temp.substring(0, a);
            inputStr = temp.substring(a+1);

            seg.reset(new StringReader(inputStr));
            String output = seg.nextLatinString('#');
            System.out.print(message + " input: " + inputStr +" output: "+output);
            System.out.print('\n');
        }
    }

    @org.junit.Test
    public void nextCNNumericTest() throws Exception {
        JcsegTaskConfig conf = new JcsegTaskConfig(true);
        ADictionary dic = DictionaryFactory.createDefaultDictionary(conf);
        ASegment seg = new ASegment(conf, dic) {
            @Override
            protected IChunk getBestCJKChunk(char[] chars, int index) throws IOException {
                return null;
            }
        };
        InputStreamReader isr;
        BufferedReader br;
        String message, inputStr, index;
        FileInputStream fis = new FileInputStream("testcase/tokenizer/ASegment_nextCNNumericTest.txt");
        isr = new InputStreamReader(fis, "utf-8");
        br = new BufferedReader(isr);
        String temp;
        while((temp = br.readLine()) != null)
        {
            int a = temp.indexOf('#');
            message = temp.substring(0, a);
            inputStr = temp.substring(a+1);
            String output = seg.nextCNNumeric(inputStr.toCharArray(),0);
            System.out.print(message + " input: " + inputStr +" output: "+output);
            System.out.print('\n');
        }
    }

    @org.junit.Test
    public void getPairPunctuationText() throws Exception {
        JcsegTaskConfig conf = new JcsegTaskConfig(true);
        ADictionary dic = DictionaryFactory.createDefaultDictionary(conf);
        ASegment seg = new ASegment(conf, dic) {
            @Override
            protected IChunk getBestCJKChunk(char[] chars, int index) throws IOException {
                return null;
            }
        };
        InputStreamReader isr;
        BufferedReader br;
        String message, inputStr, index;
        FileInputStream fis = new FileInputStream("testcase/tokenizer/ASegment_getPairPunText.txt");
        isr = new InputStreamReader(fis, "utf-8");
        br = new BufferedReader(isr);
        String temp;
        while((temp = br.readLine()) != null)
        {
            int a = temp.indexOf('#');
            int c = temp.charAt(a+1);
            message = temp.substring(0, a);
            inputStr = temp.substring(a+1);
            seg.reset(new StringReader(inputStr));
            String output = seg.getPairPunctuationText(c);
            System.out.print(message + " input: " + inputStr +" output: "+output);
            System.out.print('\n');
        }
    }

    @org.junit.Test
    public void nextTest() throws Exception {
        JcsegTaskConfig conf = new JcsegTaskConfig(true);
        ADictionary dic = DictionaryFactory.createDefaultDictionary(conf);
        ASegment seg = new ASegment(conf, dic) {
            @Override
            protected IChunk getBestCJKChunk(char[] chars, int index) throws IOException {
                return null;
            }
        };
        InputStreamReader isr;
        BufferedReader br;
        String message, inputStr, index;
        FileInputStream fis = new FileInputStream("testcase/tokenizer/ASegment_next.txt");
        isr = new InputStreamReader(fis, "utf-8");
        br = new BufferedReader(isr);
        String temp;
        ASegment.tcNum=0;
        while((temp = br.readLine()) != null)
        {
            ASegment.tcNum++;
            int a = temp.indexOf('#');
            if(a==temp.length()-1)
            {
                message = temp.substring(0, a);
                System.out.print(message + " input: " +" output: ");
                continue;
            }
            int c = temp.charAt(a+1);
            message = temp.substring(0, a);
            inputStr = temp.substring(a+1);
            seg.reset(new StringReader(inputStr));
            ArrayList<IWord> wlist=new ArrayList<IWord>(8);
            IWord[] outputs;
            IWord wtemp;
            while((wtemp=seg.next())!=null)
            {
                wlist.add(wtemp);
            }
            outputs=new IWord[wlist.size()];
            wlist.toArray(outputs);
            System.out.print(message + " input: " + inputStr +" output: ");
            for(int i=0;i<outputs.length;i++)
            {
                System.out.print(outputs[i].getValue());
                if(i!=outputs.length-1)
                    System.out.print(" ");
            }
            System.out.print('\n');
        }
    }
}