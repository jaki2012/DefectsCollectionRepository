package com.crazy.controller;

import com.crazy.entity.Account;
import com.crazy.entity.Requirement;
import com.crazy.entity.UserInfoDetail;
import com.crazy.repository.AccountRepository;
import com.crazy.repository.RequirementRepository;
import com.crazy.repository.UserInfoDetailRepository;
import com.crazy.security.JwtAuthenticationRequest;
import com.crazy.security.JwtTokenUtil;
import com.crazy.service.*;
import com.crazy.util.ResJsonTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Date;


/**
 * Account Controller
 * Created by SHIKUN on 2016/9/30.
 */

@RestController
@RequestMapping(value = "/api")
public class AccountController {
    @Value("Authorization")
    private String tokenHeader;

    @Autowired
    private AccountService accountService;
    @Autowired
    private RequirementService requirementService;
    @Autowired
    private UserInfoDetailService userInfoDetailService;
    @Autowired
    private ProjectExperienceService projectExperienceService;
    @Autowired
    UserInfoDetailRepository userInfoDetailRepository;
    @Autowired
    JwtTokenUtil jwtTokenUtil;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private RequirementRepository requirementRepository;


    //获取token
    @RequestMapping(value = "/session", method = RequestMethod.POST)
    public ResJsonTemplate createAuthenticationToken(
            @RequestBody JwtAuthenticationRequest authenticationRequest) throws AuthenticationException {
        //数据库查找是否存在该用户
        Account account = accountRepository.findByUsername(authenticationRequest.getUsername());
        if (account == null) {
            return new ResJsonTemplate("404", "用户不存在");
        }
        //验证账号密码是否正确
        final java.lang.String token = accountService.login(authenticationRequest.getUsername(), authenticationRequest.getPassword());


        UserInfoDetail userInfoDetail = userInfoDetailRepository.findById(account.getInfo_id());
        AccountInfo d = new AccountInfo();
        d.setToken(token);
        d.setUserInfoDetail(userInfoDetail);

        return new ResJsonTemplate("200", d);


    }

    @RequestMapping(value = "/user/verification", method = RequestMethod.POST)
    public ResJsonTemplate UserInfoVerifacation(
            HttpServletRequest request, @RequestBody UserInfoDetail userInfoDetail) throws AuthenticationException {
        Account account = getAccount(request);
        return userInfoDetailService.addUserInfoDetail(account,userInfoDetail);

    }

    @RequestMapping(value = "/user/projectExperience", method = RequestMethod.POST)
    public ResJsonTemplate developerSkill(
            HttpServletRequest request, @RequestParam(value = "certificate", required = false) MultipartFile file,
            @RequestParam(value = "project_name") String project_name,
            @RequestParam(value = "project_region") String project_region,
            @RequestParam(value = "project_address") String project_address,
            @RequestParam(value = "project_text") String project_text
    ) throws AuthenticationException, IOException {
        Account account = getAccount(request);
        return projectExperienceService.addExperience(account,
                file,
                project_name,
                project_region,
                project_address,
                project_text);
    }


    @RequestMapping(value = "/requirement", method = RequestMethod.POST)
    public ResJsonTemplate createRequirement(
            HttpServletRequest request,
            @RequestParam(value = "requirement_name") String requirement_name,
            @RequestParam(value = "requirement_type") String requirement_type,
            @RequestParam(value = "need_manager") int need_manager,
            @RequestParam(value = "start_time") @DateTimeFormat(pattern = "yyyy-MM-dd") Date start_time,
            @RequestParam(value = "end_time") @DateTimeFormat(pattern = "yyyy-MM-dd") Date end_time,
            @RequestParam(value = "requirement_detail") String requirement_detail,
            @RequestParam(value = "file", required = false) MultipartFile file) throws AuthenticationException, IOException {
        Account account = getAccount(request);
        return  requirementService.addRequirement(account,requirement_name,
                requirement_type,
                need_manager,
                start_time,
                end_time,
                requirement_detail,
                file);
    }


    @RequestMapping(value= "/requirement",method=RequestMethod.GET)
    public ResJsonTemplate getRequirement(HttpServletRequest request)
    {
        Account account = getAccount(request);
        return  requirementService.getReuirement(account);
    }

    @RequestMapping(value = "/requirement/{id}", method = RequestMethod.DELETE)
    public ResJsonTemplate DeteleRequirement(HttpServletRequest request, @PathVariable Long id) {
        String token = request.getHeader("Authorization");
        if (token == null) {
            return new ResJsonTemplate("401", "权限错误");
        }
        if (!requirementRepository.exists(id)) {
            return new ResJsonTemplate("400", "删除失败");
        }
        requirementRepository.deleteById(id);
        return new ResJsonTemplate("200", "删除成功");
    }

    @RequestMapping(value = "/requirement/{id}", method = RequestMethod.PUT)
    public ResJsonTemplate UpdateRequirement(HttpServletRequest request, @RequestBody Requirement requirement, @PathVariable Long id) {
        String token = request.getHeader("Authorization");
        if (token == null) {
            return new ResJsonTemplate("401", "权限错误");
        }
        if (!requirementRepository.exists(id)) {
            return new ResJsonTemplate("400", "删除失败");
        }
        requirement.setId(id);
        requirementRepository.save(requirement);
        return new ResJsonTemplate("200", "更新成功");
    }

    @RequestMapping(value = "/requirement/{id}", method = RequestMethod.GET)
    public ResJsonTemplate GetRequirementDetail(HttpServletRequest request, @PathVariable Long id) {
        String token = request.getHeader("Authorization");
        if (token == null) {
            return new ResJsonTemplate("401", "权限错误");
        }
        RequirementDetail requirementDetail = new RequirementDetail();
        requirementDetail = accountService.GetRequirementDetail(id);
        return new ResJsonTemplate("200", requirementDetail);
    }


    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public ResJsonTemplate register(@RequestBody Account addedUser) throws AuthenticationException {
        if (accountService.register(addedUser) != null) {

            return new ResJsonTemplate<java.lang.String>("201", "注册成功");
        } else {
            return new ResJsonTemplate<java.lang.String>("400", "注册失败");
        }
    }

    @PreAuthorize("hasRole('user')")
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public Account getUserByUsername(@RequestParam(value = "username") java.lang.String username) {
        return accountRepository.findByUsername(username);
    }

    public Account getAccount(HttpServletRequest request)
    {
        java.lang.String token = request.getHeader("Authorization");
        java.lang.String username = jwtTokenUtil.getUsernameFromToken(token);
        Account account = accountRepository.findByUsername(username);
        return account;
    }

}






class AccountInfo {
    private java.lang.String token;
    private UserInfoDetail userInfoDetail;

    public void setToken(java.lang.String t) {
        token = t;
    }

    public java.lang.String getToken() {
        return token;
    }

    public void setUserInfoDetail(UserInfoDetail u) {
        userInfoDetail = u;
    }

    public UserInfoDetail getUserInfoDetail() {
        return userInfoDetail;
    }
}
