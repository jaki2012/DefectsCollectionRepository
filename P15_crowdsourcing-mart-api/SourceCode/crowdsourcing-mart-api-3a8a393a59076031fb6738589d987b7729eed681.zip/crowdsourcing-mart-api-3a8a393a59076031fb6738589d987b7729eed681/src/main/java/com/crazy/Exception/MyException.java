package com.crazy.exception;

/**
 * 异常捕获类
 * Created by SHIKUN on 2016/11/1.
 */
public class MyException extends Exception {
    public MyException(String message) {
        super(message);

    }

}
