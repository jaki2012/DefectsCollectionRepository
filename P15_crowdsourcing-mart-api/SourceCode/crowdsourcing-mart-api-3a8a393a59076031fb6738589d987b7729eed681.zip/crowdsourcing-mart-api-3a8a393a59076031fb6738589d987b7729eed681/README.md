# crowdsourcing-mart-api
The crowdsourcing mart server api project. This project provid api service for front.
# framework for this project.
Crowdsourcing-mart-api uses Spring Boot as the main framework. Using Mybatis as the ORM layers framework.
# how to resovle project dependencies?
The whole project uses gradle to simplify the dependecies. you can run **gradle build** at your local enviroment to download the libraries.
# how to run this project?
You can use command Spring boot command line run this project, but we recommand using IDEA to run this project.The main function entry is **Application.java**
