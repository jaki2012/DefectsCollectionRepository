package com.crazy.service.impl;
import com.crazy.entity.Account;
import com.crazy.service.AccountService;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.jupiter.api.Assertions.*;


@RunWith(SpringRunner.class)
@SpringBootTest
public class AccountServiceImplTest {
    @Autowired
    private AccountService accountService;

    @Test
    @Ignore
    public void registerTest () {
        Account account = new Account();
        account.setEmail("183540581@qq.com");
        account.setPassword("test");
        account.setUsername("NeeTest");

        Account result = accountService.register(account);
        assertNotNull(result);
    }

    @Test
    public void registerRepeatTest() {
        Account account = new Account();
        account.setEmail("183540581@qq.com");
        account.setPassword("test");
        account.setUsername("NeeTest");

        Account result = accountService.register(account);
        assertNull(result);
    }


    @Test
    public void loginTest() {
        try {
            accountService.login("Nee", "test");
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void loginTestUserNotExist() {
        try {
            accountService.login("NeeN", "test");
        } catch (Exception e) {
            assertNotNull(e);
        }
    }

    @Test
    public void loginTestPasswordIncorrect() {
        try {
            accountService.login("Nee", "testtest");
        } catch (Exception e) {
            assertNotNull(e);
        }
    }
}
