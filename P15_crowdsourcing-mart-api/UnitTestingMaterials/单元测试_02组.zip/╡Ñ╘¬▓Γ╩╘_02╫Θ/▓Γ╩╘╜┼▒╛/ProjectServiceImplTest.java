package com.crazy.service.impl;

import com.crazy.service.ProjectService;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;



@RunWith(SpringRunner.class)
@SpringBootTest
public class ProjectServiceImplTest {
    private int current_project_num = 3;
    @Autowired
    ProjectService projectService;

    @Test
    public void projectListTest() {
        int result = ((ArrayList)projectService.getAllproject().getResult()).size();

        assertEquals(result, current_project_num, "project numbers incorrect");
    }



    @Test
    @Ignore
    public void projectAddTest() {
        try {
            String result = projectService.addProject(3000,60,30, "Tongji Daxue", "Test Project", "Nee", "Web", "Test Project").getResult().toString();
        } catch (Exception e) {
            fail(e.getMessage());
        }
        int count = ((ArrayList)projectService.getAllproject().getResult()).size();
        assertEquals(count, current_project_num + 1, "add project fail");
    }

    @Test
    @Ignore
    public void getProjectListbyusernameTest() {
        int result = ((ArrayList)projectService.getProjectListbyusername("Nee").getResult()).size();
        assertEquals(0, result, "get personal project list fail");

        result = ((ArrayList)projectService.getProjectListbyusername("yuhao123").getResult()).size();
        assertEquals(3, result, "get personal project list fail");

        result = Integer.valueOf(projectService.getProjectListbyusername("NeeN").getStatus());
        assertEquals(500, result, "get project list error if user not exists");
    }

    @Test
    public void getProjectDetailByProjectIdTest() {
        long id = 1;

        int count = ((ArrayList)projectService.getProjectDetailByProjectId(id).getResult()).size();
        assertEquals(1, count, "get project detail failed");

        id = -1;
        count = ((ArrayList)projectService.getProjectDetailByProjectId(id).getResult()).size();
        assertEquals(0, count, "get project detail failed");

    }

    @Test
    @Ignore
    public void getDeveloperCountbyProjectIdTest() {
        long id = 2;
        int count = Integer.valueOf(projectService.getDeveloperCountbyProjectId(id).getResult().toString());
        assertEquals(1, count, "get develop count by project id fail");

        id = -1;
        int state = Integer.valueOf(projectService.getDeveloperCountbyProjectId(id).getStatus());
        assertEquals(500, state, "get develop count by project id fail when project not exists");
    }


}



















