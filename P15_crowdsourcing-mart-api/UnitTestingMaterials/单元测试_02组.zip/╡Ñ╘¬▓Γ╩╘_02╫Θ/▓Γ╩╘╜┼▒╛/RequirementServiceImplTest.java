package com.crazy.service.impl;

import com.crazy.entity.Account;
import com.crazy.service.RequirementService;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RequirementServiceImplTest {
    @Autowired
    RequirementService requirementService;


    @Test
    @Ignore
    public void getReuirementTest() {
        Account account = new Account();
        account.setAccount_id((long)30);
        int count = ((ArrayList)requirementService.getReuirement(account).getResult()).size();

        assertEquals(8, count, "get requirement count fail");

        account.setAccount_id((long)-1);
        int state = Integer.valueOf(requirementService.getReuirement(account).getStatus());
        assertEquals(500, state, "get requirement fail when account not exists");
    }
}